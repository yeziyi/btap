package com.tapjoy.mraid.listener;

public abstract interface Player
{
  public abstract void onComplete();
  
  public abstract void onPrepared();
  
  public abstract void onError();
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.listener.Player
 * JD-Core Version:    0.7.0.1
 */