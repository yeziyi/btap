package com.tapjoy.mraid.listener;

import android.graphics.Bitmap;
import android.webkit.ConsoleMessage;
import android.webkit.WebView;

public abstract interface MraidViewListener
{
  public abstract boolean onReady();
  
  public abstract boolean onClose();
  
  public abstract boolean onResize();
  
  public abstract boolean onExpand();
  
  public abstract boolean onExpandClose();
  
  public abstract boolean onResizeClose();
  
  public abstract boolean onEventFired();
  
  public abstract void onReceivedError(WebView paramWebView, int paramInt, String paramString1, String paramString2);
  
  public abstract void onPageStarted(WebView paramWebView, String paramString, Bitmap paramBitmap);
  
  public abstract void onPageFinished(WebView paramWebView, String paramString);
  
  public abstract boolean shouldOverrideUrlLoading(WebView paramWebView, String paramString);
  
  public abstract boolean onConsoleMessage(ConsoleMessage paramConsoleMessage);
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.listener.MraidViewListener
 * JD-Core Version:    0.7.0.1
 */