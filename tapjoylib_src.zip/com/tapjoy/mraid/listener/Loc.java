/*   1:    */ package com.tapjoy.mraid.listener;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.location.Location;
/*   5:    */ import android.location.LocationListener;
/*   6:    */ import android.location.LocationManager;
/*   7:    */ import android.os.Bundle;
/*   8:    */ import com.tapjoy.mraid.controller.MraidLocation;
/*   9:    */ 
/*  10:    */ public class Loc
/*  11:    */   implements LocationListener
/*  12:    */ {
/*  13:    */   MraidLocation mOrmmaLocationController;
/*  14:    */   private LocationManager mLocMan;
/*  15:    */   private String mProvider;
/*  16:    */   
/*  17:    */   public Loc(Context c, int interval, MraidLocation ormmaLocationController, String provider)
/*  18:    */   {
/*  19: 76 */     this.mOrmmaLocationController = ormmaLocationController;
/*  20: 77 */     this.mLocMan = ((LocationManager)c.getSystemService("location"));
/*  21: 78 */     this.mProvider = provider;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public void onProviderDisabled(String provider)
/*  25:    */   {
/*  26: 86 */     this.mOrmmaLocationController.fail();
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void onStatusChanged(String provider, int status, Bundle extras)
/*  30:    */   {
/*  31: 93 */     if (status == 0) {
/*  32: 94 */       this.mOrmmaLocationController.fail();
/*  33:    */     }
/*  34:    */   }
/*  35:    */   
/*  36:    */   public void onLocationChanged(Location location)
/*  37:    */   {
/*  38:102 */     this.mOrmmaLocationController.success(location);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void stop()
/*  42:    */   {
/*  43:109 */     this.mLocMan.removeUpdates(this);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public void onProviderEnabled(String provider) {}
/*  47:    */   
/*  48:    */   public void start()
/*  49:    */   {
/*  50:125 */     this.mLocMan.requestLocationUpdates(this.mProvider, 0L, 0.0F, this);
/*  51:    */   }
/*  52:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.listener.Loc
 * JD-Core Version:    0.7.0.1
 */