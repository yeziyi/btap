/*   1:    */ package com.tapjoy.mraid.listener;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.hardware.Sensor;
/*   5:    */ import android.hardware.SensorEvent;
/*   6:    */ import android.hardware.SensorEventListener;
/*   7:    */ import android.hardware.SensorManager;
/*   8:    */ import com.tapjoy.mraid.controller.MraidSensor;
/*   9:    */ import java.util.List;
/*  10:    */ 
/*  11:    */ public class Accel
/*  12:    */   implements SensorEventListener
/*  13:    */ {
/*  14:    */   private static final int FORCE_THRESHOLD = 1000;
/*  15:    */   private static final int TIME_THRESHOLD = 100;
/*  16:    */   private static final int SHAKE_TIMEOUT = 500;
/*  17:    */   private static final int SHAKE_DURATION = 2000;
/*  18:    */   private static final int SHAKE_COUNT = 2;
/*  19:    */   MraidSensor mSensorController;
/*  20:    */   String mKey;
/*  21: 41 */   int registeredTiltListeners = 0;
/*  22: 42 */   int registeredShakeListeners = 0;
/*  23: 43 */   int registeredHeadingListeners = 0;
/*  24:    */   private SensorManager sensorManager;
/*  25: 46 */   private int mSensorDelay = 3;
/*  26:    */   private long mLastForce;
/*  27:    */   private int mShakeCount;
/*  28:    */   private long mLastTime;
/*  29:    */   private long mLastShake;
/*  30:    */   private float[] mMagVals;
/*  31: 52 */   private float[] mAccVals = { 0.0F, 0.0F, 0.0F };
/*  32:    */   private boolean bMagReady;
/*  33:    */   private boolean bAccReady;
/*  34: 55 */   private float[] mLastAccVals = { 0.0F, 0.0F, 0.0F };
/*  35: 56 */   private float[] mActualOrientation = { -1.0F, -1.0F, -1.0F };
/*  36:    */   
/*  37:    */   public Accel(Context ctx, MraidSensor sensorController)
/*  38:    */   {
/*  39: 66 */     this.mSensorController = sensorController;
/*  40: 67 */     this.sensorManager = ((SensorManager)ctx.getSystemService("sensor"));
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void setSensorDelay(int delay)
/*  44:    */   {
/*  45: 76 */     this.mSensorDelay = delay;
/*  46: 77 */     if ((this.registeredTiltListeners > 0) || (this.registeredShakeListeners > 0))
/*  47:    */     {
/*  48: 78 */       stop();
/*  49: 79 */       start();
/*  50:    */     }
/*  51:    */   }
/*  52:    */   
/*  53:    */   public void startTrackingTilt()
/*  54:    */   {
/*  55: 87 */     if (this.registeredTiltListeners == 0) {
/*  56: 88 */       start();
/*  57:    */     }
/*  58: 89 */     this.registeredTiltListeners += 1;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void stopTrackingTilt()
/*  62:    */   {
/*  63: 96 */     if ((this.registeredTiltListeners > 0) && (--this.registeredTiltListeners == 0)) {
/*  64: 97 */       stop();
/*  65:    */     }
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void startTrackingShake()
/*  69:    */   {
/*  70:105 */     if (this.registeredShakeListeners == 0)
/*  71:    */     {
/*  72:106 */       setSensorDelay(1);
/*  73:107 */       start();
/*  74:    */     }
/*  75:109 */     this.registeredShakeListeners += 1;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void stopTrackingShake()
/*  79:    */   {
/*  80:116 */     if ((this.registeredShakeListeners > 0) && (--this.registeredShakeListeners == 0))
/*  81:    */     {
/*  82:117 */       setSensorDelay(3);
/*  83:118 */       stop();
/*  84:    */     }
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void startTrackingHeading()
/*  88:    */   {
/*  89:126 */     if (this.registeredHeadingListeners == 0) {
/*  90:127 */       startMag();
/*  91:    */     }
/*  92:128 */     this.registeredHeadingListeners += 1;
/*  93:    */   }
/*  94:    */   
/*  95:    */   private void startMag()
/*  96:    */   {
/*  97:135 */     List<Sensor> list = this.sensorManager.getSensorList(2);
/*  98:136 */     if (list.size() > 0)
/*  99:    */     {
/* 100:137 */       this.sensorManager.registerListener(this, (Sensor)list.get(0), this.mSensorDelay);
/* 101:138 */       start();
/* 102:    */     }
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void stopTrackingHeading()
/* 106:    */   {
/* 107:148 */     if ((this.registeredHeadingListeners > 0) && (--this.registeredHeadingListeners == 0)) {
/* 108:149 */       stop();
/* 109:    */     }
/* 110:    */   }
/* 111:    */   
/* 112:    */   private void start()
/* 113:    */   {
/* 114:157 */     List<Sensor> list = this.sensorManager.getSensorList(1);
/* 115:158 */     if (list.size() > 0) {
/* 116:159 */       this.sensorManager.registerListener(this, (Sensor)list.get(0), this.mSensorDelay);
/* 117:    */     }
/* 118:    */   }
/* 119:    */   
/* 120:    */   public void stop()
/* 121:    */   {
/* 122:169 */     if ((this.registeredHeadingListeners == 0) && (this.registeredShakeListeners == 0) && (this.registeredTiltListeners == 0)) {
/* 123:170 */       this.sensorManager.unregisterListener(this);
/* 124:    */     }
/* 125:    */   }
/* 126:    */   
/* 127:    */   public void onAccuracyChanged(Sensor sensor, int accuracy) {}
/* 128:    */   
/* 129:    */   public void onSensorChanged(SensorEvent event)
/* 130:    */   {
/* 131:184 */     switch (event.sensor.getType())
/* 132:    */     {
/* 133:    */     case 2: 
/* 134:187 */       this.mMagVals = ((float[])event.values.clone());
/* 135:188 */       this.bMagReady = true;
/* 136:189 */       break;
/* 137:    */     case 1: 
/* 138:192 */       this.mLastAccVals = this.mAccVals;
/* 139:193 */       this.mAccVals = ((float[])event.values.clone());
/* 140:194 */       this.bAccReady = true;
/* 141:    */     }
/* 142:197 */     if ((this.mMagVals != null) && (this.mAccVals != null) && (this.bAccReady) && (this.bMagReady))
/* 143:    */     {
/* 144:198 */       this.bAccReady = false;
/* 145:199 */       this.bMagReady = false;
/* 146:200 */       float[] R = new float[9];
/* 147:201 */       float[] I = new float[9];
/* 148:202 */       SensorManager.getRotationMatrix(R, I, this.mAccVals, this.mMagVals);
/* 149:    */       
/* 150:204 */       this.mActualOrientation = new float[3];
/* 151:    */       
/* 152:206 */       SensorManager.getOrientation(R, this.mActualOrientation);
/* 153:207 */       this.mSensorController.onHeadingChange(this.mActualOrientation[0]);
/* 154:    */     }
/* 155:209 */     if (event.sensor.getType() == 1)
/* 156:    */     {
/* 157:210 */       long now = System.currentTimeMillis();
/* 158:212 */       if (now - this.mLastForce > 500L) {
/* 159:213 */         this.mShakeCount = 0;
/* 160:    */       }
/* 161:216 */       if (now - this.mLastTime > 100L)
/* 162:    */       {
/* 163:217 */         long diff = now - this.mLastTime;
/* 164:218 */         float speed = Math.abs(this.mAccVals[0] + this.mAccVals[1] + this.mAccVals[2] - this.mLastAccVals[0] - this.mLastAccVals[1] - this.mLastAccVals[2]) / (float)diff * 10000.0F;
/* 165:222 */         if (speed > 1000.0F)
/* 166:    */         {
/* 167:224 */           if ((++this.mShakeCount >= 2) && (now - this.mLastShake > 2000L))
/* 168:    */           {
/* 169:225 */             this.mLastShake = now;
/* 170:226 */             this.mShakeCount = 0;
/* 171:227 */             this.mSensorController.onShake();
/* 172:    */           }
/* 173:229 */           this.mLastForce = now;
/* 174:    */         }
/* 175:231 */         this.mLastTime = now;
/* 176:232 */         this.mSensorController.onTilt(this.mAccVals[0], this.mAccVals[1], this.mAccVals[2]);
/* 177:    */       }
/* 178:    */     }
/* 179:    */   }
/* 180:    */   
/* 181:    */   public float getHeading()
/* 182:    */   {
/* 183:245 */     return this.mActualOrientation[0];
/* 184:    */   }
/* 185:    */   
/* 186:    */   public void stopAllListeners()
/* 187:    */   {
/* 188:252 */     this.registeredTiltListeners = 0;
/* 189:253 */     this.registeredShakeListeners = 0;
/* 190:254 */     this.registeredHeadingListeners = 0;
/* 191:    */     try
/* 192:    */     {
/* 193:256 */       stop();
/* 194:    */     }
/* 195:    */     catch (Exception e) {}
/* 196:    */   }
/* 197:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.listener.Accel
 * JD-Core Version:    0.7.0.1
 */