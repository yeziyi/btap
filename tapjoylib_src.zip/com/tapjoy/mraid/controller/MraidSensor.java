/*   1:    */ package com.tapjoy.mraid.controller;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import com.tapjoy.TapjoyLog;
/*   5:    */ import com.tapjoy.mraid.listener.Accel;
/*   6:    */ import com.tapjoy.mraid.view.MraidView;
/*   7:    */ 
/*   8:    */ public class MraidSensor
/*   9:    */   extends Abstract
/*  10:    */ {
/*  11:    */   private static final String TAG = "MRAID Sensor";
/*  12: 16 */   final int INTERVAL = 1000;
/*  13:    */   private Accel mAccel;
/*  14: 18 */   private float mLastX = 0.0F;
/*  15: 19 */   private float mLastY = 0.0F;
/*  16: 20 */   private float mLastZ = 0.0F;
/*  17:    */   
/*  18:    */   public MraidSensor(MraidView adView, Context context)
/*  19:    */   {
/*  20: 29 */     super(adView, context);
/*  21: 30 */     this.mAccel = new Accel(context, this);
/*  22:    */   }
/*  23:    */   
/*  24:    */   public void startTiltListener()
/*  25:    */   {
/*  26: 37 */     this.mAccel.startTrackingTilt();
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void startShakeListener()
/*  30:    */   {
/*  31: 44 */     this.mAccel.startTrackingShake();
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void stopTiltListener()
/*  35:    */   {
/*  36: 51 */     this.mAccel.stopTrackingTilt();
/*  37:    */   }
/*  38:    */   
/*  39:    */   public void stopShakeListener()
/*  40:    */   {
/*  41: 58 */     this.mAccel.stopTrackingShake();
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void startHeadingListener()
/*  45:    */   {
/*  46: 65 */     this.mAccel.startTrackingHeading();
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void stopHeadingListener()
/*  50:    */   {
/*  51: 72 */     this.mAccel.stopTrackingHeading();
/*  52:    */   }
/*  53:    */   
/*  54:    */   void stop() {}
/*  55:    */   
/*  56:    */   public void onShake()
/*  57:    */   {
/*  58: 85 */     this.mMraidView.injectMraidJavaScript("mraid.gotShake()");
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void onTilt(float x, float y, float z)
/*  62:    */   {
/*  63: 96 */     this.mLastX = x;
/*  64: 97 */     this.mLastY = y;
/*  65: 98 */     this.mLastZ = z;
/*  66:    */     
/*  67:100 */     String script = "window.mraidview.fireChangeEvent({ tilt: " + getTilt() + "})";
/*  68:101 */     TapjoyLog.d("MRAID Sensor", script);
/*  69:102 */     this.mMraidView.injectMraidJavaScript(script);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public String getTilt()
/*  73:    */   {
/*  74:111 */     String tilt = "{ x : \"" + this.mLastX + "\", y : \"" + this.mLastY + "\", z : \"" + this.mLastZ + "\"}";
/*  75:112 */     TapjoyLog.d("MRAID Sensor", "getTilt: " + tilt);
/*  76:113 */     return tilt;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void onHeadingChange(float f)
/*  80:    */   {
/*  81:122 */     String script = "window.mraidview.fireChangeEvent({ heading: " + (int)(f * 57.295779513082323D) + "});";
/*  82:123 */     TapjoyLog.d("MRAID Sensor", script);
/*  83:124 */     this.mMraidView.injectMraidJavaScript(script);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public float getHeading()
/*  87:    */   {
/*  88:133 */     TapjoyLog.d("MRAID Sensor", "getHeading: " + this.mAccel.getHeading());
/*  89:134 */     return this.mAccel.getHeading();
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void stopAllListeners()
/*  93:    */   {
/*  94:142 */     this.mAccel.stopAllListeners();
/*  95:    */   }
/*  96:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.controller.MraidSensor
 * JD-Core Version:    0.7.0.1
 */