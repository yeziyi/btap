/*   1:    */ package com.tapjoy.mraid.controller;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.content.IntentFilter;
/*   5:    */ import android.net.ConnectivityManager;
/*   6:    */ import android.net.NetworkInfo;
/*   7:    */ import com.tapjoy.TapjoyLog;
/*   8:    */ import com.tapjoy.mraid.util.NetworkBroadcastReceiver;
/*   9:    */ import com.tapjoy.mraid.view.MraidView;
/*  10:    */ 
/*  11:    */ public class Network
/*  12:    */   extends Abstract
/*  13:    */ {
/*  14:    */   private static final String TAG = "MRAID Network";
/*  15:    */   private ConnectivityManager mConnectivityManager;
/*  16:    */   private int mNetworkListenerCount;
/*  17:    */   private NetworkBroadcastReceiver mBroadCastReceiver;
/*  18:    */   private IntentFilter mFilter;
/*  19:    */   
/*  20:    */   public Network(MraidView adView, Context context)
/*  21:    */   {
/*  22: 31 */     super(adView, context);
/*  23: 32 */     this.mConnectivityManager = ((ConnectivityManager)context.getSystemService("connectivity"));
/*  24:    */   }
/*  25:    */   
/*  26:    */   public String getNetwork()
/*  27:    */   {
/*  28: 43 */     NetworkInfo ni = null;
/*  29:    */     try
/*  30:    */     {
/*  31: 46 */       ni = this.mConnectivityManager.getActiveNetworkInfo();
/*  32:    */     }
/*  33:    */     catch (Exception e)
/*  34:    */     {
/*  35: 50 */       e.printStackTrace();
/*  36:    */     }
/*  37: 53 */     String networkType = "unknown";
/*  38: 54 */     if (ni == null) {
/*  39: 55 */       networkType = "offline";
/*  40:    */     } else {
/*  41: 58 */       switch (1.$SwitchMap$android$net$NetworkInfo$State[ni.getState().ordinal()])
/*  42:    */       {
/*  43:    */       case 1: 
/*  44: 60 */         networkType = "unknown";
/*  45: 61 */         break;
/*  46:    */       case 2: 
/*  47: 63 */         networkType = "offline";
/*  48: 64 */         break;
/*  49:    */       default: 
/*  50: 66 */         int type = ni.getType();
/*  51: 67 */         if (type == 0) {
/*  52: 68 */           networkType = "cell";
/*  53: 69 */         } else if (type == 1) {
/*  54: 70 */           networkType = "wifi";
/*  55:    */         }
/*  56:    */         break;
/*  57:    */       }
/*  58:    */     }
/*  59: 73 */     TapjoyLog.d("MRAID Network", "getNetwork: " + networkType);
/*  60: 74 */     return networkType;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void startNetworkListener()
/*  64:    */   {
/*  65: 81 */     if (this.mNetworkListenerCount == 0)
/*  66:    */     {
/*  67: 82 */       this.mBroadCastReceiver = new NetworkBroadcastReceiver(this);
/*  68: 83 */       this.mFilter = new IntentFilter();
/*  69: 84 */       this.mFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
/*  70:    */     }
/*  71: 86 */     this.mNetworkListenerCount += 1;
/*  72: 87 */     this.mContext.registerReceiver(this.mBroadCastReceiver, this.mFilter);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void stopNetworkListener()
/*  76:    */   {
/*  77: 94 */     this.mNetworkListenerCount -= 1;
/*  78: 95 */     if (this.mNetworkListenerCount == 0)
/*  79:    */     {
/*  80: 96 */       this.mContext.unregisterReceiver(this.mBroadCastReceiver);
/*  81: 97 */       this.mBroadCastReceiver = null;
/*  82: 98 */       this.mFilter = null;
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void onConnectionChanged()
/*  87:    */   {
/*  88:106 */     String script = "window.mraidview.fireChangeEvent({ network: '" + getNetwork() + "'});";
/*  89:107 */     TapjoyLog.d("MRAID Network", script);
/*  90:108 */     this.mMraidView.injectMraidJavaScript(script);
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void stopAllListeners()
/*  94:    */   {
/*  95:114 */     this.mNetworkListenerCount = 0;
/*  96:    */     try
/*  97:    */     {
/*  98:116 */       this.mContext.unregisterReceiver(this.mBroadCastReceiver);
/*  99:    */     }
/* 100:    */     catch (Exception e) {}
/* 101:    */   }
/* 102:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.controller.Network
 * JD-Core Version:    0.7.0.1
 */