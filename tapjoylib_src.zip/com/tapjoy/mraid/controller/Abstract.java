/*   1:    */ package com.tapjoy.mraid.controller;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.os.Parcel;
/*   5:    */ import android.os.Parcelable;
/*   6:    */ import android.os.Parcelable.Creator;
/*   7:    */ import com.tapjoy.mraid.util.NavigationStringEnum;
/*   8:    */ import com.tapjoy.mraid.util.TransitionStringEnum;
/*   9:    */ import com.tapjoy.mraid.view.MraidView;
/*  10:    */ import java.lang.reflect.Field;
/*  11:    */ import java.lang.reflect.Type;
/*  12:    */ import org.json.JSONException;
/*  13:    */ import org.json.JSONObject;
/*  14:    */ 
/*  15:    */ public abstract class Abstract
/*  16:    */ {
/*  17:    */   protected MraidView mMraidView;
/*  18:    */   protected Context mContext;
/*  19:    */   private static final String STRING_TYPE = "class java.lang.String";
/*  20:    */   private static final String INT_TYPE = "int";
/*  21:    */   private static final String BOOLEAN_TYPE = "boolean";
/*  22:    */   private static final String FLOAT_TYPE = "float";
/*  23:    */   private static final String NAVIGATION_TYPE = "class com.tapjoy.mraid.util.NavigationStringEnum";
/*  24:    */   private static final String TRANSITION_TYPE = "class com.tapjoy.mraid.util.TransitionStringEnum";
/*  25:    */   public static final String FULL_SCREEN = "fullscreen";
/*  26:    */   public static final String EXIT = "exit";
/*  27:    */   public static final String STYLE_NORMAL = "normal";
/*  28:    */   
/*  29:    */   public static class PlayerProperties
/*  30:    */     extends Abstract.ReflectedParcelable
/*  31:    */   {
/*  32:    */     public PlayerProperties()
/*  33:    */     {
/*  34: 50 */       this.autoPlay = (this.showControl = 1);
/*  35: 51 */       this.doLoop = (this.audioMuted = 0);
/*  36: 52 */       this.startStyle = (this.stopStyle = "normal");
/*  37: 53 */       this.inline = false;
/*  38:    */     }
/*  39:    */     
/*  40: 59 */     public static final Parcelable.Creator<PlayerProperties> CREATOR = new Parcelable.Creator()
/*  41:    */     {
/*  42:    */       public Abstract.PlayerProperties createFromParcel(Parcel in)
/*  43:    */       {
/*  44: 61 */         return new Abstract.PlayerProperties(in);
/*  45:    */       }
/*  46:    */       
/*  47:    */       public Abstract.PlayerProperties[] newArray(int size)
/*  48:    */       {
/*  49: 65 */         return new Abstract.PlayerProperties[size];
/*  50:    */       }
/*  51:    */     };
/*  52:    */     public boolean autoPlay;
/*  53:    */     public boolean showControl;
/*  54:    */     public boolean doLoop;
/*  55:    */     public boolean audioMuted;
/*  56:    */     public boolean inline;
/*  57:    */     public String stopStyle;
/*  58:    */     public String startStyle;
/*  59:    */     
/*  60:    */     public PlayerProperties(Parcel in)
/*  61:    */     {
/*  62: 70 */       super();
/*  63:    */     }
/*  64:    */     
/*  65:    */     public void setStopStyle(String style)
/*  66:    */     {
/*  67: 78 */       this.stopStyle = style;
/*  68:    */     }
/*  69:    */     
/*  70:    */     public void setProperties(boolean audioMuted, boolean autoPlay, boolean controls, boolean inline, boolean loop, String startStyle, String stopStyle)
/*  71:    */     {
/*  72: 88 */       this.autoPlay = autoPlay;
/*  73: 89 */       this.showControl = controls;
/*  74: 90 */       this.doLoop = loop;
/*  75: 91 */       this.audioMuted = audioMuted;
/*  76: 92 */       this.startStyle = startStyle;
/*  77: 93 */       this.stopStyle = stopStyle;
/*  78: 94 */       this.inline = inline;
/*  79:    */     }
/*  80:    */     
/*  81:    */     public void muteAudio()
/*  82:    */     {
/*  83:102 */       this.audioMuted = true;
/*  84:    */     }
/*  85:    */     
/*  86:    */     public boolean isAutoPlay()
/*  87:    */     {
/*  88:110 */       return this.autoPlay == true;
/*  89:    */     }
/*  90:    */     
/*  91:    */     public boolean showControl()
/*  92:    */     {
/*  93:117 */       return this.showControl;
/*  94:    */     }
/*  95:    */     
/*  96:    */     public boolean doLoop()
/*  97:    */     {
/*  98:125 */       return this.doLoop;
/*  99:    */     }
/* 100:    */     
/* 101:    */     public boolean doMute()
/* 102:    */     {
/* 103:132 */       return this.audioMuted;
/* 104:    */     }
/* 105:    */     
/* 106:    */     public boolean exitOnComplete()
/* 107:    */     {
/* 108:140 */       return this.stopStyle.equalsIgnoreCase("exit");
/* 109:    */     }
/* 110:    */     
/* 111:    */     public boolean isFullScreen()
/* 112:    */     {
/* 113:148 */       return this.startStyle.equalsIgnoreCase("fullscreen");
/* 114:    */     }
/* 115:    */   }
/* 116:    */   
/* 117:    */   public static class Dimensions
/* 118:    */     extends Abstract.ReflectedParcelable
/* 119:    */   {
/* 120:    */     public Dimensions()
/* 121:    */     {
/* 122:164 */       this.x = -1;
/* 123:165 */       this.y = -1;
/* 124:166 */       this.width = -1;
/* 125:167 */       this.height = -1;
/* 126:    */     }
/* 127:    */     
/* 128:173 */     public static final Parcelable.Creator<Dimensions> CREATOR = new Parcelable.Creator()
/* 129:    */     {
/* 130:    */       public Abstract.Dimensions createFromParcel(Parcel in)
/* 131:    */       {
/* 132:175 */         return new Abstract.Dimensions(in);
/* 133:    */       }
/* 134:    */       
/* 135:    */       public Abstract.Dimensions[] newArray(int size)
/* 136:    */       {
/* 137:179 */         return new Abstract.Dimensions[size];
/* 138:    */       }
/* 139:    */     };
/* 140:    */     public int x;
/* 141:    */     public int y;
/* 142:    */     public int width;
/* 143:    */     public int height;
/* 144:    */     
/* 145:    */     protected Dimensions(Parcel in)
/* 146:    */     {
/* 147:189 */       super();
/* 148:    */     }
/* 149:    */   }
/* 150:    */   
/* 151:    */   public static class Properties
/* 152:    */     extends Abstract.ReflectedParcelable
/* 153:    */   {
/* 154:    */     protected Properties(Parcel in)
/* 155:    */     {
/* 156:211 */       super();
/* 157:    */     }
/* 158:    */     
/* 159:    */     public Properties()
/* 160:    */     {
/* 161:218 */       this.useBackground = false;
/* 162:219 */       this.backgroundColor = 0;
/* 163:220 */       this.backgroundOpacity = 0.0F;
/* 164:221 */       this.isModal = false;
/* 165:222 */       this.lockOrientation = false;
/* 166:223 */       this.useCustomClose = false;
/* 167:    */     }
/* 168:    */     
/* 169:229 */     public static final Parcelable.Creator<Properties> CREATOR = new Parcelable.Creator()
/* 170:    */     {
/* 171:    */       public Abstract.Properties createFromParcel(Parcel in)
/* 172:    */       {
/* 173:231 */         return new Abstract.Properties(in);
/* 174:    */       }
/* 175:    */       
/* 176:    */       public Abstract.Properties[] newArray(int size)
/* 177:    */       {
/* 178:235 */         return new Abstract.Properties[size];
/* 179:    */       }
/* 180:    */     };
/* 181:    */     public boolean useBackground;
/* 182:    */     public int backgroundColor;
/* 183:    */     public float backgroundOpacity;
/* 184:    */     public boolean isModal;
/* 185:    */     public boolean lockOrientation;
/* 186:    */     public boolean useCustomClose;
/* 187:    */   }
/* 188:    */   
/* 189:    */   public Abstract(MraidView adView, Context context)
/* 190:    */   {
/* 191:255 */     this.mMraidView = adView;
/* 192:256 */     this.mContext = context;
/* 193:    */   }
/* 194:    */   
/* 195:    */   protected static Object getFromJSON(JSONObject json, Class<?> c)
/* 196:    */     throws IllegalAccessException, InstantiationException, NumberFormatException, NullPointerException
/* 197:    */   {
/* 198:272 */     Field[] fields = null;
/* 199:273 */     fields = c.getDeclaredFields();
/* 200:274 */     Object obj = c.newInstance();
/* 201:276 */     for (int i = 0; i < fields.length; i++)
/* 202:    */     {
/* 203:277 */       Field f = fields[i];
/* 204:278 */       String name = f.getName();
/* 205:279 */       String JSONName = name.replace('_', '-');
/* 206:280 */       Type type = f.getType();
/* 207:281 */       String typeStr = type.toString();
/* 208:    */       try
/* 209:    */       {
/* 210:283 */         if (typeStr.equals("int"))
/* 211:    */         {
/* 212:284 */           String value = json.getString(JSONName).toLowerCase();
/* 213:285 */           int iVal = 0;
/* 214:286 */           if (value.startsWith("#"))
/* 215:    */           {
/* 216:287 */             iVal = -1;
/* 217:    */             try
/* 218:    */             {
/* 219:289 */               if (value.startsWith("#0x")) {
/* 220:290 */                 iVal = Integer.decode(value.substring(1)).intValue();
/* 221:    */               } else {
/* 222:293 */                 iVal = Integer.parseInt(value.substring(1), 16);
/* 223:    */               }
/* 224:    */             }
/* 225:    */             catch (NumberFormatException e) {}
/* 226:    */           }
/* 227:    */           else
/* 228:    */           {
/* 229:300 */             iVal = Integer.parseInt(value);
/* 230:    */           }
/* 231:302 */           f.set(obj, Integer.valueOf(iVal));
/* 232:    */         }
/* 233:303 */         else if (typeStr.equals("class java.lang.String"))
/* 234:    */         {
/* 235:304 */           String value = json.getString(JSONName);
/* 236:305 */           f.set(obj, value);
/* 237:    */         }
/* 238:306 */         else if (typeStr.equals("boolean"))
/* 239:    */         {
/* 240:307 */           boolean value = json.getBoolean(JSONName);
/* 241:308 */           f.set(obj, Boolean.valueOf(value));
/* 242:    */         }
/* 243:309 */         else if (typeStr.equals("float"))
/* 244:    */         {
/* 245:310 */           float value = Float.parseFloat(json.getString(JSONName));
/* 246:311 */           f.set(obj, Float.valueOf(value));
/* 247:    */         }
/* 248:312 */         else if (typeStr.equals("class com.tapjoy.mraid.util.NavigationStringEnum"))
/* 249:    */         {
/* 250:313 */           NavigationStringEnum value = NavigationStringEnum.fromString(json.getString(JSONName));
/* 251:314 */           f.set(obj, value);
/* 252:    */         }
/* 253:315 */         else if (typeStr.equals("class com.tapjoy.mraid.util.TransitionStringEnum"))
/* 254:    */         {
/* 255:316 */           TransitionStringEnum value = TransitionStringEnum.fromString(json.getString(JSONName));
/* 256:317 */           f.set(obj, value);
/* 257:    */         }
/* 258:    */       }
/* 259:    */       catch (JSONException e)
/* 260:    */       {
/* 261:321 */         e.printStackTrace();
/* 262:    */       }
/* 263:    */     }
/* 264:325 */     return obj;
/* 265:    */   }
/* 266:    */   
/* 267:    */   public abstract void stopAllListeners();
/* 268:    */   
/* 269:    */   public static class ReflectedParcelable
/* 270:    */     implements Parcelable
/* 271:    */   {
/* 272:    */     public ReflectedParcelable() {}
/* 273:    */     
/* 274:    */     public int describeContents()
/* 275:    */     {
/* 276:345 */       return 0;
/* 277:    */     }
/* 278:    */     
/* 279:    */     protected ReflectedParcelable(Parcel in)
/* 280:    */     {
/* 281:354 */       Field[] fields = null;
/* 282:355 */       Class<?> c = getClass();
/* 283:356 */       fields = c.getDeclaredFields();
/* 284:    */       try
/* 285:    */       {
/* 286:359 */         Object obj = this;
/* 287:360 */         for (int i = 0; i < fields.length; i++)
/* 288:    */         {
/* 289:361 */           Field f = fields[i];
/* 290:    */           
/* 291:363 */           Class<?> type = f.getType();
/* 292:365 */           if (type.isEnum())
/* 293:    */           {
/* 294:366 */             String typeStr = type.toString();
/* 295:367 */             if (typeStr.equals("class com.tapjoy.mraid.util.NavigationStringEnum")) {
/* 296:368 */               f.set(obj, NavigationStringEnum.fromString(in.readString()));
/* 297:369 */             } else if (typeStr.equals("class com.tapjoy.mraid.util.TransitionStringEnum")) {
/* 298:370 */               f.set(obj, TransitionStringEnum.fromString(in.readString()));
/* 299:    */             }
/* 300:    */           }
/* 301:    */           else
/* 302:    */           {
/* 303:373 */             Object dt = f.get(this);
/* 304:374 */             if (!(dt instanceof Parcelable.Creator)) {
/* 305:375 */               f.set(obj, in.readValue(null));
/* 306:    */             }
/* 307:    */           }
/* 308:    */         }
/* 309:    */       }
/* 310:    */       catch (IllegalArgumentException e)
/* 311:    */       {
/* 312:382 */         e.printStackTrace();
/* 313:    */       }
/* 314:    */       catch (IllegalAccessException e)
/* 315:    */       {
/* 316:385 */         e.printStackTrace();
/* 317:    */       }
/* 318:    */     }
/* 319:    */     
/* 320:    */     public void writeToParcel(Parcel out, int flags1)
/* 321:    */     {
/* 322:393 */       Field[] fields = null;
/* 323:394 */       Class<?> c = getClass();
/* 324:395 */       fields = c.getDeclaredFields();
/* 325:    */       try
/* 326:    */       {
/* 327:397 */         for (int i = 0; i < fields.length; i++)
/* 328:    */         {
/* 329:398 */           Field f = fields[i];
/* 330:399 */           Class<?> type = f.getType();
/* 331:401 */           if (type.isEnum())
/* 332:    */           {
/* 333:402 */             String typeStr = type.toString();
/* 334:403 */             if (typeStr.equals("class com.tapjoy.mraid.util.NavigationStringEnum")) {
/* 335:404 */               out.writeString(((NavigationStringEnum)f.get(this)).getText());
/* 336:405 */             } else if (typeStr.equals("class com.tapjoy.mraid.util.TransitionStringEnum")) {
/* 337:406 */               out.writeString(((TransitionStringEnum)f.get(this)).getText());
/* 338:    */             }
/* 339:    */           }
/* 340:    */           else
/* 341:    */           {
/* 342:409 */             Object dt = f.get(this);
/* 343:410 */             if (!(dt instanceof Parcelable.Creator)) {
/* 344:411 */               out.writeValue(dt);
/* 345:    */             }
/* 346:    */           }
/* 347:    */         }
/* 348:    */       }
/* 349:    */       catch (IllegalArgumentException e)
/* 350:    */       {
/* 351:417 */         e.printStackTrace();
/* 352:    */       }
/* 353:    */       catch (IllegalAccessException e)
/* 354:    */       {
/* 355:420 */         e.printStackTrace();
/* 356:    */       }
/* 357:    */     }
/* 358:    */   }
/* 359:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.controller.Abstract
 * JD-Core Version:    0.7.0.1
 */