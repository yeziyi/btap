/*   1:    */ package com.tapjoy.mraid.controller;
/*   2:    */ 
/*   3:    */ import android.R.raw;
/*   4:    */ import android.app.Activity;
/*   5:    */ import android.content.Context;
/*   6:    */ import android.content.Intent;
/*   7:    */ import android.content.IntentFilter;
/*   8:    */ import android.content.pm.PackageManager;
/*   9:    */ import android.content.pm.ResolveInfo;
/*  10:    */ import android.net.Uri;
/*  11:    */ import android.util.DisplayMetrics;
/*  12:    */ import android.view.WindowManager;
/*  13:    */ import android.webkit.JavascriptInterface;
/*  14:    */ import android.webkit.URLUtil;
/*  15:    */ import com.tapjoy.TapjoyLog;
/*  16:    */ import com.tapjoy.mraid.util.ConfigBroadcastReceiver;
/*  17:    */ import com.tapjoy.mraid.view.MraidView;
/*  18:    */ import java.lang.reflect.Field;
/*  19:    */ import java.util.List;
/*  20:    */ import org.json.JSONException;
/*  21:    */ import org.json.JSONObject;
/*  22:    */ 
/*  23:    */ public class Display
/*  24:    */   extends Abstract
/*  25:    */ {
/*  26:    */   private static final String TAG = "MRAID Display";
/*  27:    */   private WindowManager mWindowManager;
/*  28: 37 */   private boolean bMaxSizeSet = false;
/*  29: 38 */   private int mMaxWidth = -1;
/*  30: 39 */   private int mMaxHeight = -1;
/*  31:    */   private ConfigBroadcastReceiver mBroadCastReceiver;
/*  32:    */   private float mDensity;
/*  33:    */   private Context context;
/*  34:    */   
/*  35:    */   public Display(MraidView adView, Context c)
/*  36:    */   {
/*  37: 54 */     super(adView, c);
/*  38: 55 */     this.context = c;
/*  39: 56 */     DisplayMetrics metrics = new DisplayMetrics();
/*  40: 57 */     this.mWindowManager = ((WindowManager)c.getSystemService("window"));
/*  41:    */     
/*  42: 59 */     this.mWindowManager.getDefaultDisplay().getMetrics(metrics);
/*  43: 60 */     this.mDensity = metrics.density;
/*  44:    */   }
/*  45:    */   
/*  46:    */   @JavascriptInterface
/*  47:    */   public void resize(String properties)
/*  48:    */   {
/*  49: 75 */     int width = 0;int height = 0;int offsetX = 0;int offsetY = 0;
/*  50: 76 */     String customClosePosition = null;
/*  51: 77 */     boolean allowOffScreen = true;
/*  52:    */     try
/*  53:    */     {
/*  54: 81 */       JSONObject propertiesJSON = new JSONObject(properties);
/*  55: 82 */       width = propertiesJSON.getInt("width");
/*  56: 83 */       height = propertiesJSON.getInt("height");
/*  57: 84 */       offsetX = propertiesJSON.getInt("offsetX");
/*  58: 85 */       offsetY = propertiesJSON.getInt("offsetY");
/*  59: 86 */       customClosePosition = propertiesJSON.getString("customClosePosition");
/*  60: 87 */       allowOffScreen = propertiesJSON.getBoolean("allowOffScreen");
/*  61:    */     }
/*  62:    */     catch (Exception e) {}
/*  63: 91 */     this.mMraidView.resize((int)(this.mDensity * width), (int)(this.mDensity * height), offsetX, offsetY, customClosePosition, allowOffScreen);
/*  64:    */   }
/*  65:    */   
/*  66:    */   @JavascriptInterface
/*  67:    */   public void open(String url, boolean back, boolean forward, boolean refresh)
/*  68:    */   {
/*  69:111 */     TapjoyLog.i("MRAID Display", "open: url: " + url + " back: " + back + " forward: " + forward + " refresh: " + refresh);
/*  70:113 */     if (!URLUtil.isValidUrl(url))
/*  71:    */     {
/*  72:115 */       TapjoyLog.i("MRAID Display", "invalid URL");
/*  73:    */       
/*  74:    */ 
/*  75:118 */       Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
/*  76:119 */       List<ResolveInfo> resInfo = this.context.getPackageManager().queryIntentActivities(intent, 0);
/*  77:122 */       if (resInfo.size() == 1)
/*  78:    */       {
/*  79:124 */         this.context.startActivity(intent);
/*  80:    */       }
/*  81:128 */       else if (resInfo.size() > 1)
/*  82:    */       {
/*  83:130 */         Intent i = Intent.createChooser(intent, "Select");
/*  84:131 */         ((Activity)this.context).startActivity(i);
/*  85:    */       }
/*  86:    */       else
/*  87:    */       {
/*  88:136 */         this.mMraidView.raiseError("Invalid url", "open");
/*  89:    */       }
/*  90:    */     }
/*  91:    */     else
/*  92:    */     {
/*  93:141 */       this.mMraidView.open(url, back, forward, refresh);
/*  94:    */     }
/*  95:    */   }
/*  96:    */   
/*  97:    */   @JavascriptInterface
/*  98:    */   public void useCustomClose(boolean input)
/*  99:    */   {
/* 100:148 */     if (input) {
/* 101:148 */       this.mMraidView.removeCloseImageButton();
/* 102:149 */     } else if (!input) {
/* 103:149 */       this.mMraidView.showCloseImageButton();
/* 104:    */     }
/* 105:    */   }
/* 106:    */   
/* 107:    */   @JavascriptInterface
/* 108:    */   public void openMap(String url, boolean fullscreen)
/* 109:    */   {
/* 110:162 */     TapjoyLog.d("MRAID Display", "openMap: url: " + url);
/* 111:163 */     this.mMraidView.openMap(url, fullscreen);
/* 112:    */   }
/* 113:    */   
/* 114:    */   @JavascriptInterface
/* 115:    */   public void setOrientationProperties(boolean allowOrientationChange, String forceOrientation)
/* 116:    */   {
/* 117:176 */     TapjoyLog.d("MRAID Display", "setOrientationProperties: allowOrientationChange: " + Boolean.toString(allowOrientationChange) + " forceOrientation: " + forceOrientation);
/* 118:177 */     this.mMraidView.setOrientationProperties(allowOrientationChange, forceOrientation);
/* 119:    */   }
/* 120:    */   
/* 121:    */   @JavascriptInterface
/* 122:    */   public void playAudio(String url, boolean autoPlay, boolean controls, boolean loop, boolean position, String startStyle, String stopStyle)
/* 123:    */   {
/* 124:202 */     TapjoyLog.d("MRAID Display", "playAudio: url: " + url + " autoPlay: " + autoPlay + " controls: " + controls + " loop: " + loop + " position: " + position + " startStyle: " + startStyle + " stopStyle: " + stopStyle);
/* 125:206 */     if (!URLUtil.isValidUrl(url)) {
/* 126:207 */       this.mMraidView.raiseError("Invalid url", "playAudio");
/* 127:    */     } else {
/* 128:209 */       this.mMraidView.playAudio(url, autoPlay, controls, loop, position, startStyle, stopStyle);
/* 129:    */     }
/* 130:    */   }
/* 131:    */   
/* 132:    */   @JavascriptInterface
/* 133:    */   public void playVideo(String url, boolean audioMuted, boolean autoPlay, boolean controls, boolean loop, int[] position, String startStyle, String stopStyle)
/* 134:    */   {
/* 135:241 */     TapjoyLog.d("MRAID Display", "playVideo: url: " + url + " audioMuted: " + audioMuted + " autoPlay: " + autoPlay + " controls: " + controls + " loop: " + loop + " x: " + position[0] + " y: " + position[1] + " width: " + position[2] + " height: " + position[3] + " startStyle: " + startStyle + " stopStyle: " + stopStyle);
/* 136:    */     
/* 137:    */ 
/* 138:    */ 
/* 139:    */ 
/* 140:    */ 
/* 141:247 */     Abstract.Dimensions d = null;
/* 142:248 */     if (position[0] != -1)
/* 143:    */     {
/* 144:249 */       d = new Abstract.Dimensions();
/* 145:250 */       d.x = position[0];
/* 146:251 */       d.y = position[1];
/* 147:252 */       d.width = position[2];
/* 148:253 */       d.height = position[3];
/* 149:254 */       d = getDeviceDimensions(d);
/* 150:    */     }
/* 151:257 */     String fileName = null;
/* 152:258 */     int field = 0;
/* 153:260 */     if (url.contains("android.resource"))
/* 154:    */     {
/* 155:262 */       int start = url.lastIndexOf("/") + 1;
/* 156:263 */       int end = url.lastIndexOf(".");
/* 157:264 */       fileName = url.substring(start, end);
/* 158:    */       try
/* 159:    */       {
/* 160:266 */         field = R.raw.class.getField(fileName).getInt(null);
/* 161:    */       }
/* 162:    */       catch (Exception e)
/* 163:    */       {
/* 164:269 */         e.printStackTrace();
/* 165:    */       }
/* 166:271 */       String packageName = this.mContext.getPackageName();
/* 167:272 */       url = "android.resource://" + packageName + "/" + field;
/* 168:    */     }
/* 169:276 */     this.mMraidView.playVideo(url, false, true, true, false, d, "fullscreen", "exit");
/* 170:    */   }
/* 171:    */   
/* 172:    */   private Abstract.Dimensions getDeviceDimensions(Abstract.Dimensions d)
/* 173:    */   {
/* 174:288 */     d.width = ((int)Math.ceil(this.mDensity * d.width));
/* 175:289 */     d.height = ((int)Math.ceil(this.mDensity * d.height)); Abstract.Dimensions 
/* 176:290 */       tmp39_38 = d;tmp39_38.x = ((int)(tmp39_38.x * this.mDensity)); Abstract.Dimensions 
/* 177:291 */       tmp54_53 = d;tmp54_53.y = ((int)(tmp54_53.y * this.mDensity));
/* 178:292 */     if (d.height < 0) {
/* 179:293 */       d.height = this.mMraidView.getHeight();
/* 180:    */     }
/* 181:294 */     if (d.width < 0) {
/* 182:295 */       d.width = this.mMraidView.getWidth();
/* 183:    */     }
/* 184:296 */     int[] loc = new int[2];
/* 185:297 */     this.mMraidView.getLocationInWindow(loc);
/* 186:298 */     if (d.x < 0) {
/* 187:299 */       d.x = loc[0];
/* 188:    */     }
/* 189:300 */     if (d.y < 0)
/* 190:    */     {
/* 191:301 */       int topStuff = 0;
/* 192:302 */       d.y = (loc[1] - topStuff);
/* 193:    */     }
/* 194:304 */     return d;
/* 195:    */   }
/* 196:    */   
/* 197:    */   @JavascriptInterface
/* 198:    */   public void expand(String URL, String properties)
/* 199:    */   {
/* 200:319 */     TapjoyLog.d("MRAID Display", "expand: properties: " + properties + " url: " + URL);
/* 201:    */     try
/* 202:    */     {
/* 203:322 */       JSONObject propertiesJSON = new JSONObject(properties);
/* 204:323 */       JSONObject dimensions = new JSONObject();
/* 205:324 */       dimensions.put("width", propertiesJSON.get("width"));
/* 206:325 */       dimensions.put("height", propertiesJSON.get("height"));
/* 207:326 */       dimensions.put("x", 0);
/* 208:327 */       dimensions.put("y", 0);
/* 209:    */       
/* 210:329 */       Abstract.Dimensions d = (Abstract.Dimensions)getFromJSON(dimensions, Abstract.Dimensions.class);
/* 211:    */       
/* 212:    */ 
/* 213:332 */       this.mMraidView.expand(getDeviceDimensions(d), URL, (Abstract.Properties)getFromJSON(new JSONObject(properties), Abstract.Properties.class));
/* 214:    */     }
/* 215:    */     catch (NumberFormatException e)
/* 216:    */     {
/* 217:340 */       e.printStackTrace();
/* 218:    */     }
/* 219:    */     catch (NullPointerException e)
/* 220:    */     {
/* 221:343 */       e.printStackTrace();
/* 222:    */     }
/* 223:    */     catch (IllegalAccessException e)
/* 224:    */     {
/* 225:346 */       e.printStackTrace();
/* 226:    */     }
/* 227:    */     catch (InstantiationException e)
/* 228:    */     {
/* 229:349 */       e.printStackTrace();
/* 230:    */     }
/* 231:    */     catch (JSONException e)
/* 232:    */     {
/* 233:352 */       e.printStackTrace();
/* 234:    */     }
/* 235:    */   }
/* 236:    */   
/* 237:    */   @JavascriptInterface
/* 238:    */   public void close()
/* 239:    */   {
/* 240:361 */     TapjoyLog.d("MRAID Display", "close");
/* 241:362 */     this.mMraidView.close();
/* 242:    */   }
/* 243:    */   
/* 244:    */   @JavascriptInterface
/* 245:    */   public void hide()
/* 246:    */   {
/* 247:370 */     TapjoyLog.d("MRAID Display", "hide");
/* 248:371 */     this.mMraidView.hide();
/* 249:    */   }
/* 250:    */   
/* 251:    */   @JavascriptInterface
/* 252:    */   public void show()
/* 253:    */   {
/* 254:379 */     TapjoyLog.d("MRAID Display", "show");
/* 255:380 */     this.mMraidView.show();
/* 256:    */   }
/* 257:    */   
/* 258:    */   public boolean isVisible()
/* 259:    */   {
/* 260:389 */     return this.mMraidView.getVisibility() == 0;
/* 261:    */   }
/* 262:    */   
/* 263:    */   public String dimensions()
/* 264:    */   {
/* 265:398 */     return "{ \"top\" :" + (int)(this.mMraidView.getTop() / this.mDensity) + "," + "\"left\" :" + (int)(this.mMraidView.getLeft() / this.mDensity) + "," + "\"bottom\" :" + (int)(this.mMraidView.getBottom() / this.mDensity) + "," + "\"right\" :" + (int)(this.mMraidView.getRight() / this.mDensity) + "}";
/* 266:    */   }
/* 267:    */   
/* 268:    */   public int getOrientation()
/* 269:    */   {
/* 270:411 */     int orientation = this.mWindowManager.getDefaultDisplay().getOrientation();
/* 271:412 */     int ret = -1;
/* 272:413 */     switch (orientation)
/* 273:    */     {
/* 274:    */     case 0: 
/* 275:415 */       ret = 0;
/* 276:416 */       break;
/* 277:    */     case 1: 
/* 278:419 */       ret = 90;
/* 279:420 */       break;
/* 280:    */     case 2: 
/* 281:423 */       ret = 180;
/* 282:424 */       break;
/* 283:    */     case 3: 
/* 284:427 */       ret = 270;
/* 285:    */     }
/* 286:430 */     TapjoyLog.d("MRAID Display", "getOrientation: " + ret);
/* 287:431 */     return ret;
/* 288:    */   }
/* 289:    */   
/* 290:    */   public String getScreenSize()
/* 291:    */   {
/* 292:440 */     DisplayMetrics metrics = new DisplayMetrics();
/* 293:441 */     this.mWindowManager.getDefaultDisplay().getMetrics(metrics);
/* 294:    */     
/* 295:443 */     return "{ width: " + (int)Math.ceil(metrics.widthPixels / metrics.density) + ", " + "height: " + (int)Math.ceil(metrics.heightPixels / metrics.density) + "}";
/* 296:    */   }
/* 297:    */   
/* 298:    */   public String getSize()
/* 299:    */   {
/* 300:454 */     return this.mMraidView.getSize();
/* 301:    */   }
/* 302:    */   
/* 303:    */   public String getMaxSize()
/* 304:    */   {
/* 305:463 */     if (this.bMaxSizeSet) {
/* 306:464 */       return "{ width: " + this.mMaxWidth + ", " + "height: " + this.mMaxHeight + "}";
/* 307:    */     }
/* 308:467 */     return getScreenSize();
/* 309:    */   }
/* 310:    */   
/* 311:    */   public void setMaxSize(int w, int h)
/* 312:    */   {
/* 313:479 */     TapjoyLog.i("MRAID Display", "setMaxSize: " + w + "x" + h);
/* 314:480 */     this.bMaxSizeSet = true;
/* 315:481 */     this.mMaxWidth = w;
/* 316:482 */     this.mMaxHeight = h;
/* 317:    */   }
/* 318:    */   
/* 319:    */   public void onOrientationChanged(int orientation)
/* 320:    */   {
/* 321:492 */     String script = "window.mraidview.fireChangeEvent({ orientation: " + orientation + "});";
/* 322:    */     
/* 323:494 */     TapjoyLog.d("MRAID Display", script);
/* 324:495 */     this.mMraidView.injectMraidJavaScript(script);
/* 325:    */   }
/* 326:    */   
/* 327:    */   public void logHTML(String html)
/* 328:    */   {
/* 329:505 */     TapjoyLog.d("MRAID Display", html);
/* 330:    */   }
/* 331:    */   
/* 332:    */   public void stopAllListeners()
/* 333:    */   {
/* 334:515 */     stopConfigurationListener();
/* 335:516 */     this.mBroadCastReceiver = null;
/* 336:    */   }
/* 337:    */   
/* 338:    */   public void stopConfigurationListener()
/* 339:    */   {
/* 340:    */     try
/* 341:    */     {
/* 342:521 */       this.mContext.unregisterReceiver(this.mBroadCastReceiver);
/* 343:    */     }
/* 344:    */     catch (Exception e) {}
/* 345:    */   }
/* 346:    */   
/* 347:    */   public void startConfigurationListener()
/* 348:    */   {
/* 349:    */     try
/* 350:    */     {
/* 351:528 */       if (this.mBroadCastReceiver == null) {
/* 352:529 */         this.mBroadCastReceiver = new ConfigBroadcastReceiver(this);
/* 353:    */       }
/* 354:530 */       this.mContext.registerReceiver(this.mBroadCastReceiver, new IntentFilter("android.intent.action.CONFIGURATION_CHANGED"));
/* 355:    */     }
/* 356:    */     catch (Exception e) {}
/* 357:    */   }
/* 358:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.controller.Display
 * JD-Core Version:    0.7.0.1
 */