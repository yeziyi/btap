/*   1:    */ package com.tapjoy.mraid.controller;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.location.Location;
/*   5:    */ import android.location.LocationManager;
/*   6:    */ import com.tapjoy.TapjoyLog;
/*   7:    */ import com.tapjoy.mraid.listener.Loc;
/*   8:    */ import com.tapjoy.mraid.view.MraidView;
/*   9:    */ import java.util.Iterator;
/*  10:    */ import java.util.List;
/*  11:    */ 
/*  12:    */ public class MraidLocation
/*  13:    */   extends Abstract
/*  14:    */ {
/*  15:    */   private static final String TAG = "MRAID Location";
/*  16:    */   private LocationManager mLocationManager;
/*  17: 23 */   private boolean hasPermission = false;
/*  18: 24 */   final int INTERVAL = 1000;
/*  19:    */   private Loc mGps;
/*  20:    */   private Loc mNetwork;
/*  21:    */   private int mLocListenerCount;
/*  22: 28 */   private boolean allowLocationServices = false;
/*  23:    */   
/*  24:    */   public MraidLocation(MraidView adView, Context context)
/*  25:    */   {
/*  26: 37 */     super(adView, context);
/*  27:    */     try
/*  28:    */     {
/*  29: 39 */       this.mLocationManager = ((LocationManager)context.getSystemService("location"));
/*  30: 41 */       if (this.mLocationManager.getProvider("gps") != null) {
/*  31: 42 */         this.mGps = new Loc(context, 1000, this, "gps");
/*  32:    */       }
/*  33: 44 */       if (this.mLocationManager.getProvider("network") != null) {
/*  34: 45 */         this.mNetwork = new Loc(context, 1000, this, "network");
/*  35:    */       }
/*  36: 46 */       this.hasPermission = true;
/*  37:    */     }
/*  38:    */     catch (SecurityException e) {}
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void allowLocationServices(boolean flag)
/*  42:    */   {
/*  43: 56 */     this.allowLocationServices = flag;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public boolean allowLocationServices()
/*  47:    */   {
/*  48: 63 */     return this.allowLocationServices;
/*  49:    */   }
/*  50:    */   
/*  51:    */   private static String formatLocation(Location loc)
/*  52:    */   {
/*  53: 68 */     return "{ lat: " + loc.getLatitude() + ", lon: " + loc.getLongitude() + ", acc: " + loc.getAccuracy() + "}";
/*  54:    */   }
/*  55:    */   
/*  56:    */   public String getLocation()
/*  57:    */   {
/*  58: 77 */     TapjoyLog.d("MRAID Location", "getLocation: hasPermission: " + this.hasPermission);
/*  59: 78 */     if (!this.hasPermission) {
/*  60: 79 */       return null;
/*  61:    */     }
/*  62: 81 */     List<String> providers = this.mLocationManager.getProviders(true);
/*  63: 82 */     Iterator<String> provider = providers.iterator();
/*  64: 83 */     Location lastKnown = null;
/*  65: 84 */     while (provider.hasNext())
/*  66:    */     {
/*  67: 85 */       lastKnown = this.mLocationManager.getLastKnownLocation((String)provider.next());
/*  68: 86 */       if (lastKnown != null) {
/*  69:    */         break;
/*  70:    */       }
/*  71:    */     }
/*  72: 90 */     TapjoyLog.d("MRAID Location", "getLocation: " + lastKnown);
/*  73: 91 */     if (lastKnown != null) {
/*  74: 92 */       return formatLocation(lastKnown);
/*  75:    */     }
/*  76: 94 */     return null;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void startLocationListener()
/*  80:    */   {
/*  81:101 */     if (this.mLocListenerCount == 0)
/*  82:    */     {
/*  83:103 */       if (this.mNetwork != null) {
/*  84:104 */         this.mNetwork.start();
/*  85:    */       }
/*  86:105 */       if (this.mGps != null) {
/*  87:106 */         this.mGps.start();
/*  88:    */       }
/*  89:    */     }
/*  90:108 */     this.mLocListenerCount += 1;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void stopLocationListener()
/*  94:    */   {
/*  95:115 */     this.mLocListenerCount -= 1;
/*  96:116 */     if (this.mLocListenerCount == 0)
/*  97:    */     {
/*  98:118 */       if (this.mNetwork != null) {
/*  99:119 */         this.mNetwork.stop();
/* 100:    */       }
/* 101:120 */       if (this.mGps != null) {
/* 102:121 */         this.mGps.stop();
/* 103:    */       }
/* 104:    */     }
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void success(Location loc)
/* 108:    */   {
/* 109:131 */     String script = "window.mraidview.fireChangeEvent({ location: " + formatLocation(loc) + "})";
/* 110:132 */     TapjoyLog.d("MRAID Location", script);
/* 111:133 */     this.mMraidView.injectMraidJavaScript(script);
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void fail()
/* 115:    */   {
/* 116:140 */     TapjoyLog.e("MRAID Location", "Location can't be determined");
/* 117:141 */     this.mMraidView.injectMraidJavaScript("window.mraidview.fireErrorEvent(\"Location cannot be identified\", \"OrmmaLocationController\")");
/* 118:    */   }
/* 119:    */   
/* 120:    */   public void stopAllListeners()
/* 121:    */   {
/* 122:149 */     this.mLocListenerCount = 0;
/* 123:    */     try
/* 124:    */     {
/* 125:151 */       this.mGps.stop();
/* 126:    */     }
/* 127:    */     catch (Exception e) {}
/* 128:    */     try
/* 129:    */     {
/* 130:155 */       this.mNetwork.stop();
/* 131:    */     }
/* 132:    */     catch (Exception e) {}
/* 133:    */   }
/* 134:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.controller.MraidLocation
 * JD-Core Version:    0.7.0.1
 */