/*   1:    */ package com.tapjoy.mraid.controller;
/*   2:    */ 
/*   3:    */ import android.annotation.TargetApi;
/*   4:    */ import android.app.AlertDialog;
/*   5:    */ import android.app.AlertDialog.Builder;
/*   6:    */ import android.content.ContentResolver;
/*   7:    */ import android.content.ContentValues;
/*   8:    */ import android.content.Context;
/*   9:    */ import android.content.DialogInterface;
/*  10:    */ import android.content.DialogInterface.OnClickListener;
/*  11:    */ import android.content.Intent;
/*  12:    */ import android.database.Cursor;
/*  13:    */ import android.net.Uri;
/*  14:    */ import android.os.Build.VERSION;
/*  15:    */ import android.provider.CalendarContract.Events;
/*  16:    */ import android.text.TextUtils;
/*  17:    */ import android.util.Log;
/*  18:    */ import android.webkit.JavascriptInterface;
/*  19:    */ import android.widget.ListAdapter;
/*  20:    */ import android.widget.SimpleAdapter;
/*  21:    */ import android.widget.Toast;
/*  22:    */ import com.tapjoy.TapjoyLog;
/*  23:    */ import com.tapjoy.mraid.view.MraidView;
/*  24:    */ import java.io.IOException;
/*  25:    */ import java.io.InputStream;
/*  26:    */ import java.util.ArrayList;
/*  27:    */ import java.util.Calendar;
/*  28:    */ import java.util.HashMap;
/*  29:    */ import java.util.List;
/*  30:    */ import java.util.Map;
/*  31:    */ import org.json.JSONException;
/*  32:    */ import org.json.JSONObject;
/*  33:    */ 
/*  34:    */ @TargetApi(14)
/*  35:    */ public class Utility
/*  36:    */   extends Abstract
/*  37:    */ {
/*  38:    */   private static final String TAG = "MRAID Utility";
/*  39:    */   private Assets mAssetController;
/*  40:    */   private Display mDisplayController;
/*  41:    */   private MraidLocation mLocationController;
/*  42:    */   private Network mNetworkController;
/*  43:    */   private MraidSensor mSensorController;
/*  44:    */   
/*  45:    */   public Utility(MraidView adView, Context context)
/*  46:    */   {
/*  47: 65 */     super(adView, context);
/*  48: 66 */     this.mAssetController = new Assets(adView, context);
/*  49: 67 */     this.mDisplayController = new Display(adView, context);
/*  50: 68 */     this.mLocationController = new MraidLocation(adView, context);
/*  51: 69 */     this.mNetworkController = new Network(adView, context);
/*  52: 70 */     this.mSensorController = new MraidSensor(adView, context);
/*  53:    */     
/*  54:    */ 
/*  55: 73 */     adView.addJavascriptInterface(this.mAssetController, "MRAIDAssetsControllerBridge");
/*  56: 74 */     adView.addJavascriptInterface(this.mDisplayController, "MRAIDDisplayControllerBridge");
/*  57: 75 */     adView.addJavascriptInterface(this.mLocationController, "MRAIDLocationControllerBridge");
/*  58: 76 */     adView.addJavascriptInterface(this.mNetworkController, "MRAIDNetworkControllerBridge");
/*  59: 77 */     adView.addJavascriptInterface(this.mSensorController, "MRAIDSensorControllerBridge");
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void init(float density)
/*  63:    */   {
/*  64: 88 */     String injection = "window.mraidview.fireChangeEvent({ state: 'default', network: '" + this.mNetworkController.getNetwork() + "'," + " size: " + this.mDisplayController.getSize() + "," + " placement: " + "'" + this.mMraidView.getPlacementType() + "'," + " maxSize: " + this.mDisplayController.getMaxSize() + ",expandProperties: " + this.mDisplayController.getMaxSize() + "," + " screenSize: " + this.mDisplayController.getScreenSize() + "," + " defaultPosition: { x:" + (int)(this.mMraidView.getLeft() / density) + ", y: " + (int)(this.mMraidView.getTop() / density) + ", width: " + (int)(this.mMraidView.getWidth() / density) + ", height: " + (int)(this.mMraidView.getHeight() / density) + " }," + " orientation:" + this.mDisplayController.getOrientation() + "," + getSupports() + ",viewable:true });";
/*  65:    */     
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73: 97 */     Log.d("MRAID Utility", "init: injection: " + injection);
/*  74: 98 */     this.mMraidView.injectMraidJavaScript(injection);
/*  75: 99 */     ready();
/*  76:    */   }
/*  77:    */   
/*  78:    */   private String getSupports()
/*  79:    */   {
/*  80:109 */     String supports = "supports: [ 'level-1', 'level-2', 'screen', 'orientation', 'network'";
/*  81:    */     
/*  82:111 */     boolean p = (this.mLocationController.allowLocationServices()) && ((this.mContext.checkCallingOrSelfPermission("android.permission.ACCESS_COARSE_LOCATION") == 0) || (this.mContext.checkCallingOrSelfPermission("android.permission.ACCESS_FINE_LOCATION") == 0));
/*  83:114 */     if (p) {
/*  84:115 */       supports = supports + ", 'location'";
/*  85:    */     }
/*  86:117 */     p = this.mContext.checkCallingOrSelfPermission("android.permission.SEND_SMS") == 0;
/*  87:118 */     if (p) {
/*  88:119 */       supports = supports + ", 'sms'";
/*  89:    */     }
/*  90:121 */     p = this.mContext.checkCallingOrSelfPermission("android.permission.CALL_PHONE") == 0;
/*  91:122 */     if (p) {
/*  92:123 */       supports = supports + ", 'phone'";
/*  93:    */     }
/*  94:125 */     p = (this.mContext.checkCallingOrSelfPermission("android.permission.WRITE_CALENDAR") == 0) && (this.mContext.checkCallingOrSelfPermission("android.permission.READ_CALENDAR") == 0) && (Build.VERSION.SDK_INT >= 14);
/*  95:129 */     if (p) {
/*  96:130 */       supports = supports + ", 'calendar'";
/*  97:    */     }
/*  98:132 */     supports = supports + ", 'video'";
/*  99:    */     
/* 100:134 */     supports = supports + ", 'audio'";
/* 101:    */     
/* 102:136 */     supports = supports + ", 'map'";
/* 103:    */     
/* 104:138 */     supports = supports + ", 'email' ]";
/* 105:139 */     TapjoyLog.d("MRAID Utility", "getSupports: " + supports);
/* 106:140 */     return supports;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public void ready()
/* 110:    */   {
/* 111:148 */     this.mMraidView.injectMraidJavaScript("mraid.setState(\"" + this.mMraidView.getState() + "\");");
/* 112:    */     
/* 113:150 */     this.mMraidView.injectMraidJavaScript("mraidview.fireReadyEvent();");
/* 114:    */   }
/* 115:    */   
/* 116:    */   @JavascriptInterface
/* 117:    */   public void sendSMS(String recipient, String body)
/* 118:    */   {
/* 119:161 */     TapjoyLog.d("MRAID Utility", "sendSMS: recipient: " + recipient + " body: " + body);
/* 120:162 */     Intent sendIntent = new Intent("android.intent.action.VIEW");
/* 121:163 */     sendIntent.putExtra("address", recipient);
/* 122:164 */     sendIntent.putExtra("sms_body", body);
/* 123:165 */     sendIntent.setType("vnd.android-dir/mms-sms");
/* 124:166 */     sendIntent.addFlags(268435456);
/* 125:167 */     this.mContext.startActivity(sendIntent);
/* 126:    */   }
/* 127:    */   
/* 128:    */   @JavascriptInterface
/* 129:    */   public void sendMail(String recipient, String subject, String body)
/* 130:    */   {
/* 131:179 */     TapjoyLog.d("MRAID Utility", "sendMail: recipient: " + recipient + " subject: " + subject + " body: " + body);
/* 132:180 */     Intent i = new Intent("android.intent.action.SEND");
/* 133:181 */     i.setType("plain/text");
/* 134:182 */     i.putExtra("android.intent.extra.EMAIL", new String[] { recipient });
/* 135:183 */     i.putExtra("android.intent.extra.SUBJECT", subject);
/* 136:184 */     i.putExtra("android.intent.extra.TEXT", body);
/* 137:185 */     i.addFlags(268435456);
/* 138:186 */     this.mContext.startActivity(i);
/* 139:    */   }
/* 140:    */   
/* 141:    */   private String createTelUrl(String number)
/* 142:    */   {
/* 143:196 */     if (TextUtils.isEmpty(number)) {
/* 144:197 */       return null;
/* 145:    */     }
/* 146:200 */     StringBuilder buf = new StringBuilder("tel:");
/* 147:201 */     buf.append(number);
/* 148:202 */     return buf.toString();
/* 149:    */   }
/* 150:    */   
/* 151:    */   @JavascriptInterface
/* 152:    */   public void makeCall(String number)
/* 153:    */   {
/* 154:212 */     TapjoyLog.d("MRAID Utility", "makeCall: number: " + number);
/* 155:213 */     String url = createTelUrl(number);
/* 156:214 */     if (url == null)
/* 157:    */     {
/* 158:215 */       this.mMraidView.raiseError("Bad Phone Number", "makeCall");
/* 159:    */     }
/* 160:    */     else
/* 161:    */     {
/* 162:218 */       Intent i = new Intent("android.intent.action.CALL", Uri.parse(url.toString()));
/* 163:219 */       i.addFlags(268435456);
/* 164:220 */       this.mContext.startActivity(i);
/* 165:    */     }
/* 166:    */   }
/* 167:    */   
/* 168:    */   @JavascriptInterface
/* 169:    */   public void mraidCreateEvent(String properties)
/* 170:    */   {
/* 171:232 */     String description = null;String location = null;String summary = null;
/* 172:233 */     String reminder = null;String status = null;
/* 173:235 */     if (Build.VERSION.SDK_INT < 14) {
/* 174:235 */       return;
/* 175:    */     }
/* 176:236 */     Calendar beginTime = Calendar.getInstance();
/* 177:237 */     Calendar endTime = Calendar.getInstance();
/* 178:    */     try
/* 179:    */     {
/* 180:239 */       JSONObject propertiesJSON = new JSONObject(properties);
/* 181:240 */       JSONObject start = propertiesJSON.getJSONObject("start");
/* 182:241 */       JSONObject end = propertiesJSON.optJSONObject("end");
/* 183:243 */       if (end == null) {
/* 184:244 */         end = start;
/* 185:    */       }
/* 186:246 */       description = propertiesJSON.getString("description");
/* 187:247 */       location = propertiesJSON.optString("location");
/* 188:248 */       summary = propertiesJSON.optString("summary");
/* 189:249 */       status = propertiesJSON.optString("status");
/* 190:250 */       beginTime.set(start.getInt("year"), start.getInt("month"), start.getInt("day"), start.getInt("hour"), start.getInt("min"));
/* 191:    */       
/* 192:252 */       endTime.set(end.getInt("year"), end.getInt("month"), end.getInt("day"), end.getInt("hour"), end.getInt("min"));
/* 193:    */     }
/* 194:    */     catch (JSONException e)
/* 195:    */     {
/* 196:255 */       e.printStackTrace();
/* 197:    */     }
/* 198:257 */     Intent intent = new Intent("android.intent.action.INSERT").setData(CalendarContract.Events.CONTENT_URI).putExtra("beginTime", beginTime.getTimeInMillis()).putExtra("endTime", endTime.getTimeInMillis()).putExtra("title", summary).putExtra("description", description).putExtra("eventLocation", location).putExtra("eventStatus", status);
/* 199:    */     
/* 200:    */ 
/* 201:    */ 
/* 202:    */ 
/* 203:    */ 
/* 204:    */ 
/* 205:    */ 
/* 206:265 */     this.mMraidView.getContext().startActivity(intent);
/* 207:    */   }
/* 208:    */   
/* 209:    */   @JavascriptInterface
/* 210:    */   public void createEvent(final String date, final String title, final String body)
/* 211:    */   {
/* 212:277 */     TapjoyLog.d("MRAID Utility", "createEvent: date: " + date + " title: " + title + " body: " + body);
/* 213:278 */     ContentResolver cr = this.mContext.getContentResolver();
/* 214:    */     
/* 215:280 */     String[] cols = { "_id", "displayName", "_sync_account" };
/* 216:    */     Cursor cursor;
/* 217:    */     Cursor cursor;
/* 218:282 */     if (Integer.parseInt(Build.VERSION.SDK) == 8) {
/* 219:283 */       cursor = cr.query(Uri.parse("content://com.android.calendar/calendars"), cols, null, null, null);
/* 220:    */     } else {
/* 221:286 */       cursor = cr.query(Uri.parse("content://calendar/calendars"), cols, null, null, null);
/* 222:    */     }
/* 223:289 */     if ((cursor == null) || ((cursor != null) && (!cursor.moveToFirst())))
/* 224:    */     {
/* 225:291 */       Toast.makeText(this.mContext, "No calendar account found", 1).show();
/* 226:292 */       if (cursor != null) {
/* 227:293 */         cursor.close();
/* 228:    */       }
/* 229:294 */       return;
/* 230:    */     }
/* 231:297 */     if (cursor.getCount() == 1)
/* 232:    */     {
/* 233:298 */       addCalendarEvent(cursor.getInt(0), date, title, body);
/* 234:    */     }
/* 235:    */     else
/* 236:    */     {
/* 237:301 */       final List<Map<String, String>> entries = new ArrayList();
/* 238:303 */       for (int i = 0; i < cursor.getCount(); i++)
/* 239:    */       {
/* 240:304 */         Map<String, String> entry = new HashMap();
/* 241:305 */         entry.put("ID", cursor.getString(0));
/* 242:306 */         entry.put("NAME", cursor.getString(1));
/* 243:307 */         entry.put("EMAILID", cursor.getString(2));
/* 244:308 */         entries.add(entry);
/* 245:309 */         cursor.moveToNext();
/* 246:    */       }
/* 247:312 */       AlertDialog.Builder builder = new AlertDialog.Builder(this.mContext);
/* 248:313 */       builder.setTitle("Choose Calendar to save event to");
/* 249:314 */       ListAdapter adapter = new SimpleAdapter(this.mContext, entries, 17367053, new String[] { "NAME", "EMAILID" }, new int[] { 16908308, 16908309 });
/* 250:    */       
/* 251:    */ 
/* 252:    */ 
/* 253:    */ 
/* 254:    */ 
/* 255:    */ 
/* 256:321 */       builder.setSingleChoiceItems(adapter, -1, new DialogInterface.OnClickListener()
/* 257:    */       {
/* 258:    */         public void onClick(DialogInterface dialog, int which)
/* 259:    */         {
/* 260:324 */           Map<String, String> entry = (Map)entries.get(which);
/* 261:325 */           Utility.this.addCalendarEvent(Integer.parseInt((String)entry.get("ID")), date, title, body);
/* 262:326 */           dialog.cancel();
/* 263:    */         }
/* 264:330 */       });
/* 265:331 */       builder.create().show();
/* 266:    */     }
/* 267:333 */     cursor.close();
/* 268:    */   }
/* 269:    */   
/* 270:    */   private void addCalendarEvent(int callId, String date, String title, String body)
/* 271:    */   {
/* 272:346 */     ContentResolver cr = this.mContext.getContentResolver();
/* 273:347 */     long dtStart = Long.parseLong(date);
/* 274:348 */     long dtEnd = dtStart + 3600000L;
/* 275:349 */     ContentValues cv = new ContentValues();
/* 276:350 */     cv.put("calendar_id", Integer.valueOf(callId));
/* 277:351 */     cv.put("title", title);
/* 278:352 */     cv.put("description", body);
/* 279:353 */     cv.put("dtstart", Long.valueOf(dtStart));
/* 280:354 */     cv.put("hasAlarm", Integer.valueOf(1));
/* 281:355 */     cv.put("dtend", Long.valueOf(dtEnd));
/* 282:    */     Uri newEvent;
/* 283:    */     Uri newEvent;
/* 284:358 */     if (Integer.parseInt(Build.VERSION.SDK) == 8) {
/* 285:359 */       newEvent = cr.insert(Uri.parse("content://com.android.calendar/events"), cv);
/* 286:    */     } else {
/* 287:361 */       newEvent = cr.insert(Uri.parse("content://calendar/events"), cv);
/* 288:    */     }
/* 289:363 */     if (newEvent != null)
/* 290:    */     {
/* 291:364 */       long id = Long.parseLong(newEvent.getLastPathSegment());
/* 292:365 */       ContentValues values = new ContentValues();
/* 293:366 */       values.put("event_id", Long.valueOf(id));
/* 294:367 */       values.put("method", Integer.valueOf(1));
/* 295:368 */       values.put("minutes", Integer.valueOf(15));
/* 296:369 */       if (Integer.parseInt(Build.VERSION.SDK) == 8) {
/* 297:370 */         cr.insert(Uri.parse("content://com.android.calendar/reminders"), values);
/* 298:    */       } else {
/* 299:372 */         cr.insert(Uri.parse("content://calendar/reminders"), values);
/* 300:    */       }
/* 301:    */     }
/* 302:375 */     Toast.makeText(this.mContext, "Event added to calendar", 0).show();
/* 303:    */   }
/* 304:    */   
/* 305:    */   public String copyTextFromJarIntoAssetDir(String alias, String source)
/* 306:    */   {
/* 307:387 */     return this.mAssetController.copyTextFromJarIntoAssetDir(alias, source);
/* 308:    */   }
/* 309:    */   
/* 310:    */   public void setMaxSize(int w, int h)
/* 311:    */   {
/* 312:397 */     this.mDisplayController.setMaxSize(w, h);
/* 313:    */   }
/* 314:    */   
/* 315:    */   public String writeToDiskWrap(InputStream is, String currentFile, boolean storeInHashedDirectory, String injection, String bridgePath)
/* 316:    */     throws IllegalStateException, IOException
/* 317:    */   {
/* 318:415 */     return this.mAssetController.writeToDiskWrap(is, currentFile, storeInHashedDirectory, injection, bridgePath);
/* 319:    */   }
/* 320:    */   
/* 321:    */   @JavascriptInterface
/* 322:    */   public void activate(String event)
/* 323:    */   {
/* 324:425 */     TapjoyLog.d("MRAID Utility", "activate: " + event);
/* 325:426 */     if (event.equalsIgnoreCase("networkChange")) {
/* 326:427 */       this.mNetworkController.startNetworkListener();
/* 327:428 */     } else if ((this.mLocationController.allowLocationServices()) && (event.equalsIgnoreCase("locationChange"))) {
/* 328:429 */       this.mLocationController.startLocationListener();
/* 329:430 */     } else if (event.equalsIgnoreCase("shake")) {
/* 330:431 */       this.mSensorController.startShakeListener();
/* 331:432 */     } else if (event.equalsIgnoreCase("tiltChange")) {
/* 332:433 */       this.mSensorController.startTiltListener();
/* 333:434 */     } else if (event.equalsIgnoreCase("headingChange")) {
/* 334:435 */       this.mSensorController.startHeadingListener();
/* 335:436 */     } else if (event.equalsIgnoreCase("orientationChange")) {
/* 336:437 */       this.mDisplayController.startConfigurationListener();
/* 337:    */     }
/* 338:    */   }
/* 339:    */   
/* 340:    */   @JavascriptInterface
/* 341:    */   public void deactivate(String event)
/* 342:    */   {
/* 343:448 */     TapjoyLog.d("MRAID Utility", "deactivate: " + event);
/* 344:449 */     if (event.equalsIgnoreCase("networkChange")) {
/* 345:450 */       this.mNetworkController.stopNetworkListener();
/* 346:451 */     } else if (event.equalsIgnoreCase("locationChange")) {
/* 347:452 */       this.mLocationController.stopAllListeners();
/* 348:453 */     } else if (event.equalsIgnoreCase("shake")) {
/* 349:454 */       this.mSensorController.stopShakeListener();
/* 350:455 */     } else if (event.equalsIgnoreCase("tiltChange")) {
/* 351:456 */       this.mSensorController.stopTiltListener();
/* 352:457 */     } else if (event.equalsIgnoreCase("headingChange")) {
/* 353:458 */       this.mSensorController.stopHeadingListener();
/* 354:459 */     } else if (event.equalsIgnoreCase("orientationChange")) {
/* 355:460 */       this.mDisplayController.stopConfigurationListener();
/* 356:    */     }
/* 357:    */   }
/* 358:    */   
/* 359:    */   public void deleteOldAds()
/* 360:    */   {
/* 361:470 */     this.mAssetController.deleteOldAds();
/* 362:    */   }
/* 363:    */   
/* 364:    */   public void stopAllListeners()
/* 365:    */   {
/* 366:    */     try
/* 367:    */     {
/* 368:477 */       this.mAssetController.stopAllListeners();
/* 369:478 */       this.mDisplayController.stopAllListeners();
/* 370:479 */       this.mLocationController.stopAllListeners();
/* 371:480 */       this.mNetworkController.stopAllListeners();
/* 372:481 */       this.mSensorController.stopAllListeners();
/* 373:    */     }
/* 374:    */     catch (Exception e) {}
/* 375:    */   }
/* 376:    */   
/* 377:    */   @JavascriptInterface
/* 378:    */   public void showAlert(String message)
/* 379:    */   {
/* 380:488 */     TapjoyLog.e("MRAID Utility", message);
/* 381:    */   }
/* 382:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.controller.Utility
 * JD-Core Version:    0.7.0.1
 */