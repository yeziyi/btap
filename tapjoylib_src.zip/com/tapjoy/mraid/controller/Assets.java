/*   1:    */ package com.tapjoy.mraid.controller;
/*   2:    */ 
/*   3:    */ import android.app.AlertDialog.Builder;
/*   4:    */ import android.content.Context;
/*   5:    */ import android.content.DialogInterface;
/*   6:    */ import android.content.DialogInterface.OnClickListener;
/*   7:    */ import android.content.res.AssetManager;
/*   8:    */ import android.os.Environment;
/*   9:    */ import android.os.StatFs;
/*  10:    */ import android.util.Log;
/*  11:    */ import android.webkit.JavascriptInterface;
/*  12:    */ import com.tapjoy.TapjoyLog;
/*  13:    */ import com.tapjoy.mraid.view.MraidView;
/*  14:    */ import java.io.BufferedInputStream;
/*  15:    */ import java.io.ByteArrayOutputStream;
/*  16:    */ import java.io.File;
/*  17:    */ import java.io.FileNotFoundException;
/*  18:    */ import java.io.FileOutputStream;
/*  19:    */ import java.io.IOException;
/*  20:    */ import java.io.InputStream;
/*  21:    */ import java.net.URL;
/*  22:    */ import java.net.URLConnection;
/*  23:    */ import java.security.MessageDigest;
/*  24:    */ import java.security.NoSuchAlgorithmException;
/*  25:    */ import java.util.jar.JarEntry;
/*  26:    */ import java.util.jar.JarFile;
/*  27:    */ import org.apache.http.HttpEntity;
/*  28:    */ import org.apache.http.HttpResponse;
/*  29:    */ import org.apache.http.client.methods.HttpGet;
/*  30:    */ import org.apache.http.impl.client.DefaultHttpClient;
/*  31:    */ import org.apache.http.util.ByteArrayBuffer;
/*  32:    */ 
/*  33:    */ public class Assets
/*  34:    */   extends Abstract
/*  35:    */ {
/*  36:    */   private static final String TAG = "MRAID Assets";
/*  37: 40 */   private int imageNameCounter = 0;
/*  38:    */   
/*  39:    */   public Assets(MraidView adView, Context c)
/*  40:    */   {
/*  41: 50 */     super(adView, c);
/*  42:    */   }
/*  43:    */   
/*  44:    */   @JavascriptInterface
/*  45:    */   public void storePictureInit(String URI)
/*  46:    */   {
/*  47: 55 */     final String uri = URI;
/*  48: 56 */     AlertDialog.Builder myDialog = new AlertDialog.Builder(this.mContext);
/*  49: 57 */     myDialog.setMessage("Are you sure you want to save file from " + URI + " to your SD card?");
/*  50: 58 */     myDialog.setCancelable(false);
/*  51: 59 */     myDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener()
/*  52:    */     {
/*  53:    */       public void onClick(DialogInterface dialog, int id)
/*  54:    */       {
/*  55: 61 */         Assets.this.storePicture(uri);
/*  56:    */       }
/*  57: 63 */     });
/*  58: 64 */     myDialog.setNegativeButton("No", null);
/*  59: 65 */     myDialog.show();
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void storePicture(String URI)
/*  63:    */   {
/*  64: 70 */     TapjoyLog.d("MRAID Assets", "Storing media from " + URI + " to device photo album.  Output directory: " + Environment.getExternalStorageDirectory() + " state: " + Environment.getExternalStorageState());
/*  65:    */     
/*  66: 72 */     this.imageNameCounter += 1;
/*  67:    */     try
/*  68:    */     {
/*  69: 75 */       URL url = new URL(URI);
/*  70: 76 */       String fileName = "MraidMedia" + this.imageNameCounter + ".jpg";
/*  71: 77 */       File file = new File(Environment.getExternalStorageDirectory().toString() + "/" + fileName);
/*  72:    */       
/*  73: 79 */       long startTime = System.currentTimeMillis();
/*  74: 80 */       Log.d("MRAID Assets", "download beginning");
/*  75: 81 */       Log.d("MRAID Assets", "download url:" + url);
/*  76: 82 */       Log.d("MRAID Assets", "downloaded file name:" + fileName);
/*  77:    */       
/*  78: 84 */       URLConnection ucon = url.openConnection();
/*  79:    */       
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83: 89 */       InputStream is = ucon.getInputStream();
/*  84: 90 */       BufferedInputStream bis = new BufferedInputStream(is);
/*  85:    */       
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89: 95 */       ByteArrayBuffer baf = new ByteArrayBuffer(50);
/*  90: 96 */       int current = 0;
/*  91: 97 */       while ((current = bis.read()) != -1) {
/*  92: 98 */         baf.append((byte)current);
/*  93:    */       }
/*  94:102 */       FileOutputStream fos = new FileOutputStream(file);
/*  95:103 */       fos.write(baf.toByteArray());
/*  96:104 */       fos.close();
/*  97:105 */       Log.d("MRAID Assets", "download ready in" + (System.currentTimeMillis() - startTime) / 1000L + " sec");
/*  98:    */     }
/*  99:    */     catch (IOException e)
/* 100:    */     {
/* 101:110 */       Log.d("MRAID Assets", "Error: " + e);
/* 102:    */     }
/* 103:    */   }
/* 104:    */   
/* 105:    */   public String copyTextFromJarIntoAssetDir(String alias, String source)
/* 106:    */   {
/* 107:125 */     InputStream in = null;
/* 108:    */     try
/* 109:    */     {
/* 110:127 */       URL url = Assets.class.getClassLoader().getResource(source);
/* 111:    */       int pos;
/* 112:130 */       if (url == null)
/* 113:    */       {
/* 114:132 */         AssetManager am = this.mContext.getAssets();
/* 115:133 */         in = am.open(source);
/* 116:    */       }
/* 117:    */       else
/* 118:    */       {
/* 119:137 */         String file = url.getFile();
/* 120:139 */         if (file.startsWith("jar:")) {
/* 121:140 */           file = file.substring(4);
/* 122:    */         }
/* 123:142 */         if (file.startsWith("file:")) {
/* 124:143 */           file = file.substring(5);
/* 125:    */         }
/* 126:145 */         pos = file.indexOf("!");
/* 127:146 */         if (pos > 0) {
/* 128:147 */           file = file.substring(0, pos);
/* 129:    */         }
/* 130:148 */         JarFile jf = new JarFile(file);
/* 131:149 */         JarEntry entry = jf.getJarEntry(source);
/* 132:150 */         in = jf.getInputStream(entry);
/* 133:    */       }
/* 134:153 */       String name = writeToDisk(in, alias, false);
/* 135:154 */       return name;
/* 136:    */     }
/* 137:    */     catch (Exception e)
/* 138:    */     {
/* 139:157 */       TapjoyLog.e("MRAID Assets", "copyTextFromJarIntoAssetDir: " + e.toString());
/* 140:    */     }
/* 141:    */     finally
/* 142:    */     {
/* 143:159 */       if (in != null)
/* 144:    */       {
/* 145:    */         try
/* 146:    */         {
/* 147:161 */           in.close();
/* 148:    */         }
/* 149:    */         catch (Exception e) {}
/* 150:165 */         in = null;
/* 151:    */       }
/* 152:    */     }
/* 153:168 */     return null;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public void addAsset(String alias, String url)
/* 157:    */   {
/* 158:180 */     HttpEntity entity = getHttpEntity(url);
/* 159:181 */     InputStream in = null;
/* 160:    */     try
/* 161:    */     {
/* 162:183 */       in = entity.getContent();
/* 163:184 */       writeToDisk(in, alias, false);
/* 164:185 */       String str = "MraidAdController.addedAsset('" + alias + "' )";
/* 165:186 */       this.mMraidView.injectMraidJavaScript(str);
/* 166:    */     }
/* 167:    */     catch (Exception e)
/* 168:    */     {
/* 169:188 */       e.printStackTrace();
/* 170:    */     }
/* 171:    */     finally
/* 172:    */     {
/* 173:190 */       if (in != null)
/* 174:    */       {
/* 175:    */         try
/* 176:    */         {
/* 177:192 */           in.close();
/* 178:    */         }
/* 179:    */         catch (Exception e) {}
/* 180:195 */         in = null;
/* 181:    */       }
/* 182:    */     }
/* 183:    */     try
/* 184:    */     {
/* 185:200 */       entity.consumeContent();
/* 186:    */     }
/* 187:    */     catch (Exception e)
/* 188:    */     {
/* 189:202 */       e.printStackTrace();
/* 190:    */     }
/* 191:    */   }
/* 192:    */   
/* 193:    */   private HttpEntity getHttpEntity(String url)
/* 194:    */   {
/* 195:218 */     HttpEntity entity = null;
/* 196:    */     try
/* 197:    */     {
/* 198:220 */       DefaultHttpClient httpclient = new DefaultHttpClient();
/* 199:221 */       HttpGet httpget = new HttpGet(url);
/* 200:222 */       HttpResponse response = httpclient.execute(httpget);
/* 201:223 */       entity = response.getEntity();
/* 202:    */     }
/* 203:    */     catch (Exception e)
/* 204:    */     {
/* 205:225 */       e.printStackTrace();
/* 206:226 */       return null;
/* 207:    */     }
/* 208:228 */     return entity;
/* 209:    */   }
/* 210:    */   
/* 211:    */   public int cacheRemaining()
/* 212:    */   {
/* 213:237 */     File filesDir = this.mContext.getFilesDir();
/* 214:238 */     StatFs stats = new StatFs(filesDir.getPath());
/* 215:239 */     int free = stats.getFreeBlocks() * stats.getBlockSize();
/* 216:240 */     return free;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public String writeToDisk(InputStream in, String file, boolean storeInHashedDirectory)
/* 220:    */     throws IllegalStateException, IOException
/* 221:    */   {
/* 222:265 */     int i = 0;
/* 223:266 */     byte[] buff = new byte[1024];
/* 224:    */     
/* 225:268 */     MessageDigest digest = null;
/* 226:269 */     if (storeInHashedDirectory) {
/* 227:    */       try
/* 228:    */       {
/* 229:271 */         digest = MessageDigest.getInstance("MD5");
/* 230:    */       }
/* 231:    */       catch (NoSuchAlgorithmException e)
/* 232:    */       {
/* 233:273 */         e.printStackTrace();
/* 234:    */       }
/* 235:    */     }
/* 236:276 */     FileOutputStream out = null;
/* 237:    */     try
/* 238:    */     {
/* 239:278 */       out = getAssetOutputString(file);
/* 240:    */       for (;;)
/* 241:    */       {
/* 242:280 */         int numread = in.read(buff);
/* 243:281 */         if (numread <= 0) {
/* 244:    */           break;
/* 245:    */         }
/* 246:284 */         if ((storeInHashedDirectory) && (digest != null)) {
/* 247:285 */           digest.update(buff);
/* 248:    */         }
/* 249:287 */         out.write(buff, 0, numread);
/* 250:288 */         i++;
/* 251:    */       }
/* 252:290 */       out.flush();
/* 253:    */     }
/* 254:    */     finally
/* 255:    */     {
/* 256:292 */       if (out != null)
/* 257:    */       {
/* 258:    */         try
/* 259:    */         {
/* 260:294 */           out.close();
/* 261:    */         }
/* 262:    */         catch (Exception e) {}
/* 263:297 */         out = null;
/* 264:    */       }
/* 265:    */     }
/* 266:301 */     String filesDir = getFilesDir();
/* 267:303 */     if ((storeInHashedDirectory) && (digest != null)) {
/* 268:304 */       filesDir = moveToAdDirectory(file, filesDir, asHex(digest));
/* 269:    */     }
/* 270:306 */     return filesDir + file;
/* 271:    */   }
/* 272:    */   
/* 273:    */   public String writeToDiskWrap(InputStream in, String file, boolean storeInHashedDirectory, String injection, String bridgePath)
/* 274:    */     throws IllegalStateException, IOException
/* 275:    */   {
/* 276:333 */     byte[] buff = new byte[1024];
/* 277:    */     
/* 278:335 */     MessageDigest digest = null;
/* 279:336 */     if (storeInHashedDirectory) {
/* 280:    */       try
/* 281:    */       {
/* 282:338 */         digest = MessageDigest.getInstance("MD5");
/* 283:    */       }
/* 284:    */       catch (NoSuchAlgorithmException e)
/* 285:    */       {
/* 286:340 */         e.printStackTrace();
/* 287:    */       }
/* 288:    */     }
/* 289:345 */     ByteArrayOutputStream fromFile = new ByteArrayOutputStream();
/* 290:346 */     FileOutputStream out = null;
/* 291:    */     try
/* 292:    */     {
/* 293:    */       for (;;)
/* 294:    */       {
/* 295:349 */         int numread = in.read(buff);
/* 296:351 */         if (numread <= 0) {
/* 297:    */           break;
/* 298:    */         }
/* 299:355 */         if ((storeInHashedDirectory) && (digest != null)) {
/* 300:356 */           digest.update(buff);
/* 301:    */         }
/* 302:359 */         fromFile.write(buff, 0, numread);
/* 303:    */       }
/* 304:363 */       String wholeHTML = fromFile.toString();
/* 305:364 */       boolean hasHTMLWrap = wholeHTML.indexOf("</html>") >= 0;
/* 306:    */       
/* 307:    */ 
/* 308:    */ 
/* 309:368 */       StringBuffer wholeHTMLBuffer = null;
/* 310:369 */       wholeHTMLBuffer = new StringBuffer(wholeHTML);
/* 311:371 */       if (hasHTMLWrap) {
/* 312:372 */         if (contains(wholeHTMLBuffer, "mraid.js")) {
/* 313:373 */           replace(wholeHTMLBuffer, "mraid.js", bridgePath);
/* 314:374 */         } else if (contains(wholeHTMLBuffer, "ormma.js")) {
/* 315:375 */           replace(wholeHTMLBuffer, "ormma.js", bridgePath);
/* 316:376 */         } else if (contains(wholeHTMLBuffer, "ormma_bridge.js")) {
/* 317:377 */           replace(wholeHTMLBuffer, "ormma_bridge.js", bridgePath);
/* 318:    */         }
/* 319:    */       }
/* 320:380 */       out = getAssetOutputString(file);
/* 321:381 */       if (!hasHTMLWrap)
/* 322:    */       {
/* 323:382 */         out.write("<html>".getBytes());
/* 324:383 */         out.write("<head>".getBytes());
/* 325:384 */         out.write("<meta name='viewport' content='user-scalable=no initial-scale=1.0' />".getBytes());
/* 326:    */         
/* 327:386 */         out.write("<title>Advertisement</title> ".getBytes());
/* 328:    */         
/* 329:388 */         out.write(("<script src=\"file://" + bridgePath + "\" type=\"text/javascript\"></script>").getBytes());
/* 330:393 */         if (injection != null)
/* 331:    */         {
/* 332:394 */           out.write("<script type=\"text/javascript\">".getBytes());
/* 333:395 */           out.write(injection.getBytes());
/* 334:396 */           out.write("</script>".getBytes());
/* 335:    */         }
/* 336:398 */         out.write("</head>".getBytes());
/* 337:399 */         out.write("<body style=\"margin:0; padding:0; overflow:hidden; background-color:transparent;\">".getBytes());
/* 338:    */         
/* 339:401 */         out.write("<div align=\"center\"> ".getBytes());
/* 340:    */       }
/* 341:404 */       if (!hasHTMLWrap) {
/* 342:405 */         out.write(fromFile.toByteArray());
/* 343:    */       } else {
/* 344:407 */         out.write(wholeHTMLBuffer.toString().getBytes());
/* 345:    */       }
/* 346:410 */       if (!hasHTMLWrap)
/* 347:    */       {
/* 348:411 */         out.write("</div> ".getBytes());
/* 349:412 */         out.write("</body> ".getBytes());
/* 350:413 */         out.write("</html> ".getBytes());
/* 351:    */       }
/* 352:416 */       out.flush();
/* 353:    */     }
/* 354:    */     finally
/* 355:    */     {
/* 356:419 */       if (fromFile != null)
/* 357:    */       {
/* 358:    */         try
/* 359:    */         {
/* 360:421 */           fromFile.close();
/* 361:    */         }
/* 362:    */         catch (Exception e) {}
/* 363:425 */         fromFile = null;
/* 364:    */       }
/* 365:427 */       if (out != null)
/* 366:    */       {
/* 367:    */         try
/* 368:    */         {
/* 369:429 */           out.close();
/* 370:    */         }
/* 371:    */         catch (Exception e) {}
/* 372:434 */         out = null;
/* 373:    */       }
/* 374:    */     }
/* 375:437 */     String filesDir = getFilesDir();
/* 376:439 */     if ((storeInHashedDirectory) && (digest != null)) {
/* 377:440 */       filesDir = moveToAdDirectory(file, filesDir, asHex(digest));
/* 378:    */     }
/* 379:442 */     return filesDir;
/* 380:    */   }
/* 381:    */   
/* 382:    */   private boolean contains(StringBuffer buffer, String lookForMe)
/* 383:    */   {
/* 384:    */     try
/* 385:    */     {
/* 386:447 */       if (buffer.indexOf(lookForMe) >= 0) {
/* 387:447 */         return true;
/* 388:    */       }
/* 389:    */     }
/* 390:    */     catch (Exception e)
/* 391:    */     {
/* 392:449 */       TapjoyLog.d("contains", "html file does not contain " + lookForMe);
/* 393:    */     }
/* 394:451 */     return false;
/* 395:    */   }
/* 396:    */   
/* 397:    */   private void replace(StringBuffer buffer, String toReplace, String bridgePath)
/* 398:    */   {
/* 399:455 */     int start = buffer.indexOf(toReplace);
/* 400:456 */     TapjoyLog.d("replace ", bridgePath);
/* 401:457 */     buffer.replace(start, start + toReplace.length(), "file://" + bridgePath);
/* 402:    */   }
/* 403:    */   
/* 404:    */   private String moveToAdDirectory(String fn, String filesDir, String subDir)
/* 405:    */   {
/* 406:474 */     File file = new File(filesDir + File.separator + fn);
/* 407:475 */     File adDir = new File(filesDir + File.separator + "ad");
/* 408:476 */     adDir.mkdir();
/* 409:477 */     File dir = new File(filesDir + File.separator + "ad" + File.separator + subDir);
/* 410:    */     
/* 411:479 */     dir.mkdir();
/* 412:480 */     file.renameTo(new File(dir, file.getName()));
/* 413:481 */     return dir.getPath() + File.separator;
/* 414:    */   }
/* 415:    */   
/* 416:487 */   private static final char[] HEX_CHARS = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/* 417:    */   
/* 418:    */   private String asHex(MessageDigest digest)
/* 419:    */   {
/* 420:498 */     byte[] hash = digest.digest();
/* 421:499 */     char[] buf = new char[hash.length * 2];
/* 422:500 */     int i = 0;
/* 423:500 */     for (int x = 0; i < hash.length; i++)
/* 424:    */     {
/* 425:501 */       buf[(x++)] = HEX_CHARS[(hash[i] >>> 4 & 0xF)];
/* 426:502 */       buf[(x++)] = HEX_CHARS[(hash[i] & 0xF)];
/* 427:    */     }
/* 428:504 */     return new String(buf);
/* 429:    */   }
/* 430:    */   
/* 431:    */   private String getFilesDir()
/* 432:    */   {
/* 433:513 */     return this.mContext.getFilesDir().getPath();
/* 434:    */   }
/* 435:    */   
/* 436:    */   public FileOutputStream getAssetOutputString(String asset)
/* 437:    */     throws FileNotFoundException
/* 438:    */   {
/* 439:527 */     File dir = getAssetDir(getAssetPath(asset));
/* 440:528 */     dir.mkdirs();
/* 441:529 */     File file = new File(dir, getAssetName(asset));
/* 442:530 */     return new FileOutputStream(file);
/* 443:    */   }
/* 444:    */   
/* 445:    */   public void removeAsset(String asset)
/* 446:    */   {
/* 447:540 */     File dir = getAssetDir(getAssetPath(asset));
/* 448:541 */     dir.mkdirs();
/* 449:542 */     File file = new File(dir, getAssetName(asset));
/* 450:543 */     file.delete();
/* 451:    */     
/* 452:545 */     String str = "MraidAdController.assetRemoved('" + asset + "' )";
/* 453:546 */     this.mMraidView.injectMraidJavaScript(str);
/* 454:    */   }
/* 455:    */   
/* 456:    */   private File getAssetDir(String path)
/* 457:    */   {
/* 458:557 */     File filesDir = this.mContext.getFilesDir();
/* 459:558 */     File newDir = new File(filesDir.getPath() + File.separator + path);
/* 460:    */     
/* 461:560 */     return newDir;
/* 462:    */   }
/* 463:    */   
/* 464:    */   private String getAssetPath(String asset)
/* 465:    */   {
/* 466:571 */     int lastSep = asset.lastIndexOf(File.separatorChar);
/* 467:572 */     String path = "/";
/* 468:574 */     if (lastSep >= 0) {
/* 469:575 */       path = asset.substring(0, asset.lastIndexOf(File.separatorChar));
/* 470:    */     }
/* 471:578 */     return path;
/* 472:    */   }
/* 473:    */   
/* 474:    */   private String getAssetName(String asset)
/* 475:    */   {
/* 476:589 */     int lastSep = asset.lastIndexOf(File.separatorChar);
/* 477:590 */     String name = asset;
/* 478:592 */     if (lastSep >= 0) {
/* 479:593 */       name = asset.substring(asset.lastIndexOf(File.separatorChar) + 1);
/* 480:    */     }
/* 481:596 */     return name;
/* 482:    */   }
/* 483:    */   
/* 484:    */   public String getAssetPath()
/* 485:    */   {
/* 486:605 */     return "file://" + this.mContext.getFilesDir() + "/";
/* 487:    */   }
/* 488:    */   
/* 489:    */   public static boolean deleteDirectory(String path)
/* 490:    */   {
/* 491:616 */     if (path != null) {
/* 492:617 */       return deleteDirectory(new File(path));
/* 493:    */     }
/* 494:618 */     return false;
/* 495:    */   }
/* 496:    */   
/* 497:    */   public static boolean deleteDirectory(File path)
/* 498:    */   {
/* 499:629 */     if (path.exists())
/* 500:    */     {
/* 501:630 */       File[] files = path.listFiles();
/* 502:631 */       for (int i = 0; i < files.length; i++) {
/* 503:632 */         if (files[i].isDirectory()) {
/* 504:633 */           deleteDirectory(files[i]);
/* 505:    */         } else {
/* 506:635 */           files[i].delete();
/* 507:    */         }
/* 508:    */       }
/* 509:    */     }
/* 510:639 */     return path.delete();
/* 511:    */   }
/* 512:    */   
/* 513:    */   public void deleteOldAds()
/* 514:    */   {
/* 515:646 */     String filesDir = getFilesDir();
/* 516:647 */     File adDir = new File(filesDir + File.separator + "ad");
/* 517:648 */     deleteDirectory(adDir);
/* 518:    */   }
/* 519:    */   
/* 520:    */   public void stopAllListeners() {}
/* 521:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.controller.Assets
 * JD-Core Version:    0.7.0.1
 */