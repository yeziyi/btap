/*  1:   */ package com.tapjoy.mraid.util;
/*  2:   */ 
/*  3:   */ public enum TransitionStringEnum
/*  4:   */ {
/*  5: 6 */   DEFAULT("default"),  DISSOLVE("dissolve"),  FADE("fade"),  ROLL("roll"),  SLIDE("slide"),  ZOOM("zoom"),  NONE("none");
/*  6:   */   
/*  7:   */   private String text;
/*  8:   */   
/*  9:   */   private TransitionStringEnum(String text)
/* 10:   */   {
/* 11:11 */     this.text = text;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String getText()
/* 15:   */   {
/* 16:15 */     return this.text;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public static TransitionStringEnum fromString(String text)
/* 20:   */   {
/* 21:19 */     if (text != null) {
/* 22:20 */       for (TransitionStringEnum b : values()) {
/* 23:21 */         if (text.equalsIgnoreCase(b.text)) {
/* 24:22 */           return b;
/* 25:   */         }
/* 26:   */       }
/* 27:   */     }
/* 28:26 */     return null;
/* 29:   */   }
/* 30:   */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.util.TransitionStringEnum
 * JD-Core Version:    0.7.0.1
 */