/*   1:    */ package com.tapjoy.mraid.util;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.media.AudioManager;
/*   5:    */ import android.media.MediaPlayer;
/*   6:    */ import android.media.MediaPlayer.OnCompletionListener;
/*   7:    */ import android.media.MediaPlayer.OnErrorListener;
/*   8:    */ import android.media.MediaPlayer.OnPreparedListener;
/*   9:    */ import android.net.Uri;
/*  10:    */ import android.view.ViewGroup;
/*  11:    */ import android.widget.ImageButton;
/*  12:    */ import android.widget.MediaController;
/*  13:    */ import android.widget.RelativeLayout;
/*  14:    */ import android.widget.RelativeLayout.LayoutParams;
/*  15:    */ import android.widget.TextView;
/*  16:    */ import android.widget.VideoView;
/*  17:    */ import com.tapjoy.TapjoyLog;
/*  18:    */ import com.tapjoy.mraid.controller.Abstract.PlayerProperties;
/*  19:    */ import com.tapjoy.mraid.listener.Player;
/*  20:    */ 
/*  21:    */ public class MraidPlayer
/*  22:    */   extends VideoView
/*  23:    */   implements MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener, MediaPlayer.OnPreparedListener
/*  24:    */ {
/*  25:    */   private Abstract.PlayerProperties playProperties;
/*  26:    */   private AudioManager aManager;
/*  27:    */   private Player listener;
/*  28:    */   private int mutedVolume;
/*  29:    */   private String contentURL;
/*  30:    */   private RelativeLayout transientLayout;
/*  31:    */   private ImageButton closeImageButton;
/*  32: 41 */   private static String transientText = "Loading. Please Wait..";
/*  33: 42 */   private static String TAG = "MRAID Player";
/*  34:    */   private boolean isReleased;
/*  35:    */   
/*  36:    */   public MraidPlayer(Context context)
/*  37:    */   {
/*  38: 50 */     super(context);
/*  39: 51 */     this.aManager = ((AudioManager)getContext().getSystemService("audio"));
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void setPlayData(Abstract.PlayerProperties properties, String url)
/*  43:    */   {
/*  44: 60 */     this.isReleased = false;
/*  45: 61 */     this.playProperties = properties;
/*  46: 62 */     this.contentURL = url;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void playAudio()
/*  50:    */   {
/*  51: 70 */     loadContent();
/*  52:    */   }
/*  53:    */   
/*  54:    */   public ImageButton getCloseImageButton()
/*  55:    */   {
/*  56: 74 */     return this.closeImageButton;
/*  57:    */   }
/*  58:    */   
/*  59:    */   void displayControl()
/*  60:    */   {
/*  61: 82 */     if (this.playProperties.showControl())
/*  62:    */     {
/*  63: 83 */       MediaController ctrl = new MediaController(getContext());
/*  64: 84 */       setMediaController(ctrl);
/*  65: 85 */       ctrl.setAnchorView(this);
/*  66:    */     }
/*  67:    */   }
/*  68:    */   
/*  69:    */   void loadContent()
/*  70:    */   {
/*  71: 99 */     this.contentURL = this.contentURL.trim();
/*  72:    */     
/*  73:101 */     this.contentURL = Utils.convert(this.contentURL);
/*  74:102 */     if ((this.contentURL == null) && (this.listener != null))
/*  75:    */     {
/*  76:103 */       removeView();
/*  77:104 */       this.listener.onError();
/*  78:105 */       return;
/*  79:    */     }
/*  80:108 */     setVideoURI(Uri.parse(this.contentURL));
/*  81:109 */     TapjoyLog.d("player", Uri.parse(this.contentURL).toString());
/*  82:110 */     displayControl();
/*  83:111 */     startContent();
/*  84:    */   }
/*  85:    */   
/*  86:    */   void startContent()
/*  87:    */   {
/*  88:119 */     setOnCompletionListener(this);
/*  89:120 */     setOnErrorListener(this);
/*  90:121 */     setOnPreparedListener(this);
/*  91:123 */     if (!this.playProperties.inline) {
/*  92:124 */       addTransientMessage();
/*  93:    */     }
/*  94:126 */     if (this.playProperties.isAutoPlay()) {
/*  95:127 */       start();
/*  96:    */     }
/*  97:    */   }
/*  98:    */   
/*  99:    */   public void playVideo()
/* 100:    */   {
/* 101:137 */     if (this.playProperties.doMute())
/* 102:    */     {
/* 103:138 */       this.mutedVolume = this.aManager.getStreamVolume(3);
/* 104:139 */       this.aManager.setStreamVolume(3, 0, 4);
/* 105:    */     }
/* 106:141 */     loadContent();
/* 107:    */   }
/* 108:    */   
/* 109:    */   void unMute()
/* 110:    */   {
/* 111:148 */     this.aManager.setStreamVolume(3, this.mutedVolume, 4);
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void setListener(Player listener)
/* 115:    */   {
/* 116:156 */     this.listener = listener;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public void onCompletion(MediaPlayer mp)
/* 120:    */   {
/* 121:161 */     if (this.playProperties.doLoop()) {
/* 122:162 */       start();
/* 123:163 */     } else if ((this.playProperties.exitOnComplete()) || (this.playProperties.inline)) {
/* 124:165 */       releasePlayer();
/* 125:    */     }
/* 126:    */   }
/* 127:    */   
/* 128:    */   public boolean onError(MediaPlayer mp, int what, int extra)
/* 129:    */   {
/* 130:171 */     TapjoyLog.i(TAG, "Player error : " + what);
/* 131:172 */     clearTransientMessage();
/* 132:173 */     removeView();
/* 133:174 */     if (this.listener != null) {
/* 134:175 */       this.listener.onError();
/* 135:    */     }
/* 136:176 */     return false;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public void onPrepared(MediaPlayer mp)
/* 140:    */   {
/* 141:181 */     clearTransientMessage();
/* 142:182 */     if (this.listener != null) {
/* 143:183 */       this.listener.onPrepared();
/* 144:    */     }
/* 145:    */   }
/* 146:    */   
/* 147:    */   void removeView()
/* 148:    */   {
/* 149:191 */     ViewGroup parent = (ViewGroup)getParent();
/* 150:192 */     if (parent != null) {
/* 151:193 */       parent.removeAllViews();
/* 152:    */     }
/* 153:    */   }
/* 154:    */   
/* 155:    */   public void releasePlayer()
/* 156:    */   {
/* 157:201 */     if (this.isReleased) {
/* 158:202 */       return;
/* 159:    */     }
/* 160:204 */     this.isReleased = true;
/* 161:    */     
/* 162:206 */     stopPlayback();
/* 163:207 */     removeView();
/* 164:208 */     if ((this.playProperties != null) && (this.playProperties.doMute())) {
/* 165:209 */       unMute();
/* 166:    */     }
/* 167:210 */     if (this.listener != null) {
/* 168:211 */       this.listener.onComplete();
/* 169:    */     }
/* 170:    */   }
/* 171:    */   
/* 172:    */   void addTransientMessage()
/* 173:    */   {
/* 174:219 */     if (this.playProperties.inline) {
/* 175:220 */       return;
/* 176:    */     }
/* 177:222 */     this.transientLayout = new RelativeLayout(getContext());
/* 178:223 */     this.transientLayout.setLayoutParams(getLayoutParams());
/* 179:    */     
/* 180:    */ 
/* 181:226 */     TextView transientView = new TextView(getContext());
/* 182:227 */     transientView.setText(transientText);
/* 183:228 */     transientView.setTextColor(-1);
/* 184:    */     
/* 185:230 */     RelativeLayout.LayoutParams msgparams = new RelativeLayout.LayoutParams(-2, -2);
/* 186:231 */     msgparams.addRule(13);
/* 187:    */     
/* 188:233 */     this.transientLayout.addView(transientView, msgparams);
/* 189:234 */     ViewGroup parent = (ViewGroup)getParent();
/* 190:235 */     parent.addView(this.transientLayout);
/* 191:    */   }
/* 192:    */   
/* 193:    */   void clearTransientMessage()
/* 194:    */   {
/* 195:242 */     if (this.transientLayout != null)
/* 196:    */     {
/* 197:243 */       ViewGroup parent = (ViewGroup)getParent();
/* 198:244 */       parent.removeView(this.transientLayout);
/* 199:    */     }
/* 200:    */   }
/* 201:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.util.MraidPlayer
 * JD-Core Version:    0.7.0.1
 */