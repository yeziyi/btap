/*  1:   */ package com.tapjoy.mraid.util;
/*  2:   */ 
/*  3:   */ import android.content.BroadcastReceiver;
/*  4:   */ import android.content.Context;
/*  5:   */ import android.content.Intent;
/*  6:   */ import com.tapjoy.mraid.controller.Display;
/*  7:   */ 
/*  8:   */ public class ConfigBroadcastReceiver
/*  9:   */   extends BroadcastReceiver
/* 10:   */ {
/* 11:   */   private Display mMraidDisplay;
/* 12:   */   private int mLastOrientation;
/* 13:   */   
/* 14:   */   public ConfigBroadcastReceiver(Display mraidDisplayController)
/* 15:   */   {
/* 16:29 */     this.mMraidDisplay = mraidDisplayController;
/* 17:30 */     this.mLastOrientation = this.mMraidDisplay.getOrientation();
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void onReceive(Context context, Intent intent)
/* 21:   */   {
/* 22:38 */     String action = intent.getAction();
/* 23:39 */     if (action.equals("android.intent.action.CONFIGURATION_CHANGED"))
/* 24:   */     {
/* 25:40 */       int orientation = this.mMraidDisplay.getOrientation();
/* 26:41 */       if (orientation != this.mLastOrientation)
/* 27:   */       {
/* 28:42 */         this.mLastOrientation = orientation;
/* 29:43 */         this.mMraidDisplay.onOrientationChanged(this.mLastOrientation);
/* 30:   */       }
/* 31:   */     }
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.util.ConfigBroadcastReceiver
 * JD-Core Version:    0.7.0.1
 */