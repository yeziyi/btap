/*  1:   */ package com.tapjoy.mraid.util;
/*  2:   */ 
/*  3:   */ import android.os.Bundle;
/*  4:   */ 
/*  5:   */ public class Utils
/*  6:   */ {
/*  7:   */   private static final String CHAR_SET = "ISO-8859-1";
/*  8:   */   
/*  9:   */   public static String byteToHex(byte b)
/* 10:   */   {
/* 11:10 */     char[] hexDigit = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/* 12:   */     
/* 13:12 */     char[] array = { hexDigit[(b >> 4 & 0xF)], hexDigit[(b & 0xF)] };
/* 14:13 */     return new String(array);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public static String convert(String str)
/* 18:   */   {
/* 19:   */     try
/* 20:   */     {
/* 21:24 */       byte[] array = str.getBytes();
/* 22:   */       
/* 23:26 */       StringBuffer buffer = new StringBuffer();
/* 24:27 */       for (int k = 0; k < array.length; k++) {
/* 25:28 */         if ((array[k] & 0x80) > 0) {
/* 26:29 */           buffer.append("%" + byteToHex(array[k]));
/* 27:   */         } else {
/* 28:31 */           buffer.append((char)array[k]);
/* 29:   */         }
/* 30:   */       }
/* 31:34 */       return new String(buffer.toString().getBytes(), "ISO-8859-1");
/* 32:   */     }
/* 33:   */     catch (Exception ex) {}
/* 34:38 */     return null;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public static String getData(String key, Bundle data)
/* 38:   */   {
/* 39:48 */     return data.getString(key);
/* 40:   */   }
/* 41:   */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.util.Utils
 * JD-Core Version:    0.7.0.1
 */