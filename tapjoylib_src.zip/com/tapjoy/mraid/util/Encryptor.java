/*  1:   */ package com.tapjoy.mraid.util;
/*  2:   */ 
/*  3:   */ import java.security.SecureRandom;
/*  4:   */ import javax.crypto.Cipher;
/*  5:   */ import javax.crypto.KeyGenerator;
/*  6:   */ import javax.crypto.SecretKey;
/*  7:   */ import javax.crypto.spec.SecretKeySpec;
/*  8:   */ 
/*  9:   */ public class Encryptor
/* 10:   */ {
/* 11:   */   private static final String HEX = "0123456789ABCDEF";
/* 12:   */   
/* 13:   */   public static String encrypt(String seed, String cleartext)
/* 14:   */     throws Exception
/* 15:   */   {
/* 16:19 */     byte[] rawKey = getRawKey(seed.getBytes());
/* 17:20 */     byte[] result = encrypt(rawKey, cleartext.getBytes());
/* 18:21 */     return toHex(result);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public static String decrypt(String seed, String encrypted)
/* 22:   */     throws Exception
/* 23:   */   {
/* 24:25 */     byte[] rawKey = getRawKey(seed.getBytes());
/* 25:26 */     byte[] enc = toByte(encrypted);
/* 26:27 */     byte[] result = decrypt(rawKey, enc);
/* 27:28 */     return new String(result);
/* 28:   */   }
/* 29:   */   
/* 30:   */   private static byte[] getRawKey(byte[] seed)
/* 31:   */     throws Exception
/* 32:   */   {
/* 33:32 */     KeyGenerator kgen = KeyGenerator.getInstance("AES");
/* 34:33 */     SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");
/* 35:34 */     sr.setSeed(seed);
/* 36:35 */     kgen.init(256, sr);
/* 37:36 */     SecretKey skey = kgen.generateKey();
/* 38:37 */     byte[] raw = skey.getEncoded();
/* 39:38 */     return raw;
/* 40:   */   }
/* 41:   */   
/* 42:   */   private static byte[] encrypt(byte[] raw, byte[] clear)
/* 43:   */     throws Exception
/* 44:   */   {
/* 45:43 */     SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
/* 46:44 */     Cipher cipher = Cipher.getInstance("AES");
/* 47:45 */     cipher.init(1, skeySpec);
/* 48:46 */     byte[] encrypted = cipher.doFinal(clear);
/* 49:47 */     return encrypted;
/* 50:   */   }
/* 51:   */   
/* 52:   */   private static byte[] decrypt(byte[] raw, byte[] encrypted)
/* 53:   */     throws Exception
/* 54:   */   {
/* 55:51 */     SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
/* 56:52 */     Cipher cipher = Cipher.getInstance("AES");
/* 57:53 */     cipher.init(2, skeySpec);
/* 58:54 */     byte[] decrypted = cipher.doFinal(encrypted);
/* 59:55 */     return decrypted;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public static String toHex(String txt)
/* 63:   */   {
/* 64:59 */     return toHex(txt.getBytes());
/* 65:   */   }
/* 66:   */   
/* 67:   */   public static String fromHex(String hex)
/* 68:   */   {
/* 69:62 */     return new String(toByte(hex));
/* 70:   */   }
/* 71:   */   
/* 72:   */   public static byte[] toByte(String hexString)
/* 73:   */   {
/* 74:66 */     int len = hexString.length() / 2;
/* 75:67 */     byte[] result = new byte[len];
/* 76:68 */     for (int i = 0; i < len; i++) {
/* 77:69 */       result[i] = Integer.valueOf(hexString.substring(2 * i, 2 * i + 2), 16).byteValue();
/* 78:   */     }
/* 79:70 */     return result;
/* 80:   */   }
/* 81:   */   
/* 82:   */   public static String toHex(byte[] buf)
/* 83:   */   {
/* 84:74 */     if (buf == null) {
/* 85:75 */       return "";
/* 86:   */     }
/* 87:76 */     StringBuffer result = new StringBuffer(2 * buf.length);
/* 88:77 */     for (int i = 0; i < buf.length; i++) {
/* 89:78 */       appendHex(result, buf[i]);
/* 90:   */     }
/* 91:80 */     return result.toString();
/* 92:   */   }
/* 93:   */   
/* 94:   */   private static void appendHex(StringBuffer sb, byte b)
/* 95:   */   {
/* 96:84 */     sb.append("0123456789ABCDEF".charAt(b >> 4 & 0xF)).append("0123456789ABCDEF".charAt(b & 0xF));
/* 97:   */   }
/* 98:   */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.util.Encryptor
 * JD-Core Version:    0.7.0.1
 */