/*  1:   */ package com.tapjoy.mraid.util;
/*  2:   */ 
/*  3:   */ public enum NavigationStringEnum
/*  4:   */ {
/*  5: 9 */   NONE("none"),  CLOSE("close"),  BACK("back"),  FORWARD("forward"),  REFRESH("refresh");
/*  6:   */   
/*  7:   */   private String text;
/*  8:   */   
/*  9:   */   private NavigationStringEnum(String text)
/* 10:   */   {
/* 11:20 */     this.text = text;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String getText()
/* 15:   */   {
/* 16:29 */     return this.text;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public static NavigationStringEnum fromString(String text)
/* 20:   */   {
/* 21:40 */     if (text != null) {
/* 22:41 */       for (NavigationStringEnum b : values()) {
/* 23:42 */         if (text.equalsIgnoreCase(b.text)) {
/* 24:43 */           return b;
/* 25:   */         }
/* 26:   */       }
/* 27:   */     }
/* 28:47 */     return null;
/* 29:   */   }
/* 30:   */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.util.NavigationStringEnum
 * JD-Core Version:    0.7.0.1
 */