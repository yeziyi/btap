/*  1:   */ package com.tapjoy.mraid.util;
/*  2:   */ 
/*  3:   */ import android.content.BroadcastReceiver;
/*  4:   */ import android.content.Context;
/*  5:   */ import android.content.Intent;
/*  6:   */ import com.tapjoy.mraid.controller.Network;
/*  7:   */ 
/*  8:   */ public class NetworkBroadcastReceiver
/*  9:   */   extends BroadcastReceiver
/* 10:   */ {
/* 11:   */   private Network mMraidNetwork;
/* 12:   */   
/* 13:   */   public NetworkBroadcastReceiver(Network mraidNetworkController)
/* 14:   */   {
/* 15:25 */     this.mMraidNetwork = mraidNetworkController;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void onReceive(Context context, Intent intent)
/* 19:   */   {
/* 20:33 */     String action = intent.getAction();
/* 21:34 */     if (action.equals("android.net.conn.CONNECTIVITY_CHANGE")) {
/* 22:35 */       this.mMraidNetwork.onConnectionChanged();
/* 23:   */     }
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.util.NetworkBroadcastReceiver
 * JD-Core Version:    0.7.0.1
 */