/*    1:     */ package com.tapjoy.mraid.view;
/*    2:     */ 
/*    3:     */ import android.annotation.SuppressLint;
/*    4:     */ import android.app.Activity;
/*    5:     */ import android.content.ActivityNotFoundException;
/*    6:     */ import android.content.Context;
/*    7:     */ import android.content.Intent;
/*    8:     */ import android.content.res.TypedArray;
/*    9:     */ import android.graphics.Bitmap;
/*   10:     */ import android.media.MediaPlayer;
/*   11:     */ import android.media.MediaPlayer.OnCompletionListener;
/*   12:     */ import android.media.MediaPlayer.OnErrorListener;
/*   13:     */ import android.media.MediaPlayer.OnPreparedListener;
/*   14:     */ import android.net.ConnectivityManager;
/*   15:     */ import android.net.Uri;
/*   16:     */ import android.os.AsyncTask;
/*   17:     */ import android.os.Bundle;
/*   18:     */ import android.os.Handler;
/*   19:     */ import android.os.Message;
/*   20:     */ import android.util.AttributeSet;
/*   21:     */ import android.util.DisplayMetrics;
/*   22:     */ import android.view.Display;
/*   23:     */ import android.view.GestureDetector;
/*   24:     */ import android.view.GestureDetector.SimpleOnGestureListener;
/*   25:     */ import android.view.MotionEvent;
/*   26:     */ import android.view.View;
/*   27:     */ import android.view.View.OnTouchListener;
/*   28:     */ import android.view.ViewGroup;
/*   29:     */ import android.view.ViewGroup.LayoutParams;
/*   30:     */ import android.view.ViewGroup.MarginLayoutParams;
/*   31:     */ import android.view.ViewTreeObserver;
/*   32:     */ import android.view.ViewTreeObserver.OnGlobalLayoutListener;
/*   33:     */ import android.view.Window;
/*   34:     */ import android.view.WindowManager;
/*   35:     */ import android.webkit.ConsoleMessage;
/*   36:     */ import android.webkit.JsResult;
/*   37:     */ import android.webkit.URLUtil;
/*   38:     */ import android.webkit.WebBackForwardList;
/*   39:     */ import android.webkit.WebChromeClient;
/*   40:     */ import android.webkit.WebChromeClient.CustomViewCallback;
/*   41:     */ import android.webkit.WebSettings;
/*   42:     */ import android.webkit.WebView;
/*   43:     */ import android.webkit.WebViewClient;
/*   44:     */ import android.widget.FrameLayout;
/*   45:     */ import android.widget.FrameLayout.LayoutParams;
/*   46:     */ import android.widget.ProgressBar;
/*   47:     */ import android.widget.RelativeLayout;
/*   48:     */ import android.widget.RelativeLayout.LayoutParams;
/*   49:     */ import android.widget.VideoView;
/*   50:     */ import com.tapjoy.TapjoyHttpURLResponse;
/*   51:     */ import com.tapjoy.TapjoyLog;
/*   52:     */ import com.tapjoy.TapjoyURLConnection;
/*   53:     */ import com.tapjoy.TapjoyUtil;
/*   54:     */ import com.tapjoy.mraid.controller.Abstract.Dimensions;
/*   55:     */ import com.tapjoy.mraid.controller.Abstract.PlayerProperties;
/*   56:     */ import com.tapjoy.mraid.controller.Abstract.Properties;
/*   57:     */ import com.tapjoy.mraid.controller.Utility;
/*   58:     */ import com.tapjoy.mraid.listener.MraidViewListener;
/*   59:     */ import com.tapjoy.mraid.listener.Player;
/*   60:     */ import com.tapjoy.mraid.util.MraidPlayer;
/*   61:     */ import com.tapjoy.mraid.util.Utils;
/*   62:     */ import java.util.HashSet;
/*   63:     */ import java.util.TimerTask;
/*   64:     */ import java.util.regex.Matcher;
/*   65:     */ import java.util.regex.Pattern;
/*   66:     */ 
/*   67:     */ public class MraidView
/*   68:     */   extends WebView
/*   69:     */   implements ViewTreeObserver.OnGlobalLayoutListener
/*   70:     */ {
/*   71:     */   private static final String NO_CONNECTION_HTML = "<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\"><title>Connection not Established</title></head><h2>Connection Not Properly Established</h2><body></body></html>";
/*   72:     */   
/*   73:     */   public static enum VIEW_STATE
/*   74:     */   {
/*   75:  87 */     DEFAULT,  RESIZED,  EXPANDED,  HIDDEN,  LEFT_BEHIND,  OPENED;
/*   76:     */     
/*   77:     */     private VIEW_STATE() {}
/*   78:     */   }
/*   79:     */   
/*   80:     */   public static enum PLACEMENT_TYPE
/*   81:     */   {
/*   82:  92 */     INLINE,  INTERSTITIAL;
/*   83:     */     
/*   84:     */     private PLACEMENT_TYPE() {}
/*   85:     */   }
/*   86:     */   
/*   87:     */   public static enum customCloseState
/*   88:     */   {
/*   89:  96 */     HIDDEN,  OPEN,  UNKNOWN;
/*   90:     */     
/*   91:     */     private customCloseState() {}
/*   92:     */   }
/*   93:     */   
/*   94:     */   public static enum Action
/*   95:     */   {
/*   96: 100 */     PLAY_AUDIO,  PLAY_VIDEO;
/*   97:     */     
/*   98:     */     private Action() {}
/*   99:     */   }
/*  100:     */   
/*  101: 104 */   private static int[] attrs = { 16843039, 16843040 };
/*  102:     */   private static final int MESSAGE_RESIZE = 1000;
/*  103:     */   private static final int MESSAGE_CLOSE = 1001;
/*  104:     */   private static final int MESSAGE_HIDE = 1002;
/*  105:     */   private static final int MESSAGE_SHOW = 1003;
/*  106:     */   private static final int MESSAGE_EXPAND = 1004;
/*  107:     */   private static final int MESSAGE_SEND_EXPAND_CLOSE = 1005;
/*  108:     */   private static final int MESSAGE_OPEN = 1006;
/*  109:     */   private static final int MESSAGE_PLAY_VIDEO = 1007;
/*  110:     */   private static final int MESSAGE_PLAY_AUDIO = 1008;
/*  111:     */   private static final int MESSAGE_RAISE_ERROR = 1009;
/*  112:     */   private static final int MESSAGE_RESIZE_ORIENTATION = 1010;
/*  113:     */   public static final String DIMENSIONS = "expand_dimensions";
/*  114:     */   public static final String PLAYER_PROPERTIES = "player_properties";
/*  115:     */   public static final String EXPAND_URL = "expand_url";
/*  116:     */   public static final String ACTION_KEY = "action";
/*  117:     */   private static final String EXPAND_PROPERTIES = "expand_properties";
/*  118:     */   private static final String RESIZE_WIDTH = "resize_width";
/*  119:     */   private static final String RESIZE_HEIGHT = "resize_height";
/*  120:     */   private static final String RESIZE_X = "resize_x";
/*  121:     */   private static final String RESIZE_Y = "resize_y";
/*  122:     */   private static final String RESIZE_ALLOWOFFSCREEN = "resize_allowOffScreen";
/*  123:     */   private static final String RESIZE_CUSTOMCLOSEPOSITION = "resize_customClosePostition";
/*  124:     */   private static final String CURRENT_FILE = "_current_file";
/*  125:     */   private static final String AD_PATH = "AD_PATH";
/*  126:     */   private static final String ERROR_MESSAGE = "message";
/*  127:     */   private static final String ERROR_ACTION = "action";
/*  128:     */   private static final String TAG = "MRAIDView";
/*  129:     */   protected static final int BACKGROUND_ID = 101;
/*  130:     */   protected static final int PLACEHOLDER_ID = 100;
/*  131:     */   public static final int MRAID_ID = 102;
/*  132: 144 */   private static final String[] videoFormats = { ".mp4", ".3gp", ".mpg" };
/*  133: 147 */   private customCloseState closeButtonState = customCloseState.UNKNOWN;
/*  134:     */   private TimeOut mTimeOut;
/*  135:     */   private static String mScriptPath;
/*  136: 151 */   private String initialExpandUrl = null;
/*  137: 152 */   private boolean initialLoadUrl = true;
/*  138: 153 */   private boolean isMraid = false;
/*  139:     */   private boolean bPageFinished;
/*  140:     */   private Utility mUtilityController;
/*  141:     */   private float mDensity;
/*  142:     */   private int mContentViewHeight;
/*  143:     */   private boolean bKeyboardOut;
/*  144:     */   private int mDefaultHeight;
/*  145:     */   private int mDefaultWidth;
/*  146:     */   private int mDefaultX;
/*  147:     */   private int mDefaultY;
/*  148:     */   private int mInitLayoutHeight;
/*  149:     */   private int mInitLayoutWidth;
/*  150:     */   private int mIndex;
/*  151:     */   private PLACEMENT_TYPE placement;
/*  152:     */   private GestureDetector mGestureDetector;
/*  153: 176 */   private VIEW_STATE mViewState = VIEW_STATE.DEFAULT;
/*  154:     */   private MraidViewListener mListener;
/*  155:     */   private static MraidPlayer player;
/*  156:     */   private String mLocalFilePath;
/*  157: 190 */   private final HashSet<String> registeredProtocols = new HashSet();
/*  158: 193 */   private int lastScreenWidth = 0;
/*  159: 194 */   private int lastScreenHeight = 0;
/*  160: 196 */   private Thread orientationThread = null;
/*  161: 197 */   private boolean viewDetached = false;
/*  162:     */   private int originalRequestedOrientation;
/*  163:     */   private Context ctx;
/*  164:     */   private RelativeLayout videoRelativeLayout;
/*  165:     */   private VideoView videoView;
/*  166:     */   private WebChromeClient.CustomViewCallback videoViewCallback;
/*  167:     */   private ProgressBar progressBar;
/*  168:     */   
/*  169:     */   public MraidView(Context context, MraidViewListener listener)
/*  170:     */   {
/*  171: 219 */     super(context);
/*  172: 220 */     setListener(listener);
/*  173: 221 */     this.ctx = context;
/*  174: 222 */     initialize();
/*  175:     */   }
/*  176:     */   
/*  177:     */   public void setListener(MraidViewListener listener)
/*  178:     */   {
/*  179: 232 */     this.mListener = listener;
/*  180:     */   }
/*  181:     */   
/*  182:     */   public void removeListener()
/*  183:     */   {
/*  184: 239 */     this.mListener = null;
/*  185:     */   }
/*  186:     */   
/*  187:     */   public MraidView(Context context)
/*  188:     */   {
/*  189: 249 */     super(context);
/*  190: 250 */     this.ctx = context;
/*  191: 251 */     initialize();
/*  192:     */   }
/*  193:     */   
/*  194:     */   public void setPlacementType(PLACEMENT_TYPE type)
/*  195:     */   {
/*  196: 255 */     if ((type.equals(PLACEMENT_TYPE.INLINE)) || (type.equals(PLACEMENT_TYPE.INTERSTITIAL))) {
/*  197: 257 */       this.placement = type;
/*  198:     */     } else {
/*  199: 259 */       TapjoyLog.d("MRAIDView", "Incorrect placement type.");
/*  200:     */     }
/*  201: 263 */     if (type.equals(PLACEMENT_TYPE.INLINE)) {
/*  202: 265 */       if ((this.orientationThread == null) || (!this.orientationThread.isAlive()))
/*  203:     */       {
/*  204: 267 */         this.orientationThread = new Thread(new OrientationThread());
/*  205: 268 */         this.orientationThread.start();
/*  206:     */       }
/*  207:     */     }
/*  208:     */   }
/*  209:     */   
/*  210:     */   public PLACEMENT_TYPE getPlacementType()
/*  211:     */   {
/*  212: 274 */     return this.placement;
/*  213:     */   }
/*  214:     */   
/*  215:     */   public void createCloseImageButton()
/*  216:     */   {
/*  217: 278 */     String injection = "window.mraidview.createCss();";
/*  218: 279 */     injectMraidJavaScript(injection);
/*  219: 280 */     TapjoyLog.d("MRAIDView", "Creating close button.");
/*  220:     */   }
/*  221:     */   
/*  222:     */   public void removeCloseImageButton()
/*  223:     */   {
/*  224: 284 */     String injection = "document.getElementById(\"closeButton\").style.visibility=\"hidden\";";
/*  225: 285 */     injectMraidJavaScript(injection);
/*  226: 286 */     TapjoyLog.d("MRAIDView", "Removing close button.");
/*  227: 287 */     this.closeButtonState = customCloseState.HIDDEN;
/*  228:     */   }
/*  229:     */   
/*  230:     */   public void showCloseImageButton()
/*  231:     */   {
/*  232: 291 */     String injection = "document.getElementById(\"closeButton\").style.visibility=\"visible\";";
/*  233: 292 */     injectMraidJavaScript(injection);
/*  234: 293 */     TapjoyLog.d("MRAIDView", "Showing close button.");
/*  235: 294 */     this.closeButtonState = customCloseState.OPEN;
/*  236:     */   }
/*  237:     */   
/*  238:     */   public customCloseState getCloseButtonState()
/*  239:     */   {
/*  240: 298 */     return this.closeButtonState;
/*  241:     */   }
/*  242:     */   
/*  243:     */   public boolean isMraid()
/*  244:     */   {
/*  245: 305 */     return this.isMraid;
/*  246:     */   }
/*  247:     */   
/*  248:     */   public void setMaxSize(int w, int h)
/*  249:     */   {
/*  250: 317 */     this.mUtilityController.setMaxSize(w, h);
/*  251:     */   }
/*  252:     */   
/*  253:     */   public void registerProtocol(String protocol)
/*  254:     */   {
/*  255: 328 */     if (protocol != null) {
/*  256: 329 */       this.registeredProtocols.add(protocol.toLowerCase());
/*  257:     */     }
/*  258:     */   }
/*  259:     */   
/*  260:     */   public void deregisterProtocol(String protocol)
/*  261:     */   {
/*  262: 340 */     if (protocol != null) {
/*  263: 341 */       this.registeredProtocols.remove(protocol.toLowerCase());
/*  264:     */     }
/*  265:     */   }
/*  266:     */   
/*  267:     */   private boolean isRegisteredProtocol(Uri uri)
/*  268:     */   {
/*  269: 354 */     String scheme = uri.getScheme();
/*  270: 355 */     if (scheme == null) {
/*  271: 356 */       return false;
/*  272:     */     }
/*  273: 358 */     for (String protocol : this.registeredProtocols) {
/*  274: 359 */       if (protocol.equalsIgnoreCase(scheme)) {
/*  275: 360 */         return true;
/*  276:     */       }
/*  277:     */     }
/*  278: 362 */     return false;
/*  279:     */   }
/*  280:     */   
/*  281:     */   public void injectMraidJavaScript(String str)
/*  282:     */   {
/*  283: 373 */     if (str != null) {
/*  284: 376 */       if (this.isMraid) {
/*  285: 377 */         super.loadUrl("javascript:" + str);
/*  286:     */       }
/*  287:     */     }
/*  288:     */   }
/*  289:     */   
/*  290:     */   public void loadUrl(final String url)
/*  291:     */   {
/*  292: 387 */     ((Activity)this.ctx).runOnUiThread(new Runnable()
/*  293:     */     {
/*  294:     */       public void run()
/*  295:     */       {
/*  296: 392 */         if (URLUtil.isValidUrl(url))
/*  297:     */         {
/*  298: 394 */           if (url.startsWith("javascript")) {
/*  299: 395 */             MraidView.this.loadUrl(url);
/*  300:     */           } else {
/*  301: 397 */             new MraidView.MraidHTTPTask(MraidView.this, null).execute(new String[] { url });
/*  302:     */           }
/*  303:     */         }
/*  304:     */         else {
/*  305: 402 */           MraidView.this.loadDataWithBaseURL(null, "<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\"><title>Connection not Established</title></head><h2>Connection Not Properly Established</h2><body></body></html>", "text/html", "utf-8", null);
/*  306:     */         }
/*  307:     */       }
/*  308:     */     });
/*  309:     */   }
/*  310:     */   
/*  311:     */   public void loadUrlStandard(String url)
/*  312:     */   {
/*  313: 414 */     super.loadUrl(url);
/*  314:     */   }
/*  315:     */   
/*  316:     */   public boolean hasMraidTag(String html)
/*  317:     */   {
/*  318: 418 */     Pattern ormma = Pattern.compile("<\\s*script[^>]+ormma\\.js");
/*  319: 419 */     Pattern mraid = Pattern.compile("<\\s*script[^>]+mraid\\.js");
/*  320:     */     
/*  321: 421 */     Matcher mraidMatcher = mraid.matcher(html);
/*  322: 422 */     Matcher ormmaMatcher = ormma.matcher(html);
/*  323:     */     
/*  324: 424 */     return (mraidMatcher.find()) || (ormmaMatcher.find());
/*  325:     */   }
/*  326:     */   
/*  327:     */   public void loadDataWithBaseURL(String baseUrl, String data, String mimeType, String encoding, String historyUrl)
/*  328:     */   {
/*  329: 432 */     if (data == null) {
/*  330: 433 */       return;
/*  331:     */     }
/*  332: 436 */     StringBuffer buffer = new StringBuffer();
/*  333: 437 */     int htmlPresent = data.indexOf("<html>");
/*  334:     */     
/*  335: 439 */     this.isMraid = false;
/*  336:     */     
/*  337: 441 */     int start = data.indexOf("mraid.js");
/*  338: 442 */     if (start < 0) {
/*  339: 443 */       start = data.indexOf("ormma.js");
/*  340:     */     }
/*  341: 446 */     int send = start;
/*  342: 447 */     int sstart = start;
/*  343: 453 */     if ((start > 0) && (hasMraidTag(data)))
/*  344:     */     {
/*  345: 454 */       this.isMraid = true;
/*  346: 458 */       for (int i = start; i >= 0; i--) {
/*  347: 459 */         if (data.substring(i, i + 7).equals("<script"))
/*  348:     */         {
/*  349: 460 */           sstart = i;
/*  350: 461 */           break;
/*  351:     */         }
/*  352:     */       }
/*  353: 464 */       for (int i = 0; i < data.length(); i++)
/*  354:     */       {
/*  355: 465 */         if (data.substring(start + i, start + i + 2).equalsIgnoreCase("/>"))
/*  356:     */         {
/*  357: 467 */           send = i + start + 2;
/*  358: 468 */           break;
/*  359:     */         }
/*  360: 470 */         if (data.substring(start + i, start + i + 9).equalsIgnoreCase("</script>"))
/*  361:     */         {
/*  362: 472 */           send = i + start + 9;
/*  363: 473 */           break;
/*  364:     */         }
/*  365:     */       }
/*  366: 478 */       if (htmlPresent < 0)
/*  367:     */       {
/*  368: 480 */         TapjoyLog.d("MRAIDView", "wrapping fragment");
/*  369: 481 */         buffer.append("<html>");
/*  370: 482 */         buffer.append("<head>");
/*  371: 483 */         buffer.append("<meta name='viewport' content='user-scalable=no initial-scale=1.0' />");
/*  372: 484 */         buffer.append("<title>Advertisement</title>");
/*  373: 485 */         buffer.append("</head>");
/*  374: 486 */         buffer.append("<body style=\"margin:0; padding:0; overflow:hidden; background-color:transparent;\">");
/*  375: 487 */         buffer.append("<div align=\"center\"> ");
/*  376: 488 */         buffer.append(data.substring(0, sstart));
/*  377: 489 */         buffer.append("<script type=text/javascript>");
/*  378:     */         
/*  379:     */ 
/*  380: 492 */         String bigString = (String)TapjoyUtil.getResource("mraid.js");
/*  381: 495 */         if (bigString == null) {
/*  382: 496 */           bigString = TapjoyUtil.copyTextFromJarIntoString("js/mraid.js", getContext());
/*  383:     */         }
/*  384: 499 */         buffer.append(bigString);
/*  385: 500 */         buffer.append("</script>");
/*  386: 501 */         buffer.append(data.substring(send));
/*  387:     */       }
/*  388:     */       else
/*  389:     */       {
/*  390: 503 */         int headStart = data.indexOf("<head>");
/*  391: 504 */         if (headStart != -1)
/*  392:     */         {
/*  393: 506 */           String bigString = (String)TapjoyUtil.getResource("mraid.js");
/*  394: 509 */           if (bigString == null) {
/*  395: 510 */             bigString = TapjoyUtil.copyTextFromJarIntoString("js/mraid.js", getContext());
/*  396:     */           }
/*  397: 513 */           buffer.append(data.substring(0, headStart + 6));
/*  398: 514 */           buffer.append("<script type='text/javascript'>");
/*  399: 515 */           buffer.append(bigString);
/*  400: 516 */           buffer.append("</script>");
/*  401: 517 */           buffer.append(data.substring(headStart + 6));
/*  402:     */         }
/*  403:     */       }
/*  404: 520 */       TapjoyLog.d("MRAIDView", "injected js/mraid.js");
/*  405:     */     }
/*  406:     */     else
/*  407:     */     {
/*  408: 523 */       buffer.append(data);
/*  409:     */     }
/*  410: 526 */     super.loadDataWithBaseURL(baseUrl, buffer.toString(), mimeType, encoding, historyUrl);
/*  411:     */   }
/*  412:     */   
/*  413:     */   class TimeOut
/*  414:     */     extends TimerTask
/*  415:     */   {
/*  416: 537 */     int mProgress = 0;
/*  417: 538 */     int mCount = 0;
/*  418:     */     
/*  419:     */     TimeOut() {}
/*  420:     */     
/*  421:     */     public void run()
/*  422:     */     {
/*  423: 542 */       int progress = MraidView.this.getProgress();
/*  424: 543 */       if (progress == 100)
/*  425:     */       {
/*  426: 544 */         cancel();
/*  427:     */       }
/*  428: 546 */       else if (this.mProgress == progress)
/*  429:     */       {
/*  430: 547 */         this.mCount += 1;
/*  431: 548 */         if (this.mCount == 3)
/*  432:     */         {
/*  433:     */           try
/*  434:     */           {
/*  435: 550 */             MraidView.this.stopLoading();
/*  436:     */           }
/*  437:     */           catch (Exception e)
/*  438:     */           {
/*  439: 552 */             TapjoyLog.w("MRAIDView", "error in stopLoading");
/*  440: 553 */             e.printStackTrace();
/*  441:     */           }
/*  442: 555 */           cancel();
/*  443:     */         }
/*  444:     */       }
/*  445: 559 */       this.mProgress = progress;
/*  446:     */     }
/*  447:     */   }
/*  448:     */   
/*  449:     */   public void clearView()
/*  450:     */   {
/*  451: 565 */     reset();
/*  452: 566 */     super.clearView();
/*  453:     */   }
/*  454:     */   
/*  455:     */   public void reset()
/*  456:     */   {
/*  457: 573 */     if (this.mViewState == VIEW_STATE.EXPANDED) {
/*  458: 574 */       closeExpanded();
/*  459: 575 */     } else if (this.mViewState == VIEW_STATE.RESIZED) {
/*  460: 576 */       closeResized();
/*  461:     */     }
/*  462: 578 */     invalidate();
/*  463: 579 */     this.mUtilityController.deleteOldAds();
/*  464: 580 */     this.mUtilityController.stopAllListeners();
/*  465: 581 */     resetLayout();
/*  466:     */   }
/*  467:     */   
/*  468:     */   public MraidView(Context context, AttributeSet set)
/*  469:     */   {
/*  470: 593 */     super(context, set);
/*  471: 594 */     initialize();
/*  472: 595 */     TypedArray a = getContext().obtainStyledAttributes(set, attrs);
/*  473: 596 */     int w = a.getDimensionPixelSize(0, -1);
/*  474: 597 */     int h = a.getDimensionPixelSize(1, -1);
/*  475: 598 */     if ((w > 0) && (h > 0)) {
/*  476: 599 */       this.mUtilityController.setMaxSize(w, h);
/*  477:     */     }
/*  478: 600 */     a.recycle();
/*  479:     */   }
/*  480:     */   
/*  481:     */   private void repositionCloseButton(String position)
/*  482:     */   {
/*  483: 611 */     if (position == null) {
/*  484: 612 */       return;
/*  485:     */     }
/*  486: 613 */     String injection = null;
/*  487: 614 */     if (position.equals("top-right")) {
/*  488: 615 */       injection = "document.getElementById(\"closeButton\").style.right = 1;document.getElementById(\"closeButton\").style.top = 1;document.getElementById(\"closeButton\").style.bottom = mraid.getSize().height -36;document.getElementById(\"closeButton\").style.left = mraid.getSize().width -36";
/*  489: 618 */     } else if (position.equals("top-center")) {
/*  490: 619 */       injection = "document.getElementById(\"closeButton\").style.right = mraid.getSize().width/2 - 18;document.getElementById(\"closeButton\").style.top = 1;document.getElementById(\"closeButton\").style.bottom = mraid.getSize().height -36;document.getElementById(\"closeButton\").style.left = mraid.getSize().width/2 -18";
/*  491: 622 */     } else if (position.equals("top-left")) {
/*  492: 623 */       injection = "document.getElementById(\"closeButton\").style.right = mraid.getSize().width -36;document.getElementById(\"closeButton\").style.top = 1;document.getElementById(\"closeButton\").style.bottom = mraid.getSize().height -36;document.getElementById(\"closeButton\").style.left = 1";
/*  493: 626 */     } else if (position.equals("center")) {
/*  494: 627 */       injection = "document.getElementById(\"closeButton\").style.right = mraid.getSize().width/2 - 18;document.getElementById(\"closeButton\").style.top = mraid.getSize().height/2 -18;document.getElementById(\"closeButton\").style.bottom = mraid.getSize().height/2 -18;document.getElementById(\"closeButton\").style.left = mraid.getSize().width/2 -18";
/*  495: 630 */     } else if (position.equals("bottom-right")) {
/*  496: 631 */       injection = "document.getElementById(\"closeButton\").style.right = 1;document.getElementById(\"closeButton\").style.top = mraid.getSize().height -36;document.getElementById(\"closeButton\").style.bottom = 1;document.getElementById(\"closeButton\").style.left = mraid.getSize().width -36";
/*  497: 633 */     } else if (position.equals("bottom-left")) {
/*  498: 634 */       injection = "document.getElementById(\"closeButton\").style.left = 1;document.getElementById(\"closeButton\").style.bottom = 1;document.getElementById(\"closeButton\").style.right = mraid.getSize().width -36;document.getElementById(\"closeButton\").style.top = mraid.getSize().height-36;";
/*  499: 637 */     } else if (position.equals("bottom-center")) {
/*  500: 638 */       injection = "document.getElementById(\"closeButton\").style.bottom = 1;document.getElementById(\"closeButton\").style.right = mraid.getSize().width -36document.getElementById(\"closeButton\").style.right = mraid.getSize().width/2 -18;document.getElementById(\"closeButton\").style.top = mraid.getSize().height-36;";
/*  501:     */     }
/*  502: 642 */     if (injection != null) {
/*  503: 643 */       injectMraidJavaScript(injection);
/*  504:     */     } else {
/*  505: 645 */       TapjoyLog.d("MRAIDView", "Reposition of close button failed.");
/*  506:     */     }
/*  507:     */   }
/*  508:     */   
/*  509: 652 */   private Handler mHandler = new Handler()
/*  510:     */   {
/*  511:     */     public void handleMessage(Message msg)
/*  512:     */     {
/*  513: 657 */       Bundle data = msg.getData();
/*  514: 658 */       switch (msg.what)
/*  515:     */       {
/*  516:     */       case 1005: 
/*  517: 661 */         if (MraidView.this.mListener != null) {
/*  518: 662 */           MraidView.this.mListener.onExpandClose();
/*  519:     */         }
/*  520:     */         break;
/*  521:     */       case 1000: 
/*  522: 667 */         ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams)MraidView.this.getLayoutParams();
/*  523: 670 */         if (lp != null)
/*  524:     */         {
/*  525: 672 */           MraidView.this.removeCloseImageButton();
/*  526: 673 */           MraidView.this.mViewState = MraidView.VIEW_STATE.RESIZED;
/*  527:     */           
/*  528: 675 */           lp.height = data.getInt("resize_height", lp.height);
/*  529: 676 */           lp.width = data.getInt("resize_width", lp.width);
/*  530: 677 */           lp.leftMargin = data.getInt("resize_x", lp.leftMargin);
/*  531: 678 */           lp.topMargin = data.getInt("resize_y", lp.topMargin);
/*  532: 679 */           String injection = "window.mraidview.fireChangeEvent({ state: 'resized', size: { width: " + lp.width + ", " + "height: " + lp.height + ", " + "x: " + lp.leftMargin + ", " + "y: " + lp.topMargin + "}});";
/*  533:     */           
/*  534:     */ 
/*  535:     */ 
/*  536:     */ 
/*  537:     */ 
/*  538:     */ 
/*  539:     */ 
/*  540:     */ 
/*  541:     */ 
/*  542:     */ 
/*  543: 690 */           MraidView.this.injectMraidJavaScript(injection);
/*  544:     */           
/*  545: 692 */           MraidView.this.requestLayout();
/*  546: 693 */           MraidView.this.repositionCloseButton(data.getString("resize_customClosePostition"));
/*  547:     */           
/*  548: 695 */           MraidView.this.showCloseImageButton();
/*  549:     */         }
/*  550: 698 */         if (MraidView.this.mListener != null) {
/*  551: 699 */           MraidView.this.mListener.onResize();
/*  552:     */         }
/*  553:     */         break;
/*  554:     */       case 1010: 
/*  555: 706 */         ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams)MraidView.this.getLayoutParams();
/*  556: 709 */         if (lp != null)
/*  557:     */         {
/*  558: 711 */           MraidView.this.removeCloseImageButton();
/*  559: 712 */           lp.height = data.getInt("resize_height", lp.height);
/*  560: 713 */           lp.width = data.getInt("resize_width", lp.width);
/*  561:     */           
/*  562:     */ 
/*  563: 716 */           String injection = "window.mraidview.fireChangeEvent({ state: '" + MraidView.this.getState() + "'," + " size: { width: " + (int)(lp.width / MraidView.this.mDensity) + ", " + "height: " + (int)(lp.height / MraidView.this.mDensity) + "}" + "});";
/*  564:     */           
/*  565:     */ 
/*  566:     */ 
/*  567:     */ 
/*  568:     */ 
/*  569:     */ 
/*  570:     */ 
/*  571: 724 */           TapjoyLog.i("MRAIDView", "resize: injection: " + injection);
/*  572: 725 */           MraidView.this.injectMraidJavaScript(injection);
/*  573:     */           
/*  574: 727 */           MraidView.this.requestLayout();
/*  575: 728 */           MraidView.this.repositionCloseButton(data.getString("resize_customClosePostition"));
/*  576: 730 */           if ((MraidView.this.placement != MraidView.PLACEMENT_TYPE.INLINE) && (MraidView.this.closeButtonState == MraidView.customCloseState.OPEN)) {
/*  577: 731 */             MraidView.this.showCloseImageButton();
/*  578:     */           }
/*  579:     */         }
/*  580: 735 */         if (MraidView.this.mListener != null) {
/*  581: 736 */           MraidView.this.mListener.onResize();
/*  582:     */         }
/*  583:     */         break;
/*  584:     */       case 1001: 
/*  585: 742 */         switch (MraidView.7.$SwitchMap$com$tapjoy$mraid$view$MraidView$VIEW_STATE[MraidView.this.mViewState.ordinal()])
/*  586:     */         {
/*  587:     */         case 1: 
/*  588: 745 */           MraidView.this.closeResized();
/*  589: 746 */           break;
/*  590:     */         case 2: 
/*  591: 748 */           MraidView.this.closeExpanded();
/*  592: 749 */           break;
/*  593:     */         case 3: 
/*  594: 751 */           if (MraidView.this.placement != MraidView.PLACEMENT_TYPE.INLINE) {
/*  595: 752 */             MraidView.this.closeWindow();
/*  596:     */           }
/*  597:     */           break;
/*  598:     */         }
/*  599: 754 */         break;
/*  600:     */       case 1002: 
/*  601: 759 */         MraidView.this.setVisibility(4);
/*  602: 760 */         String injection = "window.mraidview.fireChangeEvent({ state: 'hidden' });";
/*  603: 761 */         MraidView.this.injectMraidJavaScript(injection);
/*  604: 762 */         break;
/*  605:     */       case 1003: 
/*  606: 767 */         String injection = "window.mraidview.fireChangeEvent({ state: 'default' });";
/*  607: 768 */         MraidView.this.injectMraidJavaScript(injection);
/*  608: 769 */         MraidView.this.setVisibility(0);
/*  609: 770 */         break;
/*  610:     */       case 1004: 
/*  611: 775 */         MraidView.this.doExpand(data);
/*  612: 776 */         break;
/*  613:     */       case 1006: 
/*  614: 781 */         MraidView.this.mViewState = MraidView.VIEW_STATE.LEFT_BEHIND;
/*  615: 782 */         break;
/*  616:     */       case 1008: 
/*  617: 787 */         MraidView.this.playAudioImpl(data);
/*  618: 788 */         break;
/*  619:     */       case 1007: 
/*  620: 793 */         MraidView.this.playVideoImpl(data);
/*  621: 794 */         break;
/*  622:     */       case 1009: 
/*  623: 799 */         String strMsg = data.getString("message");
/*  624: 800 */         String action = data.getString("action");
/*  625: 801 */         String injection = "window.mraidview.fireErrorEvent(\"" + strMsg + "\", \"" + action + "\")";
/*  626:     */         
/*  627: 803 */         MraidView.this.injectMraidJavaScript(injection);
/*  628: 804 */         break;
/*  629:     */       }
/*  630: 808 */       super.handleMessage(msg);
/*  631:     */     }
/*  632:     */   };
/*  633:     */   
/*  634:     */   private void closeWindow()
/*  635:     */   {
/*  636: 814 */     if (this.mListener != null) {
/*  637: 816 */       this.mListener.onClose();
/*  638:     */     }
/*  639: 818 */     ViewGroup vg = (ViewGroup)getParent();
/*  640: 819 */     vg.removeView(this);
/*  641:     */   }
/*  642:     */   
/*  643:     */   private FrameLayout changeContentArea(Abstract.Dimensions d)
/*  644:     */   {
/*  645: 831 */     FrameLayout contentView = (FrameLayout)getRootView().findViewById(16908290);
/*  646:     */     
/*  647: 833 */     ViewGroup parent = (ViewGroup)getParent();
/*  648: 834 */     FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(d.width, d.height);
/*  649:     */     
/*  650: 836 */     fl.topMargin = d.x;
/*  651: 837 */     fl.leftMargin = d.y;
/*  652: 838 */     int index = 0;
/*  653: 839 */     int count = parent.getChildCount();
/*  654: 840 */     for (index = 0; index < count; index++) {
/*  655: 841 */       if (parent.getChildAt(index) == this) {
/*  656:     */         break;
/*  657:     */       }
/*  658:     */     }
/*  659: 844 */     this.mIndex = index;
/*  660: 845 */     FrameLayout placeHolder = new FrameLayout(getContext());
/*  661: 846 */     placeHolder.setId(100);
/*  662: 847 */     ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(getWidth(), getHeight());
/*  663:     */     
/*  664: 849 */     parent.addView(placeHolder, index, lp);
/*  665: 850 */     parent.removeView(this);
/*  666: 851 */     FrameLayout backGround = new FrameLayout(getContext());
/*  667: 852 */     backGround.setOnTouchListener(new View.OnTouchListener()
/*  668:     */     {
/*  669:     */       public boolean onTouch(View arg0, MotionEvent arg1)
/*  670:     */       {
/*  671: 855 */         TapjoyLog.i("MRAIDView", "background touch called");
/*  672: 856 */         return true;
/*  673:     */       }
/*  674: 858 */     });
/*  675: 859 */     FrameLayout.LayoutParams bgfl = new FrameLayout.LayoutParams(-1, -1);
/*  676:     */     
/*  677:     */ 
/*  678: 862 */     backGround.setId(101);
/*  679: 863 */     backGround.setPadding(d.x, d.y, 0, 0);
/*  680: 864 */     backGround.addView(this, fl);
/*  681: 865 */     contentView.addView(backGround, bgfl);
/*  682: 866 */     return backGround;
/*  683:     */   }
/*  684:     */   
/*  685:     */   private void doExpand(Bundle data)
/*  686:     */   {
/*  687: 873 */     if (this.mViewState == VIEW_STATE.EXPANDED) {
/*  688: 874 */       return;
/*  689:     */     }
/*  690: 875 */     Abstract.Dimensions d = (Abstract.Dimensions)data.getParcelable("expand_dimensions");
/*  691: 876 */     String url = data.getString("expand_url");
/*  692: 877 */     Abstract.Properties p = (Abstract.Properties)data.getParcelable("expand_properties");
/*  693: 878 */     if (URLUtil.isValidUrl(url)) {
/*  694: 879 */       loadUrl(url);
/*  695:     */     }
/*  696: 881 */     FrameLayout backGround = changeContentArea(d);
/*  697: 882 */     if (p.useBackground)
/*  698:     */     {
/*  699: 883 */       int color = p.backgroundColor | (int)(p.backgroundOpacity * 255.0F) * 268435456;
/*  700:     */       
/*  701: 885 */       backGround.setBackgroundColor(color);
/*  702:     */     }
/*  703: 887 */     if (!p.useCustomClose) {
/*  704: 888 */       showCloseImageButton();
/*  705:     */     }
/*  706: 890 */     String injection = "window.mraidview.fireChangeEvent({ state: 'expanded', size: { width: " + (int)(d.width / this.mDensity) + ", " + "height: " + (int)(d.height / this.mDensity) + "," + "x:0," + "y:0" + "}" + " });";
/*  707:     */     
/*  708:     */ 
/*  709:     */ 
/*  710:     */ 
/*  711:     */ 
/*  712:     */ 
/*  713:     */ 
/*  714:     */ 
/*  715:     */ 
/*  716:     */ 
/*  717:     */ 
/*  718: 902 */     TapjoyLog.d("MRAIDView", "doExpand: injection: " + injection);
/*  719: 903 */     injectMraidJavaScript(injection);
/*  720:     */     
/*  721: 905 */     this.mViewState = VIEW_STATE.EXPANDED;
/*  722:     */     
/*  723:     */ 
/*  724:     */ 
/*  725:     */ 
/*  726:     */ 
/*  727:     */ 
/*  728: 912 */     checkForOrientationChange();
/*  729: 914 */     if (this.mListener != null) {
/*  730: 915 */       this.mListener.onExpand();
/*  731:     */     }
/*  732:     */   }
/*  733:     */   
/*  734:     */   private void closeResized()
/*  735:     */   {
/*  736: 922 */     this.mViewState = VIEW_STATE.DEFAULT;
/*  737: 923 */     if (this.mListener != null) {
/*  738: 924 */       this.mListener.onResizeClose();
/*  739:     */     }
/*  740: 926 */     String injection = "window.mraidview.fireChangeEvent({ state: 'default', size: { width: " + this.mDefaultWidth + ", " + "height: " + this.mDefaultHeight + ", " + "x:0" + "," + "y:0" + "}" + "});";
/*  741:     */     
/*  742:     */ 
/*  743:     */ 
/*  744:     */ 
/*  745:     */ 
/*  746:     */ 
/*  747: 933 */     TapjoyLog.d("MRAIDView", "closeResized: injection: " + injection);
/*  748: 934 */     injectMraidJavaScript(injection);
/*  749: 935 */     repositionCloseButton("top-right");
/*  750: 936 */     resetLayout();
/*  751:     */   }
/*  752:     */   
/*  753: 942 */   WebViewClient mWebViewClient = new WebViewClient()
/*  754:     */   {
/*  755:     */     public void onPageStarted(WebView view, String url, Bitmap favicon)
/*  756:     */     {
/*  757: 947 */       if (MraidView.this.mListener != null) {
/*  758: 948 */         MraidView.this.mListener.onPageStarted(view, url, favicon);
/*  759:     */       }
/*  760:     */     }
/*  761:     */     
/*  762:     */     public void onReceivedError(WebView view, int errorCode, String description, String failingUrl)
/*  763:     */     {
/*  764: 954 */       if (MraidView.this.mListener != null) {
/*  765: 956 */         MraidView.this.mListener.onReceivedError(view, errorCode, description, failingUrl);
/*  766:     */       }
/*  767: 959 */       TapjoyLog.d("MRAIDView", "error:" + description);
/*  768: 960 */       super.onReceivedError(view, errorCode, description, failingUrl);
/*  769:     */     }
/*  770:     */     
/*  771:     */     public void onPageFinished(WebView view, String url)
/*  772:     */     {
/*  773: 966 */       if (MraidView.this.mListener != null) {
/*  774: 968 */         MraidView.this.mListener.onPageFinished(view, url);
/*  775:     */       }
/*  776: 971 */       MraidView.this.mDefaultHeight = ((int)(MraidView.this.getHeight() / MraidView.this.mDensity));
/*  777: 972 */       MraidView.this.mDefaultWidth = ((int)(MraidView.this.getWidth() / MraidView.this.mDensity));
/*  778: 973 */       MraidView.this.mUtilityController.init(MraidView.this.mDensity);
/*  779:     */       
/*  780: 975 */       MraidView.this.createCloseImageButton();
/*  781: 976 */       if (MraidView.this.placement == MraidView.PLACEMENT_TYPE.INLINE) {
/*  782: 977 */         MraidView.this.removeCloseImageButton();
/*  783:     */       }
/*  784:     */     }
/*  785:     */     
/*  786:     */     public boolean shouldOverrideUrlLoading(WebView view, String url)
/*  787:     */     {
/*  788: 984 */       TapjoyLog.i("MRAIDView", "shouldOverrideUrlLoading: " + url);
/*  789: 987 */       if ((MraidView.this.mListener != null) && (MraidView.this.mListener.shouldOverrideUrlLoading(view, url) == true)) {
/*  790: 989 */         return true;
/*  791:     */       }
/*  792: 994 */       Uri uri = Uri.parse(url);
/*  793:     */       try
/*  794:     */       {
/*  795: 998 */         if (url.startsWith("mraid")) {
/*  796: 999 */           return super.shouldOverrideUrlLoading(view, url);
/*  797:     */         }
/*  798:1001 */         if (url.startsWith("tel:"))
/*  799:     */         {
/*  800:1002 */           Intent intent = new Intent("android.intent.action.DIAL", Uri.parse(url));
/*  801:     */           
/*  802:1004 */           intent.addFlags(268435456);
/*  803:1005 */           MraidView.this.getContext().startActivity(intent);
/*  804:1006 */           return true;
/*  805:     */         }
/*  806:1008 */         if (url.startsWith("mailto:"))
/*  807:     */         {
/*  808:1009 */           Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
/*  809:     */           
/*  810:1011 */           intent.addFlags(268435456);
/*  811:1012 */           MraidView.this.getContext().startActivity(intent);
/*  812:1013 */           return true;
/*  813:     */         }
/*  814:1015 */         Intent intent = new Intent();
/*  815:1016 */         intent.setAction("android.intent.action.VIEW");
/*  816:1017 */         intent.setData(uri);
/*  817:1018 */         intent.addFlags(268435456);
/*  818:1019 */         MraidView.this.getContext().startActivity(intent);
/*  819:1020 */         return true;
/*  820:     */       }
/*  821:     */       catch (Exception e)
/*  822:     */       {
/*  823:     */         try
/*  824:     */         {
/*  825:1025 */           Intent intent = new Intent();
/*  826:1026 */           intent.setAction("android.intent.action.VIEW");
/*  827:1027 */           intent.setData(uri);
/*  828:1028 */           intent.addFlags(268435456);
/*  829:1029 */           MraidView.this.getContext().startActivity(intent);
/*  830:1030 */           return true;
/*  831:     */         }
/*  832:     */         catch (Exception e2) {}
/*  833:     */       }
/*  834:1032 */       return false;
/*  835:     */     }
/*  836:     */     
/*  837:     */     public void onLoadResource(WebView view, String url) {}
/*  838:     */   };
/*  839:1047 */   WebChromeClient mWebChromeClient = new WebChromeClient()
/*  840:     */   {
/*  841:     */     public boolean onJsAlert(WebView view, String url, String message, JsResult result)
/*  842:     */     {
/*  843:1051 */       TapjoyLog.d("MRAIDView", message);
/*  844:1052 */       return false;
/*  845:     */     }
/*  846:     */     
/*  847:     */     public void onCloseWindow(WebView w)
/*  848:     */     {
/*  849:1057 */       super.onCloseWindow(w);
/*  850:1058 */       MraidView.this.closeWindow();
/*  851:     */     }
/*  852:     */     
/*  853:     */     public void onShowCustomView(View view, WebChromeClient.CustomViewCallback callback)
/*  854:     */     {
/*  855:1064 */       TapjoyLog.i("MRAIDView", "-- onShowCustomView --");
/*  856:1065 */       super.onShowCustomView(view, callback);
/*  857:     */       
/*  858:1067 */       MraidView.this.videoViewCallback = callback;
/*  859:1069 */       if ((view instanceof FrameLayout))
/*  860:     */       {
/*  861:1071 */         FrameLayout frame = (FrameLayout)view;
/*  862:1072 */         if ((frame.getFocusedChild() instanceof VideoView))
/*  863:     */         {
/*  864:1075 */           if (!(MraidView.this.ctx instanceof Activity)) {
/*  865:1076 */             return;
/*  866:     */           }
/*  867:1078 */           Activity activity = (Activity)MraidView.this.ctx;
/*  868:     */           
/*  869:1080 */           MraidView.this.videoView = ((VideoView)frame.getFocusedChild());
/*  870:     */           
/*  871:1082 */           frame.removeView(MraidView.this.videoView);
/*  872:1084 */           if (MraidView.this.videoRelativeLayout == null)
/*  873:     */           {
/*  874:1086 */             MraidView.this.videoRelativeLayout = new RelativeLayout(MraidView.this.ctx);
/*  875:1087 */             MraidView.this.videoRelativeLayout.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
/*  876:1088 */             MraidView.this.videoRelativeLayout.setBackgroundColor(-16777216);
/*  877:     */           }
/*  878:1093 */           RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
/*  879:1094 */           layoutParams.addRule(13);
/*  880:1095 */           MraidView.this.videoView.setLayoutParams(layoutParams);
/*  881:     */           
/*  882:     */ 
/*  883:1098 */           MraidView.this.progressBar = new ProgressBar(MraidView.this.ctx, null, 16842874);
/*  884:1099 */           MraidView.this.progressBar.setVisibility(0);
/*  885:     */           
/*  886:     */ 
/*  887:1102 */           RelativeLayout.LayoutParams progressParams = new RelativeLayout.LayoutParams(-2, -2);
/*  888:1103 */           progressParams.addRule(13);
/*  889:1104 */           MraidView.this.progressBar.setLayoutParams(progressParams);
/*  890:     */           
/*  891:1106 */           MraidView.this.videoRelativeLayout.addView(MraidView.this.videoView);
/*  892:1107 */           MraidView.this.videoRelativeLayout.addView(MraidView.this.progressBar);
/*  893:1108 */           activity.getWindow().addContentView(MraidView.this.videoRelativeLayout, new ViewGroup.LayoutParams(-1, -1));
/*  894:     */           
/*  895:     */ 
/*  896:1111 */           new Thread(new MraidView.VideoLoadingThread(MraidView.this)).start();
/*  897:     */           
/*  898:     */ 
/*  899:     */ 
/*  900:1115 */           MraidView.this.setVisibility(8);
/*  901:     */           
/*  902:1117 */           MraidView.this.videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener()
/*  903:     */           {
/*  904:     */             public void onPrepared(MediaPlayer mp)
/*  905:     */             {
/*  906:1122 */               TapjoyLog.i("MRAIDView", "** ON PREPARED **");
/*  907:1123 */               TapjoyLog.i("MRAIDView", "isPlaying: " + mp.isPlaying());
/*  908:1126 */               if (!mp.isPlaying()) {
/*  909:1127 */                 mp.start();
/*  910:     */               }
/*  911:     */             }
/*  912:1130 */           });
/*  913:1131 */           MraidView.this.videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener()
/*  914:     */           {
/*  915:     */             public void onCompletion(MediaPlayer mp)
/*  916:     */             {
/*  917:1136 */               TapjoyLog.i("MRAIDView", "** ON COMPLETION **");
/*  918:     */               
/*  919:1138 */               MraidView.this.videoViewCleanup();
/*  920:     */             }
/*  921:1141 */           });
/*  922:1142 */           MraidView.this.videoView.setOnErrorListener(new MediaPlayer.OnErrorListener()
/*  923:     */           {
/*  924:     */             public boolean onError(MediaPlayer mp, int what, int extra)
/*  925:     */             {
/*  926:1147 */               TapjoyLog.i("MRAIDView", "** ON ERROR **");
/*  927:1148 */               MraidView.this.videoViewCleanup();
/*  928:1149 */               return false;
/*  929:     */             }
/*  930:1152 */           });
/*  931:1153 */           MraidView.this.videoView.start();
/*  932:     */         }
/*  933:     */       }
/*  934:     */     }
/*  935:     */     
/*  936:     */     public void onHideCustomView()
/*  937:     */     {
/*  938:1161 */       super.onHideCustomView();
/*  939:     */     }
/*  940:     */     
/*  941:     */     public boolean onConsoleMessage(ConsoleMessage consoleMessage)
/*  942:     */     {
/*  943:1167 */       if (MraidView.this.mListener != null) {
/*  944:1168 */         return MraidView.this.mListener.onConsoleMessage(consoleMessage);
/*  945:     */       }
/*  946:1170 */       return super.onConsoleMessage(consoleMessage);
/*  947:     */     }
/*  948:     */   };
/*  949:     */   private boolean bGotLayoutParams;
/*  950:     */   
/*  951:     */   public boolean videoPlaying()
/*  952:     */   {
/*  953:1176 */     return this.videoView != null;
/*  954:     */   }
/*  955:     */   
/*  956:     */   public void videoViewCleanup()
/*  957:     */   {
/*  958:1185 */     if (this.videoRelativeLayout != null)
/*  959:     */     {
/*  960:1187 */       ((ViewGroup)this.videoRelativeLayout.getParent()).removeView(this.videoRelativeLayout);
/*  961:1188 */       this.videoRelativeLayout.setVisibility(8);
/*  962:1189 */       this.videoRelativeLayout = null;
/*  963:     */     }
/*  964:     */     try
/*  965:     */     {
/*  966:1195 */       if (this.videoView != null) {
/*  967:1196 */         this.videoView.stopPlayback();
/*  968:     */       }
/*  969:1198 */       if (this.videoViewCallback != null) {
/*  970:1199 */         this.videoViewCallback.onCustomViewHidden();
/*  971:     */       }
/*  972:     */     }
/*  973:     */     catch (Exception e)
/*  974:     */     {
/*  975:1203 */       e.printStackTrace();
/*  976:     */     }
/*  977:1206 */     this.videoView = null;
/*  978:1207 */     this.videoViewCallback = null;
/*  979:1210 */     if (this != null) {
/*  980:1211 */       setVisibility(0);
/*  981:     */     }
/*  982:1213 */     loadUrl("javascript:try{Tapjoy.AdUnit.dispatchEvent('videoend')}catch(e){}");
/*  983:     */   }
/*  984:     */   
/*  985:     */   @SuppressLint({"SetJavaScriptEnabled"})
/*  986:     */   public void initialize()
/*  987:     */   {
/*  988:1226 */     setPlacementType(PLACEMENT_TYPE.INTERSTITIAL);
/*  989:1227 */     setScrollContainer(false);
/*  990:1228 */     setVerticalScrollBarEnabled(false);
/*  991:1229 */     setHorizontalScrollBarEnabled(false);
/*  992:1230 */     this.mGestureDetector = new GestureDetector(new ScrollEater());
/*  993:     */     
/*  994:1232 */     setBackgroundColor(0);
/*  995:1233 */     DisplayMetrics metrics = new DisplayMetrics();
/*  996:1234 */     WindowManager wm = (WindowManager)getContext().getSystemService("window");
/*  997:     */     
/*  998:     */ 
/*  999:1237 */     wm.getDefaultDisplay().getMetrics(metrics);
/* 1000:1238 */     this.mDensity = metrics.density;
/* 1001:     */     
/* 1002:1240 */     this.bPageFinished = false;
/* 1003:1242 */     if (getSettings() != null) {
/* 1004:1244 */       getSettings().setJavaScriptEnabled(true);
/* 1005:     */     }
/* 1006:1247 */     this.mUtilityController = new Utility(this, getContext());
/* 1007:     */     
/* 1008:1249 */     addJavascriptInterface(this.mUtilityController, "MRAIDUtilityControllerBridge");
/* 1009:     */     
/* 1010:     */ 
/* 1011:1252 */     setWebViewClient(this.mWebViewClient);
/* 1012:     */     
/* 1013:1254 */     setWebChromeClient(this.mWebChromeClient);
/* 1014:1255 */     setScriptPath();
/* 1015:     */     
/* 1016:1257 */     this.mContentViewHeight = getContentViewHeight();
/* 1017:1259 */     if (getViewTreeObserver() != null) {
/* 1018:1260 */       getViewTreeObserver().addOnGlobalLayoutListener(this);
/* 1019:     */     }
/* 1020:1263 */     WindowManager windowManager = (WindowManager)getContext().getSystemService("window");
/* 1021:1264 */     this.lastScreenWidth = windowManager.getDefaultDisplay().getWidth();
/* 1022:1265 */     this.lastScreenHeight = windowManager.getDefaultDisplay().getHeight();
/* 1023:     */     
/* 1024:1267 */     this.originalRequestedOrientation = ((Activity)getContext()).getRequestedOrientation();
/* 1025:     */   }
/* 1026:     */   
/* 1027:     */   private class OrientationThread
/* 1028:     */     implements Runnable
/* 1029:     */   {
/* 1030:     */     public OrientationThread() {}
/* 1031:     */     
/* 1032:     */     public void run()
/* 1033:     */     {
/* 1034:1282 */       while (!MraidView.this.viewDetached) {
/* 1035:     */         try
/* 1036:     */         {
/* 1037:1286 */           Thread.sleep(250L);
/* 1038:1287 */           MraidView.this.checkForOrientationChange();
/* 1039:     */         }
/* 1040:     */         catch (Exception e) {}
/* 1041:     */       }
/* 1042:     */     }
/* 1043:     */   }
/* 1044:     */   
/* 1045:     */   private class VideoLoadingThread
/* 1046:     */     implements Runnable
/* 1047:     */   {
/* 1048:     */     public VideoLoadingThread() {}
/* 1049:     */     
/* 1050:     */     public void run()
/* 1051:     */     {
/* 1052:1307 */       int elapsed = 0;
/* 1053:1310 */       while ((MraidView.this.videoView != null) && (!MraidView.this.videoView.isPlaying())) {
/* 1054:     */         try
/* 1055:     */         {
/* 1056:1314 */           Thread.sleep(50L);
/* 1057:1315 */           elapsed += 50;
/* 1058:1318 */           if (elapsed >= 10000) {
/* 1059:     */             break;
/* 1060:     */           }
/* 1061:     */         }
/* 1062:     */         catch (Exception e) {}
/* 1063:     */       }
/* 1064:1324 */       ((Activity)MraidView.this.ctx).runOnUiThread(new Runnable()
/* 1065:     */       {
/* 1066:     */         public void run()
/* 1067:     */         {
/* 1068:1329 */           if (MraidView.this.progressBar != null) {
/* 1069:1330 */             MraidView.this.progressBar.setVisibility(8);
/* 1070:     */           }
/* 1071:1332 */           new Thread(new MraidView.VideoLoadingThread.VideoRunningThread(MraidView.VideoLoadingThread.this)).start();
/* 1072:     */         }
/* 1073:     */       });
/* 1074:     */     }
/* 1075:     */     
/* 1076:     */     private class VideoRunningThread
/* 1077:     */       implements Runnable
/* 1078:     */     {
/* 1079:1342 */       private boolean playing = false;
/* 1080:     */       
/* 1081:     */       public VideoRunningThread() {}
/* 1082:     */       
/* 1083:     */       public void run()
/* 1084:     */       {
/* 1085:1349 */         while (MraidView.this.videoView != null) {
/* 1086:     */           try
/* 1087:     */           {
/* 1088:1351 */             Thread.sleep(100L);
/* 1089:1353 */             if (this.playing != MraidView.this.videoView.isPlaying())
/* 1090:     */             {
/* 1091:1354 */               this.playing = MraidView.this.videoView.isPlaying();
/* 1092:1355 */               String eventName = this.playing ? "videoplay" : "videopause";
/* 1093:1356 */               MraidView.this.loadUrl("javascript:try{Tapjoy.AdUnit.dispatchEvent('" + eventName + "')}catch(e){}");
/* 1094:     */             }
/* 1095:     */           }
/* 1096:     */           catch (Exception e) {}
/* 1097:     */         }
/* 1098:     */       }
/* 1099:     */     }
/* 1100:     */   }
/* 1101:     */   
/* 1102:     */   private void checkForOrientationChange()
/* 1103:     */   {
/* 1104:1368 */     WindowManager windowManager = (WindowManager)getContext().getSystemService("window");
/* 1105:1369 */     int screenWidth = windowManager.getDefaultDisplay().getWidth();
/* 1106:1370 */     int screenHeight = windowManager.getDefaultDisplay().getHeight();
/* 1107:1375 */     if ((screenWidth != this.lastScreenWidth) || (screenHeight != this.lastScreenHeight)) {
/* 1108:1385 */       if (((getPlacementType() == PLACEMENT_TYPE.INLINE) && (getViewState() == VIEW_STATE.EXPANDED)) || (getPlacementType() == PLACEMENT_TYPE.INTERSTITIAL)) {
/* 1109:1387 */         resizeOrientation(screenWidth, screenHeight, "top-right", true);
/* 1110:     */       }
/* 1111:     */     }
/* 1112:     */   }
/* 1113:     */   
/* 1114:     */   public void addJavascriptObject(Object obj, String name)
/* 1115:     */   {
/* 1116:1393 */     addJavascriptInterface(obj, name);
/* 1117:     */   }
/* 1118:     */   
/* 1119:     */   private int getContentViewHeight()
/* 1120:     */   {
/* 1121:1402 */     View contentView = getRootView().findViewById(16908290);
/* 1122:1403 */     if (contentView != null) {
/* 1123:1404 */       return contentView.getHeight();
/* 1124:     */     }
/* 1125:1406 */     return -1;
/* 1126:     */   }
/* 1127:     */   
/* 1128:     */   private synchronized void setScriptPath()
/* 1129:     */   {
/* 1130:1413 */     TapjoyLog.d("MRAIDView", " paths" + mScriptPath);
/* 1131:1415 */     if ((mScriptPath == null) && (TapjoyUtil.getResource("mraid.js") == null)) {
/* 1132:1416 */       mScriptPath = this.mUtilityController.copyTextFromJarIntoAssetDir("/js/mraid.js", "js/mraid.js");
/* 1133:     */     }
/* 1134:     */   }
/* 1135:     */   
/* 1136:     */   protected synchronized void closeExpanded()
/* 1137:     */   {
/* 1138:1425 */     resetContents();
/* 1139:     */     
/* 1140:1427 */     String injection = "window.mraidview.fireChangeEvent({ state: 'default', size: { width: " + this.mDefaultWidth + ", " + "height: " + this.mDefaultHeight + "}" + "});";
/* 1141:     */     
/* 1142:     */ 
/* 1143:     */ 
/* 1144:     */ 
/* 1145:     */ 
/* 1146:     */ 
/* 1147:1434 */     TapjoyLog.d("MRAIDView", "closeExpanded: injection: " + injection);
/* 1148:1435 */     injectMraidJavaScript(injection);
/* 1149:1436 */     this.mViewState = VIEW_STATE.DEFAULT;
/* 1150:1437 */     this.mHandler.sendEmptyMessage(1005);
/* 1151:1438 */     setVisibility(0);
/* 1152:1439 */     removeCloseImageButton();
/* 1153:     */     
/* 1154:1441 */     ((Activity)getContext()).setRequestedOrientation(this.originalRequestedOrientation);
/* 1155:     */   }
/* 1156:     */   
/* 1157:     */   protected void closeOpened(View openedFrame)
/* 1158:     */   {
/* 1159:1451 */     ((ViewGroup)((Activity)getContext()).getWindow().getDecorView()).removeView(openedFrame);
/* 1160:     */     
/* 1161:1453 */     requestLayout();
/* 1162:     */   }
/* 1163:     */   
/* 1164:     */   public VIEW_STATE getViewState()
/* 1165:     */   {
/* 1166:1458 */     return this.mViewState;
/* 1167:     */   }
/* 1168:     */   
/* 1169:     */   public String getState()
/* 1170:     */   {
/* 1171:1467 */     return this.mViewState.toString().toLowerCase();
/* 1172:     */   }
/* 1173:     */   
/* 1174:     */   public void resize(int width, int height, int offsetX, int offsetY, String customClosePosition, boolean allowOffScreen)
/* 1175:     */   {
/* 1176:1480 */     Message msg = this.mHandler.obtainMessage(1000);
/* 1177:1481 */     Bundle data = new Bundle();
/* 1178:1482 */     data.putInt("resize_width", width);
/* 1179:1483 */     data.putInt("resize_height", height);
/* 1180:1484 */     data.putInt("resize_x", offsetX);
/* 1181:1485 */     data.putInt("resize_y", offsetY);
/* 1182:1486 */     data.putBoolean("resize_allowOffScreen", allowOffScreen);
/* 1183:1487 */     data.putString("resize_customClosePostition", customClosePosition);
/* 1184:1488 */     msg.setData(data);
/* 1185:1489 */     this.mHandler.sendMessage(msg);
/* 1186:     */   }
/* 1187:     */   
/* 1188:     */   public void resizeOrientation(int width, int height, String customClosePosition, boolean allowOffScreen)
/* 1189:     */   {
/* 1190:1497 */     this.lastScreenWidth = width;
/* 1191:1498 */     this.lastScreenHeight = height;
/* 1192:     */     
/* 1193:1500 */     TapjoyLog.i("MRAIDView", "resizeOrientation to dimensions: " + width + "x" + height);
/* 1194:     */     
/* 1195:1502 */     Message msg = this.mHandler.obtainMessage(1010);
/* 1196:1503 */     Bundle data = new Bundle();
/* 1197:1504 */     data.putInt("resize_width", width);
/* 1198:1505 */     data.putInt("resize_height", height);
/* 1199:1506 */     data.putBoolean("resize_allowOffScreen", allowOffScreen);
/* 1200:1507 */     data.putString("resize_customClosePostition", customClosePosition);
/* 1201:1508 */     msg.setData(data);
/* 1202:1509 */     this.mHandler.sendMessage(msg);
/* 1203:     */   }
/* 1204:     */   
/* 1205:     */   public void close()
/* 1206:     */   {
/* 1207:1516 */     this.mHandler.sendEmptyMessage(1001);
/* 1208:     */   }
/* 1209:     */   
/* 1210:     */   public void hide()
/* 1211:     */   {
/* 1212:1523 */     this.mHandler.sendEmptyMessage(1002);
/* 1213:     */   }
/* 1214:     */   
/* 1215:     */   public void show()
/* 1216:     */   {
/* 1217:1530 */     this.mHandler.sendEmptyMessage(1003);
/* 1218:     */   }
/* 1219:     */   
/* 1220:     */   public ConnectivityManager getConnectivityManager()
/* 1221:     */   {
/* 1222:1539 */     return (ConnectivityManager)getContext().getSystemService("connectivity");
/* 1223:     */   }
/* 1224:     */   
/* 1225:     */   public void expand(Abstract.Dimensions dimensions, String URL, Abstract.Properties properties)
/* 1226:     */   {
/* 1227:1554 */     Message msg = this.mHandler.obtainMessage(1004);
/* 1228:1555 */     Bundle data = new Bundle();
/* 1229:1556 */     data.putParcelable("expand_dimensions", dimensions);
/* 1230:1557 */     data.putString("expand_url", URL);
/* 1231:1558 */     data.putParcelable("expand_properties", properties);
/* 1232:1559 */     msg.setData(data);
/* 1233:1560 */     this.mHandler.sendMessage(msg);
/* 1234:     */   }
/* 1235:     */   
/* 1236:     */   public void open(String url, boolean back, boolean forward, boolean refresh)
/* 1237:     */   {
/* 1238:1577 */     boolean isVideo = false;
/* 1239:1578 */     String videoURL = null;
/* 1240:1581 */     if (checkForVideo(url))
/* 1241:     */     {
/* 1242:1583 */       isVideo = true;
/* 1243:1584 */       videoURL = url;
/* 1244:     */     }
/* 1245:     */     else
/* 1246:     */     {
/* 1247:1588 */       TapjoyHttpURLResponse response = new TapjoyURLConnection().getRedirectFromURL(url);
/* 1248:     */       
/* 1249:1590 */       TapjoyLog.i("MRAIDView", "redirect: " + response.redirectURL + ", " + response.statusCode);
/* 1250:1593 */       if ((response != null) && (response.redirectURL != null) && (response.redirectURL.length() > 0)) {
/* 1251:1596 */         if (checkForVideo(response.redirectURL))
/* 1252:     */         {
/* 1253:1598 */           isVideo = true;
/* 1254:1599 */           videoURL = response.redirectURL;
/* 1255:     */         }
/* 1256:     */       }
/* 1257:     */     }
/* 1258:1605 */     if (isVideo)
/* 1259:     */     {
/* 1260:1607 */       initAndPlayVideo(videoURL);
/* 1261:     */     }
/* 1262:     */     else
/* 1263:     */     {
/* 1264:1612 */       TapjoyLog.d("MRAIDView", "Mraid Browser open:" + url);
/* 1265:1613 */       Intent i = new Intent(getContext(), Browser.class);
/* 1266:1614 */       i.putExtra("extra_url", url);
/* 1267:1615 */       i.putExtra("open_show_back", back);
/* 1268:1616 */       i.putExtra("open_show_forward", forward);
/* 1269:1617 */       i.putExtra("open_show_refresh", refresh);
/* 1270:1618 */       i.addFlags(268435456);
/* 1271:1619 */       getContext().startActivity(i);
/* 1272:     */     }
/* 1273:     */   }
/* 1274:     */   
/* 1275:     */   private void initAndPlayVideo(String url)
/* 1276:     */   {
/* 1277:1626 */     Abstract.Dimensions d = new Abstract.Dimensions();
/* 1278:1627 */     d.x = 0;
/* 1279:1628 */     d.y = 0;
/* 1280:1629 */     d.width = getWidth();
/* 1281:1630 */     d.height = getHeight();
/* 1282:1631 */     playVideo(url, false, true, true, false, d, "fullscreen", "exit");
/* 1283:     */   }
/* 1284:     */   
/* 1285:     */   private static boolean checkForVideo(String url)
/* 1286:     */   {
/* 1287:1635 */     for (String i : videoFormats) {
/* 1288:1636 */       if (url.endsWith(i)) {
/* 1289:1636 */         return true;
/* 1290:     */       }
/* 1291:     */     }
/* 1292:1638 */     return false;
/* 1293:     */   }
/* 1294:     */   
/* 1295:     */   public void setOrientationProperties(boolean allowOrientationChange, String forceOrientation)
/* 1296:     */   {
/* 1297:1642 */     int requestedOrientation = -1;
/* 1298:1644 */     if (!allowOrientationChange) {
/* 1299:1645 */       requestedOrientation = forceOrientation.equals("landscape") ? 0 : 1;
/* 1300:     */     }
/* 1301:1647 */     ((Activity)getContext()).setRequestedOrientation(requestedOrientation);
/* 1302:     */   }
/* 1303:     */   
/* 1304:     */   public void openMap(String POI, boolean fullscreen)
/* 1305:     */   {
/* 1306:1660 */     TapjoyLog.d("MRAIDView", "Opening Map Url " + POI);
/* 1307:1661 */     POI = POI.trim();
/* 1308:1662 */     POI = Utils.convert(POI);
/* 1309:1663 */     if (fullscreen) {
/* 1310:     */       try
/* 1311:     */       {
/* 1312:1665 */         Intent mapIntent = new Intent("android.intent.action.VIEW", Uri.parse(POI));
/* 1313:     */         
/* 1314:1667 */         mapIntent.setFlags(268435456);
/* 1315:1668 */         getContext().startActivity(mapIntent);
/* 1316:     */       }
/* 1317:     */       catch (ActivityNotFoundException e)
/* 1318:     */       {
/* 1319:1671 */         e.printStackTrace();
/* 1320:     */       }
/* 1321:     */     }
/* 1322:     */   }
/* 1323:     */   
/* 1324:     */   public void playAudioImpl(Bundle data)
/* 1325:     */   {
/* 1326:1677 */     Abstract.PlayerProperties properties = (Abstract.PlayerProperties)data.getParcelable("player_properties");
/* 1327:     */     
/* 1328:1679 */     String url = data.getString("expand_url");
/* 1329:1680 */     MraidPlayer audioPlayer = getPlayer();
/* 1330:1681 */     audioPlayer.setPlayData(properties, url);
/* 1331:1682 */     audioPlayer.setLayoutParams(new ViewGroup.LayoutParams(1, 1));
/* 1332:1683 */     ((ViewGroup)getParent()).addView(audioPlayer);
/* 1333:1684 */     audioPlayer.playAudio();
/* 1334:     */   }
/* 1335:     */   
/* 1336:     */   public void playAudio(String url, boolean autoPlay, boolean controls, boolean loop, boolean position, String startStyle, String stopStyle)
/* 1337:     */   {
/* 1338:1709 */     Abstract.PlayerProperties properties = new Abstract.PlayerProperties();
/* 1339:     */     
/* 1340:1711 */     properties.setProperties(false, autoPlay, controls, position, loop, startStyle, stopStyle);
/* 1341:     */     
/* 1342:     */ 
/* 1343:1714 */     Bundle data = new Bundle();
/* 1344:     */     
/* 1345:1716 */     data.putString("action", Action.PLAY_AUDIO.toString());
/* 1346:1717 */     data.putString("expand_url", url);
/* 1347:1718 */     data.putParcelable("player_properties", properties);
/* 1348:1720 */     if (properties.isFullScreen())
/* 1349:     */     {
/* 1350:     */       try
/* 1351:     */       {
/* 1352:1722 */         Intent intent = new Intent(getContext(), ActionHandler.class);
/* 1353:1723 */         intent.putExtras(data);
/* 1354:1724 */         getContext().startActivity(intent);
/* 1355:     */       }
/* 1356:     */       catch (ActivityNotFoundException e)
/* 1357:     */       {
/* 1358:1726 */         e.printStackTrace();
/* 1359:     */       }
/* 1360:     */     }
/* 1361:     */     else
/* 1362:     */     {
/* 1363:1729 */       Message msg = this.mHandler.obtainMessage(1008);
/* 1364:1730 */       msg.setData(data);
/* 1365:1731 */       this.mHandler.sendMessage(msg);
/* 1366:     */     }
/* 1367:     */   }
/* 1368:     */   
/* 1369:     */   public void playVideoImpl(Bundle data)
/* 1370:     */   {
/* 1371:1737 */     Abstract.PlayerProperties properties = (Abstract.PlayerProperties)data.getParcelable("player_properties");
/* 1372:     */     
/* 1373:1739 */     Abstract.Dimensions d = (Abstract.Dimensions)data.getParcelable("expand_dimensions");
/* 1374:1740 */     String url = data.getString("expand_url");
/* 1375:     */     
/* 1376:1742 */     MraidPlayer videoPlayer = getPlayer();
/* 1377:1743 */     videoPlayer.setPlayData(properties, url);
/* 1378:     */     
/* 1379:1745 */     FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(d.width, d.height);
/* 1380:     */     
/* 1381:1747 */     fl.topMargin = d.x;
/* 1382:1748 */     fl.leftMargin = d.y;
/* 1383:1749 */     videoPlayer.setLayoutParams(fl);
/* 1384:     */     
/* 1385:1751 */     FrameLayout backGround = new FrameLayout(getContext());
/* 1386:     */     
/* 1387:1753 */     backGround.setId(101);
/* 1388:1754 */     backGround.setPadding(d.x, d.y, 0, 0);
/* 1389:     */     
/* 1390:1756 */     FrameLayout contentView = (FrameLayout)getRootView().findViewById(16908290);
/* 1391:     */     
/* 1392:1758 */     contentView.addView(backGround, new FrameLayout.LayoutParams(-1, -1));
/* 1393:     */     
/* 1394:     */ 
/* 1395:     */ 
/* 1396:1762 */     backGround.addView(videoPlayer);
/* 1397:1763 */     setVisibility(4);
/* 1398:     */     
/* 1399:1765 */     videoPlayer.setListener(new Player()
/* 1400:     */     {
/* 1401:     */       public void onPrepared() {}
/* 1402:     */       
/* 1403:     */       public void onError()
/* 1404:     */       {
/* 1405:1773 */         onComplete();
/* 1406:     */       }
/* 1407:     */       
/* 1408:     */       public void onComplete()
/* 1409:     */       {
/* 1410:1778 */         FrameLayout background = (FrameLayout)MraidView.this.getRootView().findViewById(101);
/* 1411:     */         
/* 1412:1780 */         ((ViewGroup)background.getParent()).removeView(background);
/* 1413:1781 */         MraidView.this.setVisibility(0);
/* 1414:     */       }
/* 1415:1784 */     });
/* 1416:1785 */     videoPlayer.playVideo();
/* 1417:     */   }
/* 1418:     */   
/* 1419:     */   public void playVideo(String url, boolean audioMuted, boolean autoPlay, boolean controls, boolean loop, Abstract.Dimensions d, String startStyle, String stopStyle)
/* 1420:     */   {
/* 1421:1812 */     Message msg = this.mHandler.obtainMessage(1007);
/* 1422:1813 */     Abstract.PlayerProperties properties = new Abstract.PlayerProperties();
/* 1423:1814 */     properties.setProperties(audioMuted, autoPlay, controls, false, loop, startStyle, stopStyle);
/* 1424:     */     
/* 1425:1816 */     Bundle data = new Bundle();
/* 1426:1817 */     data.putString("expand_url", url);
/* 1427:1818 */     data.putString("action", Action.PLAY_VIDEO.toString());
/* 1428:     */     
/* 1429:1820 */     data.putParcelable("player_properties", properties);
/* 1430:1822 */     if (d != null) {
/* 1431:1823 */       data.putParcelable("expand_dimensions", d);
/* 1432:     */     }
/* 1433:1825 */     if (properties.isFullScreen())
/* 1434:     */     {
/* 1435:     */       try
/* 1436:     */       {
/* 1437:1827 */         Intent intent = new Intent(getContext(), ActionHandler.class);
/* 1438:1828 */         intent.putExtras(data);
/* 1439:1829 */         intent.setFlags(268435456);
/* 1440:1830 */         getContext().startActivity(intent);
/* 1441:     */       }
/* 1442:     */       catch (ActivityNotFoundException e)
/* 1443:     */       {
/* 1444:1832 */         e.printStackTrace();
/* 1445:     */       }
/* 1446:     */     }
/* 1447:1834 */     else if (d != null)
/* 1448:     */     {
/* 1449:1835 */       msg.setData(data);
/* 1450:1836 */       this.mHandler.sendMessage(msg);
/* 1451:     */     }
/* 1452:     */   }
/* 1453:     */   
/* 1454:     */   public void resetContents()
/* 1455:     */   {
/* 1456:1845 */     FrameLayout contentView = (FrameLayout)getRootView().findViewById(16908290);
/* 1457:     */     
/* 1458:1847 */     FrameLayout placeHolder = (FrameLayout)getRootView().findViewById(100);
/* 1459:     */     
/* 1460:1849 */     FrameLayout background = (FrameLayout)getRootView().findViewById(101);
/* 1461:     */     
/* 1462:1851 */     background.removeView(this);
/* 1463:1852 */     contentView.removeView(background);
/* 1464:1853 */     resetLayout();
/* 1465:1854 */     if (placeHolder != null)
/* 1466:     */     {
/* 1467:1855 */       ViewGroup parent = (ViewGroup)placeHolder.getParent();
/* 1468:1856 */       if (parent != null)
/* 1469:     */       {
/* 1470:1857 */         parent.addView(this, this.mIndex);
/* 1471:1858 */         parent.removeView(placeHolder);
/* 1472:1859 */         parent.invalidate();
/* 1473:     */       }
/* 1474:     */     }
/* 1475:     */   }
/* 1476:     */   
/* 1477:     */   private void resetLayout()
/* 1478:     */   {
/* 1479:1882 */     ViewGroup.LayoutParams lp = getLayoutParams();
/* 1480:1883 */     if (this.bGotLayoutParams)
/* 1481:     */     {
/* 1482:1884 */       lp.height = this.mInitLayoutHeight;
/* 1483:1885 */       lp.width = this.mInitLayoutWidth;
/* 1484:     */     }
/* 1485:1887 */     setVisibility(0);
/* 1486:1888 */     requestLayout();
/* 1487:     */   }
/* 1488:     */   
/* 1489:     */   public boolean isPageFinished()
/* 1490:     */   {
/* 1491:1897 */     return this.bPageFinished;
/* 1492:     */   }
/* 1493:     */   
/* 1494:     */   public void onGlobalLayout()
/* 1495:     */   {
/* 1496:1903 */     boolean state = this.bKeyboardOut;
/* 1497:1904 */     if ((!this.bKeyboardOut) && (this.mContentViewHeight >= 0) && (getContentViewHeight() >= 0) && (this.mContentViewHeight != getContentViewHeight()))
/* 1498:     */     {
/* 1499:1908 */       state = true;
/* 1500:1909 */       String injection = "window.mraidview.fireChangeEvent({ keyboardState: true});";
/* 1501:1910 */       injectMraidJavaScript(injection);
/* 1502:     */     }
/* 1503:1912 */     if ((this.bKeyboardOut) && (this.mContentViewHeight >= 0) && (getContentViewHeight() >= 0) && (this.mContentViewHeight == getContentViewHeight()))
/* 1504:     */     {
/* 1505:1915 */       state = false;
/* 1506:1916 */       String injection = "window.mraidview.fireChangeEvent({ keyboardState: false});";
/* 1507:1917 */       injectMraidJavaScript(injection);
/* 1508:     */     }
/* 1509:1919 */     if (this.mContentViewHeight < 0) {
/* 1510:1920 */       this.mContentViewHeight = getContentViewHeight();
/* 1511:     */     }
/* 1512:1922 */     this.bKeyboardOut = state;
/* 1513:     */   }
/* 1514:     */   
/* 1515:     */   public String getSize()
/* 1516:     */   {
/* 1517:1931 */     return "{ width: " + (int)Math.ceil(getWidth() / this.mDensity) + ", " + "height: " + (int)Math.ceil(getHeight() / this.mDensity) + "}";
/* 1518:     */   }
/* 1519:     */   
/* 1520:     */   protected void onAttachedToWindow()
/* 1521:     */   {
/* 1522:1937 */     if (!this.bGotLayoutParams)
/* 1523:     */     {
/* 1524:1938 */       ViewGroup.LayoutParams lp = getLayoutParams();
/* 1525:1939 */       this.mInitLayoutHeight = lp.height;
/* 1526:1940 */       this.mInitLayoutWidth = lp.width;
/* 1527:1941 */       this.bGotLayoutParams = true;
/* 1528:     */     }
/* 1529:1944 */     this.viewDetached = false;
/* 1530:1948 */     if ((this.orientationThread == null) || (!this.orientationThread.isAlive()))
/* 1531:     */     {
/* 1532:1950 */       this.orientationThread = new Thread(new OrientationThread());
/* 1533:1951 */       this.orientationThread.start();
/* 1534:     */     }
/* 1535:1954 */     super.onAttachedToWindow();
/* 1536:     */   }
/* 1537:     */   
/* 1538:     */   public WebBackForwardList saveState(Bundle outState)
/* 1539:     */   {
/* 1540:1961 */     return super.saveState(outState);
/* 1541:     */   }
/* 1542:     */   
/* 1543:     */   public WebBackForwardList restoreState(Bundle savedInstanceState)
/* 1544:     */   {
/* 1545:1975 */     return super.restoreState(savedInstanceState);
/* 1546:     */   }
/* 1547:     */   
/* 1548:     */   public static abstract class NewLocationReciever
/* 1549:     */   {
/* 1550:     */     public abstract void OnNewLocation(MraidView.VIEW_STATE paramVIEW_STATE);
/* 1551:     */   }
/* 1552:     */   
/* 1553:     */   class ScrollEater
/* 1554:     */     extends GestureDetector.SimpleOnGestureListener
/* 1555:     */   {
/* 1556:     */     ScrollEater() {}
/* 1557:     */     
/* 1558:     */     public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY)
/* 1559:     */     {
/* 1560:1986 */       return true;
/* 1561:     */     }
/* 1562:     */   }
/* 1563:     */   
/* 1564:     */   public void raiseError(String strMsg, String action)
/* 1565:     */   {
/* 1566:1992 */     Message msg = this.mHandler.obtainMessage(1009);
/* 1567:     */     
/* 1568:1994 */     Bundle data = new Bundle();
/* 1569:1995 */     data.putString("message", strMsg);
/* 1570:1996 */     data.putString("action", action);
/* 1571:1997 */     msg.setData(data);
/* 1572:1998 */     this.mHandler.sendMessage(msg);
/* 1573:     */   }
/* 1574:     */   
/* 1575:     */   public boolean isExpanded()
/* 1576:     */   {
/* 1577:2007 */     return this.mViewState == VIEW_STATE.EXPANDED;
/* 1578:     */   }
/* 1579:     */   
/* 1580:     */   protected void onDetachedFromWindow()
/* 1581:     */   {
/* 1582:2012 */     this.viewDetached = true;
/* 1583:2013 */     this.mUtilityController.stopAllListeners();
/* 1584:     */     try
/* 1585:     */     {
/* 1586:2018 */       if (this.videoView != null) {
/* 1587:2019 */         this.videoView.stopPlayback();
/* 1588:     */       }
/* 1589:2021 */       if (this.videoViewCallback != null) {
/* 1590:2022 */         this.videoViewCallback.onCustomViewHidden();
/* 1591:     */       }
/* 1592:     */     }
/* 1593:     */     catch (Exception e)
/* 1594:     */     {
/* 1595:2026 */       e.printStackTrace();
/* 1596:     */     }
/* 1597:2029 */     super.onDetachedFromWindow();
/* 1598:     */   }
/* 1599:     */   
/* 1600:     */   MraidPlayer getPlayer()
/* 1601:     */   {
/* 1602:2034 */     if (player != null) {
/* 1603:2035 */       player.releasePlayer();
/* 1604:     */     }
/* 1605:2036 */     player = new MraidPlayer(getContext());
/* 1606:2037 */     return player;
/* 1607:     */   }
/* 1608:     */   
/* 1609:     */   private class MraidHTTPTask
/* 1610:     */     extends AsyncTask<String, Void, Void>
/* 1611:     */   {
/* 1612:     */     TapjoyHttpURLResponse httpResult;
/* 1613:     */     TapjoyURLConnection tapjoyConnection;
/* 1614:     */     String url;
/* 1615:     */     
/* 1616:     */     private MraidHTTPTask() {}
/* 1617:     */     
/* 1618:     */     protected Void doInBackground(String... params)
/* 1619:     */     {
/* 1620:2049 */       this.url = params[0];
/* 1621:     */       try
/* 1622:     */       {
/* 1623:2053 */         this.tapjoyConnection = new TapjoyURLConnection();
/* 1624:2054 */         this.httpResult = this.tapjoyConnection.getResponseFromURL(this.url);
/* 1625:     */       }
/* 1626:     */       catch (Exception e)
/* 1627:     */       {
/* 1628:2058 */         e.printStackTrace();
/* 1629:     */       }
/* 1630:2061 */       return null;
/* 1631:     */     }
/* 1632:     */     
/* 1633:     */     protected void onPostExecute(Void result)
/* 1634:     */     {
/* 1635:     */       try
/* 1636:     */       {
/* 1637:2069 */         if ((this.httpResult.statusCode == 0) || (this.httpResult.response == null))
/* 1638:     */         {
/* 1639:2071 */           TapjoyLog.e("MRAIDView", "Connection not properly established");
/* 1640:2073 */           if (MraidView.this.mListener != null) {
/* 1641:2075 */             MraidView.this.mListener.onReceivedError(MraidView.this, 0, "Connection not properly established", this.url);
/* 1642:     */           }
/* 1643:     */         }
/* 1644:2080 */         else if ((this.httpResult.statusCode == 302) && (this.httpResult.redirectURL != null) && (this.httpResult.redirectURL.length() > 0))
/* 1645:     */         {
/* 1646:2082 */           TapjoyLog.i("MRAIDView", "302 redirectURL detected: " + this.httpResult.redirectURL);
/* 1647:     */           
/* 1648:2084 */           MraidView.this.loadUrlStandard(this.httpResult.redirectURL);
/* 1649:     */         }
/* 1650:     */         else
/* 1651:     */         {
/* 1652:2088 */           MraidView.this.loadDataWithBaseURL(this.url, this.httpResult.response, "text/html", "utf-8", this.url);
/* 1653:     */         }
/* 1654:     */       }
/* 1655:     */       catch (Exception e)
/* 1656:     */       {
/* 1657:2093 */         TapjoyLog.w("MRAIDView", "error in loadURL " + e);
/* 1658:2094 */         e.printStackTrace();
/* 1659:     */       }
/* 1660:     */     }
/* 1661:     */   }
/* 1662:     */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.view.MraidView
 * JD-Core Version:    0.7.0.1
 */