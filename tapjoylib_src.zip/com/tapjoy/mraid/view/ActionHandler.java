/*   1:    */ package com.tapjoy.mraid.view;
/*   2:    */ 
/*   3:    */ import android.app.Activity;
/*   4:    */ import android.content.Intent;
/*   5:    */ import android.os.Bundle;
/*   6:    */ import android.view.ViewGroup.LayoutParams;
/*   7:    */ import android.view.Window;
/*   8:    */ import android.widget.RelativeLayout;
/*   9:    */ import android.widget.RelativeLayout.LayoutParams;
/*  10:    */ import com.tapjoy.mraid.controller.Abstract.Dimensions;
/*  11:    */ import com.tapjoy.mraid.controller.Abstract.PlayerProperties;
/*  12:    */ import com.tapjoy.mraid.listener.Player;
/*  13:    */ import com.tapjoy.mraid.util.MraidPlayer;
/*  14:    */ import com.tapjoy.mraid.util.Utils;
/*  15:    */ import java.util.HashMap;
/*  16:    */ import java.util.Map.Entry;
/*  17:    */ 
/*  18:    */ public class ActionHandler
/*  19:    */   extends Activity
/*  20:    */ {
/*  21:    */   private static final String TAG = "MRAID Action Handler";
/*  22: 28 */   private HashMap<MraidView.Action, Object> actionData = new HashMap();
/*  23:    */   private RelativeLayout layout;
/*  24:    */   
/*  25:    */   public void onCreate(Bundle savedInstanceState)
/*  26:    */   {
/*  27: 33 */     super.onCreate(savedInstanceState);
/*  28:    */     
/*  29:    */ 
/*  30: 36 */     requestWindowFeature(1);
/*  31:    */     
/*  32: 38 */     Bundle data = getIntent().getExtras();
/*  33: 39 */     this.layout = new RelativeLayout(this);
/*  34: 40 */     this.layout.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
/*  35: 41 */     this.layout.setBackgroundColor(-16777216);
/*  36: 42 */     setContentView(this.layout);
/*  37: 43 */     doAction(data);
/*  38:    */   }
/*  39:    */   
/*  40:    */   private void doAction(Bundle data)
/*  41:    */   {
/*  42: 52 */     String actionData = data.getString("action");
/*  43: 54 */     if (actionData == null) {
/*  44: 55 */       return;
/*  45:    */     }
/*  46: 57 */     MraidView.Action actionType = MraidView.Action.valueOf(actionData);
/*  47: 59 */     switch (2.$SwitchMap$com$tapjoy$mraid$view$MraidView$Action[actionType.ordinal()])
/*  48:    */     {
/*  49:    */     case 1: 
/*  50: 61 */       MraidPlayer player = initPlayer(data, actionType);
/*  51: 62 */       player.playAudio();
/*  52:    */       
/*  53: 64 */       break;
/*  54:    */     case 2: 
/*  55: 66 */       MraidPlayer player = initPlayer(data, actionType);
/*  56: 67 */       player.playVideo();
/*  57:    */       
/*  58: 69 */       break;
/*  59:    */     }
/*  60:    */   }
/*  61:    */   
/*  62:    */   MraidPlayer initPlayer(Bundle playData, MraidView.Action actionType)
/*  63:    */   {
/*  64: 85 */     Abstract.PlayerProperties properties = (Abstract.PlayerProperties)playData.getParcelable("player_properties");
/*  65: 86 */     Abstract.Dimensions playDimensions = (Abstract.Dimensions)playData.getParcelable("expand_dimensions");
/*  66: 87 */     MraidPlayer player = new MraidPlayer(this);
/*  67: 88 */     player.setPlayData(properties, Utils.getData("expand_url", playData));
/*  68:    */     RelativeLayout.LayoutParams lp;
/*  69: 91 */     if ((!properties.inline) && (properties.startStyle.equals("fullscreen")))
/*  70:    */     {
/*  71: 94 */       getWindow().setFlags(1024, 1024);
/*  72: 95 */       getWindow().setFlags(16777216, 16777216);
/*  73:    */       
/*  74:    */ 
/*  75: 98 */       RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(-1, -1);
/*  76: 99 */       lp.addRule(13);
/*  77:    */     }
/*  78:    */     else
/*  79:    */     {
/*  80:104 */       lp = new RelativeLayout.LayoutParams(playDimensions.width, playDimensions.height);
/*  81:105 */       lp.topMargin = playDimensions.y;
/*  82:106 */       lp.leftMargin = playDimensions.x;
/*  83:    */     }
/*  84:109 */     player.setLayoutParams(lp);
/*  85:110 */     this.layout.addView(player);
/*  86:111 */     this.actionData.put(actionType, player);
/*  87:112 */     setPlayerListener(player);
/*  88:113 */     return player;
/*  89:    */   }
/*  90:    */   
/*  91:    */   private void setPlayerListener(MraidPlayer player)
/*  92:    */   {
/*  93:123 */     player.setListener(new Player()
/*  94:    */     {
/*  95:    */       public void onPrepared() {}
/*  96:    */       
/*  97:    */       public void onError()
/*  98:    */       {
/*  99:132 */         ActionHandler.this.finish();
/* 100:    */       }
/* 101:    */       
/* 102:    */       public void onComplete()
/* 103:    */       {
/* 104:137 */         ActionHandler.this.finish();
/* 105:    */       }
/* 106:    */     });
/* 107:    */   }
/* 108:    */   
/* 109:    */   protected void onStop()
/* 110:    */   {
/* 111:145 */     for (Map.Entry<MraidView.Action, Object> entry : this.actionData.entrySet()) {
/* 112:146 */       switch (2.$SwitchMap$com$tapjoy$mraid$view$MraidView$Action[((MraidView.Action)entry.getKey()).ordinal()])
/* 113:    */       {
/* 114:    */       case 1: 
/* 115:    */       case 2: 
/* 116:149 */         MraidPlayer player = (MraidPlayer)entry.getValue();
/* 117:150 */         player.releasePlayer();
/* 118:    */       }
/* 119:    */     }
/* 120:156 */     super.onStop();
/* 121:    */   }
/* 122:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.view.ActionHandler
 * JD-Core Version:    0.7.0.1
 */