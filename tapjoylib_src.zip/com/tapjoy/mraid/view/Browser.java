/*   1:    */ package com.tapjoy.mraid.view;
/*   2:    */ 
/*   3:    */ import android.app.Activity;
/*   4:    */ import android.content.Intent;
/*   5:    */ import android.content.res.Resources;
/*   6:    */ import android.graphics.Bitmap;
/*   7:    */ import android.graphics.BitmapFactory;
/*   8:    */ import android.graphics.Matrix;
/*   9:    */ import android.graphics.drawable.BitmapDrawable;
/*  10:    */ import android.os.Bundle;
/*  11:    */ import android.util.Base64;
/*  12:    */ import android.util.DisplayMetrics;
/*  13:    */ import android.view.Display;
/*  14:    */ import android.view.View;
/*  15:    */ import android.view.View.OnClickListener;
/*  16:    */ import android.view.Window;
/*  17:    */ import android.view.WindowManager;
/*  18:    */ import android.webkit.CookieSyncManager;
/*  19:    */ import android.webkit.WebChromeClient;
/*  20:    */ import android.webkit.WebSettings;
/*  21:    */ import android.webkit.WebView;
/*  22:    */ import android.webkit.WebViewClient;
/*  23:    */ import android.widget.ImageButton;
/*  24:    */ import android.widget.LinearLayout;
/*  25:    */ import android.widget.LinearLayout.LayoutParams;
/*  26:    */ import android.widget.RelativeLayout;
/*  27:    */ import android.widget.RelativeLayout.LayoutParams;
/*  28:    */ import com.tapjoy.TapjoyLog;
/*  29:    */ import com.tapjoy.mraid.controller.Assets;
/*  30:    */ import java.io.InputStream;
/*  31:    */ import java.net.URL;
/*  32:    */ import java.util.jar.JarEntry;
/*  33:    */ import java.util.jar.JarFile;
/*  34:    */ 
/*  35:    */ public class Browser
/*  36:    */   extends Activity
/*  37:    */ {
/*  38:    */   public static final String URL_EXTRA = "extra_url";
/*  39:    */   public static final String SHOW_BACK_EXTRA = "open_show_back";
/*  40:    */   public static final String SHOW_FORWARD_EXTRA = "open_show_forward";
/*  41:    */   public static final String SHOW_REFRESH_EXTRA = "open_show_refresh";
/*  42:    */   private static final int ButtonId = 100;
/*  43:    */   private static final int WebViewId = 101;
/*  44:    */   private static final int ForwardId = 102;
/*  45:    */   private static final int BackwardId = 103;
/*  46:    */   private static final String BACKGROUND_PNG = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAAsCAIAAAArRUU2AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJ\nbWFnZVJlYWR5ccllPAAAAEFJREFUeNpicPP0Zvr3/z/T/3//gDQQg+i//5j+gum/QBqIQXwg+x+Y\njckH6fkL0/f3NwMPHz8jKxsbAw0AQIABAGYHPKslk98oAAAAAElFTkSuQmCC";
/*  47:    */   private static final String LEFT_ARROW_PNG = "iVBORw0KGgoAAAANSUhEUgAAABIAAAAUCAYAAACAl21KAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJ\nbWFnZVJlYWR5ccllPAAAApVJREFUeNqUVEuLkmEYfT6/9/MejjjeRhvvOo7XomLIzRTChEQU0Sa6\nLdoEA21azN6NzG9oIGE2bdwERYggrdqI2SLb5G5o0VwYRZGZ0a/zig5WNo4PHF4+5DnvOed9Htnq\n6irNUuVymeHQARbA5XA4vDirbAYCBQ4NYAIuarXacDQafbK0tJRqNBr32TkIBBxKwAgsKBQKTzgc\nfgCCO36/XxOPx6lYLBKbQsB/vwDYuI3FxcWby8vLDwOBwEIkEiFO4vV6qVarTSYCiYhDC5g5gdFo\nTMLGs2AwGIeSAUEoFCKLxUJqtZpEUfyTaJiDapiDU6lUBmKx2CM03YAKiRNAESFg0ul0BJunvWzM\nhgTMAXauAs13gXsgmOMEUEQul4sMBgMx9q8RNnxOPWDlBHa7/TpufQobbn47J0GoZDKZCApJEISJ\nmbKhEpter78GGy+gYgUklEgkiOdhs9lIo9H8l+CUCDcJaHjsdDpf+nw+3cgGvgnkgyDPU2xvb6+L\n5D96PJ4MpjwJVTQ/Pz8xh7NKgea+SqX6lMvlruzs7DxvtVq/jo6OSJblmYhEt9tNvV6PoETe3Nz8\ncnx8/BoKJazAZVzAuLVp+ZRKpbeDQej3+9RsNimdTsu7u7sHmUzmVT6fT1YqlQ/7+/t0cnIy3dr4\nB29AZrS2tibX6/XvqVTqdqFQuPUNBcuDC8+09ndxq7wR+yRD6Q+o28IDHMDuCmyr+UOM2+XWJhKN\nCnnR4eEhYdd62Wz2MxRtYaYMWI9LyE8YjcZUIl789brdLmFVuLXOxsbGe6vV+g7CglDokSSJqtXq\nm6lEo+L5dDodPu1yu93+ub6+vo3/pa8gu4px2RZm/asdvBC2nm8/9pLMZrMK1sXfAgwAtiLartJw\n+UAAAAAASUVORK5CYII=";
/*  48:    */   private static final String REFRESH_PNG = "iVBORw0KGgoAAAANSUhEUgAAABMAAAAUCAYAAABvVQZ0AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJ\nbWFnZVJlYWR5ccllPAAAA2NJREFUeNqMVF1Ik1EYPm7TpsIca84pGs6VrboYaeRPpFgXKUzBH4S8\nsLoIMVCpRERCAgfSZXpR2ZVJCEIgaIQm+MdCIkXRTTTnQG0qorCFm21zp+f9+IQ5NHvh4eP7vnOe\n877Ped5Xyv4dEYAMSK2rq/tkt9tlXq83Cu9BwC8+zyQ4B5wHLgAG4M7IyAgfHR31FhcXv8F7EXAZ\nUADSo43SMCLKQimS0GKDTqfLys7OvlldXZ2Vnp4uy8nJuZGWlmacnp52ejyeANZ4AB/AQ4kigSQg\nT6/XPzebzd8pk4WFBb6+vs6xkVP4/X6+s7PDx8bGPJWVlWasTxGTOJZRInC3oaHh88zMjLDh4OCA\n+3w+4RkIBPhRHB4e8u3tbd7f38+rqqpM2CcJ1YhKu4Vsvq2urnKIzN1uN3c4HHxqaso1Pj7+Y3d3\nVyAicqfTyaHhenNzc1Eo0VF5F2traz+srKwIRFtbW3xoaMjW1tZ2X9Q12WazcZfLxefn53lXV9fb\niooKjZjIsVAkJSXdIw1IFyqvt7d3pLy8PCFksXJgYIAPDg5aGxsbs8OzCY2E+vr692tra4LIFovl\nd15eXmrYqbKmpiZzuNAnRXJ3d7eVStjc3OQo7ZXos7OC5ImjZAA1EE0nSbRarUYulzNoxeCfb/gW\n+A+yGEAvuoC8ZieyoFKpVEulUgYPMVy3Qyzn8IwuiYWNXl5FQB4/9r0gIf+gxG34iEVFRbH8/HwS\nOPakmwovMTMz81JZWZm+oKDAkJiYGENk3o2NjSVYgsXFxbHc3NxCMXX5KYRkFRU2XzEajQZUxSQS\nCdvb2/tJZAfLy8uDyI4pFApmMpkKNRpNJr7rxEaWiaS0NhrQAuk1NTVPoDWDiRmS2RweHrYK9aO0\nFPjMvb+/z3EC7+vr+6VWqx/j321xauhEsa8DJjR9NxIQDI6xxFtbW58emx4tLS0PFhcXhT4kwomJ\nCS/67qNKparH/4fAo4yMDHNHR8c8EdDB1J8w+NRJVors7Ox8t7S0JCwkIH1utVr57Owsn5ub49Ru\ndBAdSC2HG7SVlJRoT7ssaXt7e+3k5KSLiIiQJgRFMBgUmpzIqE97enq+lJaWhrbciYwRKE+NW32G\nIVgcHx9/TSaTMfAxkLsx2ywge40J8zV8bP8VYACAQuluULZPjQAAAABJRU5ErkJggg==";
/*  49:    */   private static final String RIGHT_ARROW_PNG = "iVBORw0KGgoAAAANSUhEUgAAABEAAAAUCAYAAABroNZJAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJ\nbWFnZVJlYWR5ccllPAAAAq5JREFUeNqUlN9LmmEUx4++/ihKy6yZGEMjlExdEjgqQmm78ioGu41g\nu7Ftt+5mBF0Go8sIBvsTtggqGgODboK66aIwNi0lJ7p+2TT89b7Pvo/LaKucHTj4+LzP+bzne855\nXpnVan0ZiUSSoiimiCgBP4UXfD4fozpsbW2NhP7+/vdDQ0MvFLBkMnmBfQEuHhwclOHMbDbXhOAM\nCQ6HY8Lr9Tr8fv9ji8Xy6PDw8CKTyUh4LoNzUBkg9l/I4OCg2ePxkNPpfOB2u0cbGhoeQuJZsVjk\nWbHLrMTbYBVIb2/vhMvlMttsNurs7CSj0Si32+0W7D0BRMthOKuAS5cw6brEvyCQQk1NTdTY2Eht\nbW3U1dWlxr6rp6dnJJVKldLpdBEx8kuJYrVeNyAcwE0QBGpubqb29nbq7u7WDgwMjABs39/fz+Ry\nOV4rVoXx9a0QbjKZjJRKJWm1WjIYDIRRMKJeT/ECQzQazZTLZZ4Vb0D5Tsh1mFqtJp1ORyaTSejr\n67MixouMFLFY7AeOnCuoTsMYkV6vJ41GwxugR1cnNzY2POvr66/qhlzPChlRS0tLHuuv6F74XpCq\nYRg/7e7uvh0eHo7wwsrvE5zP53cQPIr6PMcV+T41NVUZvrog6MTPeDz+BoXn1yI0MzMjLS8v09bW\n1p961QpmjJWOj48/rKysvBsfHz+bm5tji4uLBBBls1nCzaeamUD3F1Tf3dHR8RoFPQ0GgywUCtHe\n3h5/dgWoQtg/ur+Fw+Fnra2tfoz7zvT0NFtdXaXt7W06Ojri0m68UI7+5/lCkqRfiUQiGAgEnPj9\nPDs7K3Ldm5ubhP9UKBS4vFuzlqtUqnPo+7i0tGTFpeMfqALXjSEijHdF+13BV/MzNjamWVhYyM7P\nzzOMcSXw5OSESqUS1ft5/C3AAL39YeI2ufApAAAAAElFTkSuQmCC";
/*  50:    */   private static final String UN_RIGHT_ARROW_PNG = "iVBORw0KGgoAAAANSUhEUgAAABEAAAAUCAYAAABroNZJAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJ\nbWFnZVJlYWR5ccllPAAAAqNJREFUeNqUlEtrE1EUx8+8EjNT27zTaMw0k6RJGpu+VqIi4k7rQtyK\nIn6FrEraRhTET+AnENxUXLpWcFfRhaCbCpY0Lc3DpE07c+dxPTckojTG5sAfhnvP/fE/99wz3IV4\n/Fl1Z+eDZVlVAKigmihjwuejcIpoNZsg+AOBlz6//2E4EonWazUGElC2oesWip7xeIZCMAeEUDhc\npBw3LkqubDqdvs1xQNqt1iHucygGshBEh0LQQREBY2fHx8F2HLfkcl1OJKaut1vtCiEGy6M9V/Yg\nWBcSDIWKHM+PyYoMLpcbJEkCYpoT/mDg1rloNF+tVrcwV0Q5PZjzZ4l/QdiGIAjAoxiI43jOtKyY\nOqXeVRRFrmPgGb5Xot2/rxMQnhe6dA4vRhDFLsymjkApzGta8iYhpNnpdAgrsQ9j3wMh/cB1EAUR\ny3QBsSyPMqbcUFX1UrPRqJimyUAOgw2F9GzhOsLQFXNHiBmMRCeXg8FgfG939wtmtLnszMwuJ4gR\nr98Hoij993E5jgPoAvSjI1A8ngPT0B+JMGIwV263G2RZhulU8lNle/vdyBAWc4XCdijgv7deKr1n\nFzsSJB6L6ZnMdHFtZeVFbrbgxBMa/Pi+BaeCeL1eZ3529tWT8vr9iwsLdiKVhka9BqZBuvtDIRJ2\nY3Fh/jM4dBkBlVQmSxv7NTAMHWzbBkrpcEg+l9ufjIQflFdX32byeRpTVfiJY29Z5u/D/TgBOR+N\nkmw287xcKj2eKczZqqZBs97AthKg2N5B48zjvLOnCzJO6LWrV95g330bG6/XtPS0zeo+aLeBoH3n\nH4CuE5wTktS0r1pSu/O0XP6WzuZop3OIg2Vg3dYJ64OCW1xamvy4ubmXwsOGfgz68TFY+CIdeqq/\nY/f3+EuAAQARwzy3ZhCNHQAAAABJRU5ErkJggg==";
/*  51:    */   private static final String TAG = "Mraid Browser";
/*  52:    */   
/*  53:    */   public void onCreate(Bundle savedInstanceState)
/*  54:    */   {
/*  55: 74 */     super.onCreate(savedInstanceState);
/*  56:    */     
/*  57:    */ 
/*  58: 77 */     RelativeLayout rl = new RelativeLayout(this);
/*  59: 78 */     WebView webview = new WebView(this);
/*  60:    */     
/*  61: 80 */     getWindow().requestFeature(2);
/*  62: 81 */     getWindow().setFeatureInt(2, -1);
/*  63:    */     
/*  64:    */ 
/*  65: 84 */     Intent i = getIntent();
/*  66:    */     
/*  67:    */ 
/*  68: 87 */     LinearLayout bll = new LinearLayout(this);
/*  69: 88 */     bll.setOrientation(0);
/*  70: 89 */     bll.setId(100);
/*  71: 90 */     bll.setWeightSum(100.0F);
/*  72: 91 */     RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(-1, -1);
/*  73:    */     
/*  74:    */ 
/*  75: 94 */     lp.addRule(2, 100);
/*  76: 95 */     BitmapDrawable bkgDrawable = new BitmapDrawable(getDensityScaledBitmap("iVBORw0KGgoAAAANSUhEUgAAAAEAAAAsCAIAAAArRUU2AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJ\nbWFnZVJlYWR5ccllPAAAAEFJREFUeNpicPP0Zvr3/z/T/3//gDQQg+i//5j+gum/QBqIQXwg+x+Y\njckH6fkL0/f3NwMPHz8jKxsbAw0AQIABAGYHPKslk98oAAAAAElFTkSuQmCC"));
/*  77:    */     
/*  78: 97 */     bll.setBackgroundDrawable(bkgDrawable);
/*  79: 98 */     rl.addView(webview, lp);
/*  80:    */     
/*  81:100 */     lp = new RelativeLayout.LayoutParams(-1, -2);
/*  82:    */     
/*  83:    */ 
/*  84:103 */     lp.addRule(12);
/*  85:104 */     rl.addView(bll, lp);
/*  86:    */     
/*  87:106 */     LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(-2, -1);
/*  88:    */     
/*  89:    */ 
/*  90:109 */     lp2.weight = 25.0F;
/*  91:110 */     lp2.gravity = 16;
/*  92:    */     
/*  93:112 */     ImageButton backButton = new ImageButton(this);
/*  94:113 */     backButton.setBackgroundColor(getResources().getColor(17170445));
/*  95:114 */     backButton.setId(103);
/*  96:    */     
/*  97:116 */     bll.addView(backButton, lp2);
/*  98:117 */     if (!i.getBooleanExtra("open_show_back", true)) {
/*  99:119 */       backButton.setVisibility(8);
/* 100:    */     }
/* 101:120 */     backButton.setImageBitmap(getDensityScaledBitmap("iVBORw0KGgoAAAANSUhEUgAAABIAAAAUCAYAAACAl21KAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJ\nbWFnZVJlYWR5ccllPAAAApVJREFUeNqUVEuLkmEYfT6/9/MejjjeRhvvOo7XomLIzRTChEQU0Sa6\nLdoEA21azN6NzG9oIGE2bdwERYggrdqI2SLb5G5o0VwYRZGZ0a/zig5WNo4PHF4+5DnvOed9Htnq\n6irNUuVymeHQARbA5XA4vDirbAYCBQ4NYAIuarXacDQafbK0tJRqNBr32TkIBBxKwAgsKBQKTzgc\nfgCCO36/XxOPx6lYLBKbQsB/vwDYuI3FxcWby8vLDwOBwEIkEiFO4vV6qVarTSYCiYhDC5g5gdFo\nTMLGs2AwGIeSAUEoFCKLxUJqtZpEUfyTaJiDapiDU6lUBmKx2CM03YAKiRNAESFg0ul0BJunvWzM\nhgTMAXauAs13gXsgmOMEUEQul4sMBgMx9q8RNnxOPWDlBHa7/TpufQobbn47J0GoZDKZCApJEISJ\nmbKhEpter78GGy+gYgUklEgkiOdhs9lIo9H8l+CUCDcJaHjsdDpf+nw+3cgGvgnkgyDPU2xvb6+L\n5D96PJ4MpjwJVTQ/Pz8xh7NKgea+SqX6lMvlruzs7DxvtVq/jo6OSJblmYhEt9tNvV6PoETe3Nz8\ncnx8/BoKJazAZVzAuLVp+ZRKpbeDQej3+9RsNimdTsu7u7sHmUzmVT6fT1YqlQ/7+/t0cnIy3dr4\nB29AZrS2tibX6/XvqVTqdqFQuPUNBcuDC8+09ndxq7wR+yRD6Q+o28IDHMDuCmyr+UOM2+XWJhKN\nCnnR4eEhYdd62Wz2MxRtYaYMWI9LyE8YjcZUIl789brdLmFVuLXOxsbGe6vV+g7CglDokSSJqtXq\nm6lEo+L5dDodPu1yu93+ub6+vo3/pa8gu4px2RZm/asdvBC2nm8/9pLMZrMK1sXfAgwAtiLartJw\n+UAAAAAASUVORK5CYII="));
/* 102:    */     
/* 103:122 */     backButton.setOnClickListener(new View.OnClickListener()
/* 104:    */     {
/* 105:    */       public void onClick(View arg0)
/* 106:    */       {
/* 107:126 */         WebView wv = (WebView)Browser.this.findViewById(101);
/* 108:127 */         if (wv.canGoBack()) {
/* 109:128 */           wv.goBack();
/* 110:    */         } else {
/* 111:130 */           Browser.this.finish();
/* 112:    */         }
/* 113:    */       }
/* 114:133 */     });
/* 115:134 */     ImageButton forwardButton = new ImageButton(this);
/* 116:135 */     forwardButton.setBackgroundColor(getResources().getColor(17170445));
/* 117:136 */     forwardButton.setId(102);
/* 118:137 */     lp2 = new LinearLayout.LayoutParams(-2, -1);
/* 119:    */     
/* 120:    */ 
/* 121:140 */     lp2.weight = 25.0F;
/* 122:141 */     lp2.gravity = 16;
/* 123:    */     
/* 124:143 */     bll.addView(forwardButton, lp2);
/* 125:144 */     if (!i.getBooleanExtra("open_show_forward", true)) {
/* 126:145 */       forwardButton.setVisibility(8);
/* 127:    */     }
/* 128:146 */     forwardButton.setOnClickListener(new View.OnClickListener()
/* 129:    */     {
/* 130:    */       public void onClick(View arg0)
/* 131:    */       {
/* 132:150 */         WebView wv = (WebView)Browser.this.findViewById(101);
/* 133:151 */         wv.goForward();
/* 134:    */       }
/* 135:154 */     });
/* 136:155 */     ImageButton refreshButton = new ImageButton(this);
/* 137:156 */     refreshButton.setImageBitmap(getDensityScaledBitmap("iVBORw0KGgoAAAANSUhEUgAAABMAAAAUCAYAAABvVQZ0AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJ\nbWFnZVJlYWR5ccllPAAAA2NJREFUeNqMVF1Ik1EYPm7TpsIca84pGs6VrboYaeRPpFgXKUzBH4S8\nsLoIMVCpRERCAgfSZXpR2ZVJCEIgaIQm+MdCIkXRTTTnQG0qorCFm21zp+f9+IQ5NHvh4eP7vnOe\n877Ped5Xyv4dEYAMSK2rq/tkt9tlXq83Cu9BwC8+zyQ4B5wHLgAG4M7IyAgfHR31FhcXv8F7EXAZ\nUADSo43SMCLKQimS0GKDTqfLys7OvlldXZ2Vnp4uy8nJuZGWlmacnp52ejyeANZ4AB/AQ4kigSQg\nT6/XPzebzd8pk4WFBb6+vs6xkVP4/X6+s7PDx8bGPJWVlWasTxGTOJZRInC3oaHh88zMjLDh4OCA\n+3w+4RkIBPhRHB4e8u3tbd7f38+rqqpM2CcJ1YhKu4Vsvq2urnKIzN1uN3c4HHxqaso1Pj7+Y3d3\nVyAicqfTyaHhenNzc1Eo0VF5F2traz+srKwIRFtbW3xoaMjW1tZ2X9Q12WazcZfLxefn53lXV9fb\niooKjZjIsVAkJSXdIw1IFyqvt7d3pLy8PCFksXJgYIAPDg5aGxsbs8OzCY2E+vr692tra4LIFovl\nd15eXmrYqbKmpiZzuNAnRXJ3d7eVStjc3OQo7ZXos7OC5ImjZAA1EE0nSbRarUYulzNoxeCfb/gW\n+A+yGEAvuoC8ZieyoFKpVEulUgYPMVy3Qyzn8IwuiYWNXl5FQB4/9r0gIf+gxG34iEVFRbH8/HwS\nOPakmwovMTMz81JZWZm+oKDAkJiYGENk3o2NjSVYgsXFxbHc3NxCMXX5KYRkFRU2XzEajQZUxSQS\nCdvb2/tJZAfLy8uDyI4pFApmMpkKNRpNJr7rxEaWiaS0NhrQAuk1NTVPoDWDiRmS2RweHrYK9aO0\nFPjMvb+/z3EC7+vr+6VWqx/j321xauhEsa8DJjR9NxIQDI6xxFtbW58emx4tLS0PFhcXhT4kwomJ\nCS/67qNKparH/4fAo4yMDHNHR8c8EdDB1J8w+NRJVors7Ox8t7S0JCwkIH1utVr57Owsn5ub49Ru\ndBAdSC2HG7SVlJRoT7ssaXt7e+3k5KSLiIiQJgRFMBgUmpzIqE97enq+lJaWhrbciYwRKE+NW32G\nIVgcHx9/TSaTMfAxkLsx2ywge40J8zV8bP8VYACAQuluULZPjQAAAABJRU5ErkJggg=="));
/* 138:157 */     refreshButton.setBackgroundColor(getResources().getColor(17170445));
/* 139:158 */     lp2 = new LinearLayout.LayoutParams(-2, -2);
/* 140:    */     
/* 141:    */ 
/* 142:161 */     lp2.weight = 25.0F;
/* 143:162 */     lp2.gravity = 16;
/* 144:    */     
/* 145:164 */     bll.addView(refreshButton, lp2);
/* 146:165 */     if (!i.getBooleanExtra("open_show_refresh", true)) {
/* 147:167 */       refreshButton.setVisibility(8);
/* 148:    */     }
/* 149:168 */     refreshButton.setOnClickListener(new View.OnClickListener()
/* 150:    */     {
/* 151:    */       public void onClick(View arg0)
/* 152:    */       {
/* 153:172 */         WebView wv = (WebView)Browser.this.findViewById(101);
/* 154:173 */         wv.reload();
/* 155:    */       }
/* 156:176 */     });
/* 157:177 */     ImageButton closeButton = new ImageButton(this);
/* 158:    */     
/* 159:    */ 
/* 160:180 */     closeButton.setBackgroundColor(getResources().getColor(17170445));
/* 161:181 */     lp2 = new LinearLayout.LayoutParams(-2, -2);
/* 162:    */     
/* 163:    */ 
/* 164:184 */     lp2.weight = 25.0F;
/* 165:185 */     lp2.gravity = 16;
/* 166:    */     
/* 167:187 */     bll.addView(closeButton, lp2);
/* 168:188 */     closeButton.setOnClickListener(new View.OnClickListener()
/* 169:    */     {
/* 170:    */       public void onClick(View arg0)
/* 171:    */       {
/* 172:192 */         Browser.this.finish();
/* 173:    */       }
/* 174:196 */     });
/* 175:197 */     getWindow().requestFeature(2);
/* 176:    */     
/* 177:    */ 
/* 178:200 */     CookieSyncManager.createInstance(this);
/* 179:201 */     CookieSyncManager.getInstance().startSync();
/* 180:202 */     webview.getSettings().setJavaScriptEnabled(true);
/* 181:203 */     webview.loadUrl(i.getStringExtra("extra_url"));
/* 182:204 */     webview.setId(101);
/* 183:    */     
/* 184:206 */     webview.setWebViewClient(new WebViewClient()
/* 185:    */     {
/* 186:    */       public void onReceivedError(WebView view, int errorCode, String description, String failingUrl)
/* 187:    */       {
/* 188:209 */         TapjoyLog.i("Mraid Browser", "WebView error: " + description);
/* 189:    */       }
/* 190:    */       
/* 191:    */       public boolean shouldOverrideUrlLoading(WebView view, String url)
/* 192:    */       {
/* 193:214 */         view.loadUrl(url);
/* 194:215 */         return true;
/* 195:    */       }
/* 196:    */       
/* 197:    */       public void onPageStarted(WebView view, String url, Bitmap favicon)
/* 198:    */       {
/* 199:220 */         super.onPageStarted(view, url, favicon);
/* 200:221 */         ImageButton forwardButton = (ImageButton)Browser.this.findViewById(102);
/* 201:222 */         forwardButton.setImageBitmap(Browser.this.getDensityScaledBitmap("iVBORw0KGgoAAAANSUhEUgAAABEAAAAUCAYAAABroNZJAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJ\nbWFnZVJlYWR5ccllPAAAAqNJREFUeNqUlEtrE1EUx8+8EjNT27zTaMw0k6RJGpu+VqIi4k7rQtyK\nIn6FrEraRhTET+AnENxUXLpWcFfRhaCbCpY0Lc3DpE07c+dxPTckojTG5sAfhnvP/fE/99wz3IV4\n/Fl1Z+eDZVlVAKigmihjwuejcIpoNZsg+AOBlz6//2E4EonWazUGElC2oesWip7xeIZCMAeEUDhc\npBw3LkqubDqdvs1xQNqt1iHucygGshBEh0LQQREBY2fHx8F2HLfkcl1OJKaut1vtCiEGy6M9V/Yg\nWBcSDIWKHM+PyYoMLpcbJEkCYpoT/mDg1rloNF+tVrcwV0Q5PZjzZ4l/QdiGIAjAoxiI43jOtKyY\nOqXeVRRFrmPgGb5Xot2/rxMQnhe6dA4vRhDFLsymjkApzGta8iYhpNnpdAgrsQ9j3wMh/cB1EAUR\ny3QBsSyPMqbcUFX1UrPRqJimyUAOgw2F9GzhOsLQFXNHiBmMRCeXg8FgfG939wtmtLnszMwuJ4gR\nr98Hoij993E5jgPoAvSjI1A8ngPT0B+JMGIwV263G2RZhulU8lNle/vdyBAWc4XCdijgv7deKr1n\nFzsSJB6L6ZnMdHFtZeVFbrbgxBMa/Pi+BaeCeL1eZ3529tWT8vr9iwsLdiKVhka9BqZBuvtDIRJ2\nY3Fh/jM4dBkBlVQmSxv7NTAMHWzbBkrpcEg+l9ufjIQflFdX32byeRpTVfiJY29Z5u/D/TgBOR+N\nkmw287xcKj2eKczZqqZBs97AthKg2N5B48zjvLOnCzJO6LWrV95g330bG6/XtPS0zeo+aLeBoH3n\nH4CuE5wTktS0r1pSu/O0XP6WzuZop3OIg2Vg3dYJ64OCW1xamvy4ubmXwsOGfgz68TFY+CIdeqq/\nY/f3+EuAAQARwzy3ZhCNHQAAAABJRU5ErkJggg=="));
/* 202:    */       }
/* 203:    */       
/* 204:    */       public void onPageFinished(WebView view, String url)
/* 205:    */       {
/* 206:229 */         super.onPageFinished(view, url);
/* 207:230 */         ImageButton forwardButton = (ImageButton)Browser.this.findViewById(102);
/* 208:    */         
/* 209:232 */         TapjoyLog.i("Mraid Browser", "onPageFinished: " + url);
/* 210:235 */         if (view.canGoForward()) {
/* 211:236 */           forwardButton.setImageBitmap(Browser.this.getDensityScaledBitmap("iVBORw0KGgoAAAANSUhEUgAAABEAAAAUCAYAAABroNZJAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJ\nbWFnZVJlYWR5ccllPAAAAq5JREFUeNqUlN9LmmEUx4++/ihKy6yZGEMjlExdEjgqQmm78ioGu41g\nu7Ftt+5mBF0Go8sIBvsTtggqGgODboK66aIwNi0lJ7p+2TT89b7Pvo/LaKucHTj4+LzP+bzne855\nXpnVan0ZiUSSoiimiCgBP4UXfD4fozpsbW2NhP7+/vdDQ0MvFLBkMnmBfQEuHhwclOHMbDbXhOAM\nCQ6HY8Lr9Tr8fv9ji8Xy6PDw8CKTyUh4LoNzUBkg9l/I4OCg2ePxkNPpfOB2u0cbGhoeQuJZsVjk\nWbHLrMTbYBVIb2/vhMvlMttsNurs7CSj0Si32+0W7D0BRMthOKuAS5cw6brEvyCQQk1NTdTY2Eht\nbW3U1dWlxr6rp6dnJJVKldLpdBEx8kuJYrVeNyAcwE0QBGpubqb29nbq7u7WDgwMjABs39/fz+Ry\nOV4rVoXx9a0QbjKZjJRKJWm1WjIYDIRRMKJeT/ECQzQazZTLZZ4Vb0D5Tsh1mFqtJp1ORyaTSejr\n67MixouMFLFY7AeOnCuoTsMYkV6vJ41GwxugR1cnNzY2POvr66/qhlzPChlRS0tLHuuv6F74XpCq\nYRg/7e7uvh0eHo7wwsrvE5zP53cQPIr6PMcV+T41NVUZvrog6MTPeDz+BoXn1yI0MzMjLS8v09bW\n1p961QpmjJWOj48/rKysvBsfHz+bm5tji4uLBBBls1nCzaeamUD3F1Tf3dHR8RoFPQ0GgywUCtHe\n3h5/dgWoQtg/ur+Fw+Fnra2tfoz7zvT0NFtdXaXt7W06Ojri0m68UI7+5/lCkqRfiUQiGAgEnPj9\nPDs7K3Ldm5ubhP9UKBS4vFuzlqtUqnPo+7i0tGTFpeMfqALXjSEijHdF+13BV/MzNjamWVhYyM7P\nzzOMcSXw5OSESqUS1ft5/C3AAL39YeI2ufApAAAAAElFTkSuQmCC"));
/* 212:    */         } else {
/* 213:239 */           forwardButton.setImageBitmap(Browser.this.getDensityScaledBitmap("iVBORw0KGgoAAAANSUhEUgAAABEAAAAUCAYAAABroNZJAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJ\nbWFnZVJlYWR5ccllPAAAAqNJREFUeNqUlEtrE1EUx8+8EjNT27zTaMw0k6RJGpu+VqIi4k7rQtyK\nIn6FrEraRhTET+AnENxUXLpWcFfRhaCbCpY0Lc3DpE07c+dxPTckojTG5sAfhnvP/fE/99wz3IV4\n/Fl1Z+eDZVlVAKigmihjwuejcIpoNZsg+AOBlz6//2E4EonWazUGElC2oesWip7xeIZCMAeEUDhc\npBw3LkqubDqdvs1xQNqt1iHucygGshBEh0LQQREBY2fHx8F2HLfkcl1OJKaut1vtCiEGy6M9V/Yg\nWBcSDIWKHM+PyYoMLpcbJEkCYpoT/mDg1rloNF+tVrcwV0Q5PZjzZ4l/QdiGIAjAoxiI43jOtKyY\nOqXeVRRFrmPgGb5Xot2/rxMQnhe6dA4vRhDFLsymjkApzGta8iYhpNnpdAgrsQ9j3wMh/cB1EAUR\ny3QBsSyPMqbcUFX1UrPRqJimyUAOgw2F9GzhOsLQFXNHiBmMRCeXg8FgfG939wtmtLnszMwuJ4gR\nr98Hoij993E5jgPoAvSjI1A8ngPT0B+JMGIwV263G2RZhulU8lNle/vdyBAWc4XCdijgv7deKr1n\nFzsSJB6L6ZnMdHFtZeVFbrbgxBMa/Pi+BaeCeL1eZ3529tWT8vr9iwsLdiKVhka9BqZBuvtDIRJ2\nY3Fh/jM4dBkBlVQmSxv7NTAMHWzbBkrpcEg+l9ufjIQflFdX32byeRpTVfiJY29Z5u/D/TgBOR+N\nkmw287xcKj2eKczZqqZBs97AthKg2N5B48zjvLOnCzJO6LWrV95g330bG6/XtPS0zeo+aLeBoH3n\nH4CuE5wTktS0r1pSu/O0XP6WzuZop3OIg2Vg3dYJ64OCW1xamvy4ubmXwsOGfgz68TFY+CIdeqq/\nY/f3+EuAAQARwzy3ZhCNHQAAAABJRU5ErkJggg=="));
/* 214:    */         }
/* 215:    */       }
/* 216:244 */     });
/* 217:245 */     setContentView(rl);
/* 218:    */     
/* 219:247 */     webview.setWebChromeClient(new WebChromeClient()
/* 220:    */     {
/* 221:    */       public void onProgressChanged(WebView view, int progress)
/* 222:    */       {
/* 223:250 */         Activity a = (Activity)view.getContext();
/* 224:251 */         a.setTitle("Loading...");
/* 225:252 */         a.setProgress(progress * 100);
/* 226:253 */         if (progress == 100) {
/* 227:254 */           a.setTitle(view.getUrl());
/* 228:    */         }
/* 229:    */       }
/* 230:    */     });
/* 231:    */   }
/* 232:    */   
/* 233:    */   protected void onPause()
/* 234:    */   {
/* 235:288 */     super.onPause();
/* 236:289 */     CookieSyncManager.getInstance().stopSync();
/* 237:    */   }
/* 238:    */   
/* 239:    */   protected void onResume()
/* 240:    */   {
/* 241:299 */     super.onResume();
/* 242:300 */     CookieSyncManager.getInstance().startSync();
/* 243:    */   }
/* 244:    */   
/* 245:    */   public Bitmap bitmapFromJar(String source)
/* 246:    */   {
/* 247:312 */     InputStream in = null;
/* 248:    */     try
/* 249:    */     {
/* 250:314 */       URL url = Assets.class.getClassLoader().getResource(source);
/* 251:    */       
/* 252:316 */       String file = url.getFile();
/* 253:317 */       if (file.startsWith("file:")) {
/* 254:318 */         file = file.substring(5);
/* 255:    */       }
/* 256:320 */       int pos = file.indexOf("!");
/* 257:321 */       if (pos > 0) {
/* 258:322 */         file = file.substring(0, pos);
/* 259:    */       }
/* 260:323 */       JarFile jf = new JarFile(file);
/* 261:324 */       JarEntry entry = jf.getJarEntry(source);
/* 262:325 */       in = jf.getInputStream(entry);
/* 263:326 */       Bitmap bmp = BitmapFactory.decodeStream(in);
/* 264:327 */       return bmp;
/* 265:    */     }
/* 266:    */     catch (Exception e)
/* 267:    */     {
/* 268:330 */       e.printStackTrace();
/* 269:    */     }
/* 270:    */     finally
/* 271:    */     {
/* 272:332 */       if (in != null)
/* 273:    */       {
/* 274:    */         try
/* 275:    */         {
/* 276:334 */           in.close();
/* 277:    */         }
/* 278:    */         catch (Exception e) {}
/* 279:338 */         in = null;
/* 280:    */       }
/* 281:    */     }
/* 282:341 */     return null;
/* 283:    */   }
/* 284:    */   
/* 285:    */   private Bitmap bitmapFromBase64(String source)
/* 286:    */   {
/* 287:346 */     byte[] decodedByte = Base64.decode(source, 0);
/* 288:347 */     return BitmapFactory.decodeByteArray(decodedByte, 0, decodedByte.length);
/* 289:    */   }
/* 290:    */   
/* 291:    */   private Bitmap getDensityScaledBitmap(String source)
/* 292:    */   {
/* 293:352 */     Bitmap bitmap = null;
/* 294:353 */     DisplayMetrics metrics = new DisplayMetrics();
/* 295:354 */     getWindowManager().getDefaultDisplay().getMetrics(metrics);
/* 296:    */     
/* 297:    */ 
/* 298:357 */     bitmap = bitmapFromBase64(source);
/* 299:359 */     if (bitmap != null)
/* 300:    */     {
/* 301:361 */       int width = bitmap.getWidth();
/* 302:362 */       int height = bitmap.getHeight();
/* 303:363 */       float scaleWidth = metrics.scaledDensity;
/* 304:364 */       float scaleHeight = metrics.scaledDensity;
/* 305:    */       
/* 306:366 */       Matrix matrix = new Matrix();
/* 307:367 */       matrix.postScale(scaleWidth, scaleHeight);
/* 308:    */       
/* 309:369 */       bitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
/* 310:    */     }
/* 311:372 */     return bitmap;
/* 312:    */   }
/* 313:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.mraid.view.Browser
 * JD-Core Version:    0.7.0.1
 */