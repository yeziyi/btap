package com.tapjoy;

import org.json.JSONObject;

public abstract interface TJWebViewJSInterfaceNotifier
{
  public abstract void dispatchMethod(String paramString, JSONObject paramJSONObject);
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TJWebViewJSInterfaceNotifier
 * JD-Core Version:    0.7.0.1
 */