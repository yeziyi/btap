package com.tapjoy;

public class TapjoyHttpURLResponse
{
  public int statusCode;
  public int contentLength;
  public String response;
  public String redirectURL;
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyHttpURLResponse
 * JD-Core Version:    0.7.0.1
 */