/*  1:   */ package com.tapjoy;
/*  2:   */ 
/*  3:   */ import android.net.Uri;
/*  4:   */ import android.util.Log;
/*  5:   */ import java.util.Map;
/*  6:   */ import java.util.TreeSet;
/*  7:   */ import javax.crypto.Mac;
/*  8:   */ import javax.crypto.spec.SecretKeySpec;
/*  9:   */ 
/* 10:   */ public class HmacSignature
/* 11:   */ {
/* 12:   */   private String _method;
/* 13:   */   private String _secret;
/* 14:   */   
/* 15:   */   public HmacSignature(String method, String secret)
/* 16:   */   {
/* 17:16 */     this._method = method;
/* 18:17 */     this._secret = secret;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String sign(String url, Map<String, String> params)
/* 22:   */   {
/* 23:   */     try
/* 24:   */     {
/* 25:22 */       SecretKeySpec signingKey = new SecretKeySpec(this._secret.getBytes(), this._method);
/* 26:23 */       Mac mac = Mac.getInstance(this._method);
/* 27:24 */       mac.init(signingKey);
/* 28:25 */       byte[] hmac = mac.doFinal(prepareMessage(url, params).getBytes());
/* 29:26 */       StringBuilder sb = new StringBuilder();
/* 30:27 */       String ch = "";
/* 31:28 */       for (byte b : hmac)
/* 32:   */       {
/* 33:29 */         ch = Integer.toHexString(0xFF & b);
/* 34:30 */         if (ch.length() == 1) {
/* 35:31 */           sb.append('0');
/* 36:   */         }
/* 37:33 */         sb.append(ch);
/* 38:   */       }
/* 39:35 */       return sb.toString();
/* 40:   */     }
/* 41:   */     catch (Exception e) {}
/* 42:37 */     return null;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public boolean matches(String url, Map<String, String> params, String signature)
/* 46:   */   {
/* 47:41 */     String sig = sign(url, params);
/* 48:42 */     return sig.equals(signature);
/* 49:   */   }
/* 50:   */   
/* 51:   */   private String prepareMessage(String url, Map<String, String> params)
/* 52:   */   {
/* 53:46 */     Uri uri = Uri.parse(url);
/* 54:47 */     String baseUrl = uri.getScheme() + "://" + uri.getHost();
/* 55:48 */     boolean dropPort = ((uri.getScheme().equals("http")) && (uri.getPort() == 80)) || ((uri.getScheme().equals("https")) && (uri.getPort() == 443));
/* 56:49 */     if ((!dropPort) && (-1 != uri.getPort())) {
/* 57:50 */       baseUrl = baseUrl + ":" + uri.getPort();
/* 58:   */     }
/* 59:52 */     baseUrl = baseUrl.toLowerCase();
/* 60:53 */     baseUrl = baseUrl + uri.getPath();
/* 61:54 */     String paramStr = prepareParams(params);
/* 62:55 */     baseUrl = "POST&" + Uri.encode(baseUrl) + "&" + Uri.encode(paramStr);
/* 63:56 */     Log.v("HmacSignature", "Base Url: " + baseUrl);
/* 64:57 */     return baseUrl;
/* 65:   */   }
/* 66:   */   
/* 67:   */   private String prepareParams(Map<String, String> params)
/* 68:   */   {
/* 69:62 */     TreeSet<String> keys = new TreeSet(params.keySet());
/* 70:63 */     StringBuilder message = new StringBuilder();
/* 71:65 */     for (String key : keys)
/* 72:   */     {
/* 73:66 */       String val = (String)params.get(key);
/* 74:67 */       message.append(key + "=" + val + "&");
/* 75:   */     }
/* 76:69 */     message.deleteCharAt(message.lastIndexOf("&"));
/* 77:70 */     Log.v("HmacSignature", "Unhashed String: " + message.toString());
/* 78:71 */     return message.toString();
/* 79:   */   }
/* 80:   */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.HmacSignature
 * JD-Core Version:    0.7.0.1
 */