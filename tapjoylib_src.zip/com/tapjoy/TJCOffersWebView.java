/*  1:   */ package com.tapjoy;
/*  2:   */ 
/*  3:   */ import android.annotation.TargetApi;
/*  4:   */ import android.os.Bundle;
/*  5:   */ import android.webkit.WebView;
/*  6:   */ import com.tapjoy.mraid.view.MraidView;
/*  7:   */ 
/*  8:   */ @TargetApi(9)
/*  9:   */ public class TJCOffersWebView
/* 10:   */   extends TJAdUnitView
/* 11:   */ {
/* 12:   */   private static final String TAG = "Offers";
/* 13:18 */   private boolean isInitialLoad = true;
/* 14:   */   
/* 15:   */   protected void onCreate(Bundle savedInstanceState)
/* 16:   */   {
/* 17:23 */     super.onCreate(savedInstanceState);
/* 18:   */     
/* 19:25 */     TapjoyConnectCore.viewWillOpen(0);
/* 20:26 */     TapjoyConnectCore.viewDidOpen(0);
/* 21:   */   }
/* 22:   */   
/* 23:   */   protected void onResume()
/* 24:   */   {
/* 25:32 */     super.onResume();
/* 26:35 */     if ((this.offersURL != null) && (this.webView != null) && (this.pauseCalled == true) && (this.redirectedActivity == true))
/* 27:   */     {
/* 28:37 */       TapjoyLog.i("Offers", "onResume reload offer wall: " + this.offersURL);
/* 29:38 */       this.webView.loadUrl(this.offersURL);
/* 30:   */       
/* 31:   */ 
/* 32:41 */       this.historyIndex += 1;
/* 33:   */     }
/* 34:   */   }
/* 35:   */   
/* 36:   */   protected void onDestroy()
/* 37:   */   {
/* 38:48 */     super.onDestroy();
/* 39:51 */     if ((!this.skipOfferWall) && (isFinishing()))
/* 40:   */     {
/* 41:53 */       TapjoyConnectCore.viewWillClose(0);
/* 42:54 */       TapjoyConnectCore.viewDidClose(0);
/* 43:   */     }
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void handleWebViewOnReceivedError(WebView view, int errorCode, String description, String failingUrl)
/* 47:   */   {
/* 48:61 */     if (this.isInitialLoad)
/* 49:   */     {
/* 50:63 */       this.isInitialLoad = false;
/* 51:64 */       finish();
/* 52:65 */       TJCOffers.getOffersNotifierResponseFailed("Failed to load offers from server");
/* 53:   */       
/* 54:67 */       TapjoyLog.i("Offers", "getOffersNotifierResponseFailed fired");
/* 55:   */     }
/* 56:   */     else
/* 57:   */     {
/* 58:71 */       super.handleWebViewOnReceivedError(view, errorCode, description, failingUrl);
/* 59:   */     }
/* 60:   */   }
/* 61:   */   
/* 62:   */   public void handleWebViewOnPageFinished(WebView view, String url)
/* 63:   */   {
/* 64:78 */     if (this.isInitialLoad)
/* 65:   */     {
/* 66:80 */       this.isInitialLoad = false;
/* 67:81 */       TJCOffers.getOffersNotifierResponse();
/* 68:   */       
/* 69:83 */       TapjoyLog.i("Offers", "getOffersNotifierResponse fired");
/* 70:   */     }
/* 71:   */     else
/* 72:   */     {
/* 73:87 */       super.handleWebViewOnPageFinished(view, url);
/* 74:   */     }
/* 75:   */   }
/* 76:   */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TJCOffersWebView
 * JD-Core Version:    0.7.0.1
 */