package com.tapjoy;

public abstract interface TapjoyDailyRewardAdNotifier
{
  /**
   * @deprecated
   */
  public abstract void getDailyRewardAdResponse();
  
  /**
   * @deprecated
   */
  public abstract void getDailyRewardAdResponseFailed(int paramInt);
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyDailyRewardAdNotifier
 * JD-Core Version:    0.7.0.1
 */