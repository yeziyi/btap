package com.tapjoy;

public abstract interface TapjoyVideoNotifier
{
  public abstract void videoStart();
  
  public abstract void videoError(int paramInt);
  
  public abstract void videoComplete();
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyVideoNotifier
 * JD-Core Version:    0.7.0.1
 */