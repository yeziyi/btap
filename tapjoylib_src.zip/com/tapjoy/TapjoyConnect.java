/*   1:    */ package com.tapjoy;
/*   2:    */ 
/*   3:    */ import android.app.Activity;
/*   4:    */ import android.content.Context;
/*   5:    */ import android.util.Log;
/*   6:    */ import java.util.Hashtable;
/*   7:    */ 
/*   8:    */ public final class TapjoyConnect
/*   9:    */ {
/*  10: 22 */   private static TapjoyConnect tapjoyConnectInstance = null;
/*  11:    */   private static final String TAG = "TapjoyConnect";
/*  12: 25 */   private static TJCOffers tapjoyOffers = null;
/*  13: 26 */   private static TJPoints tapjoyPoints = null;
/*  14: 27 */   private static TapjoyFullScreenAd tapjoyFullScreenAd = null;
/*  15: 28 */   private static TapjoyDisplayAd tapjoyDisplayAd = null;
/*  16: 29 */   private static TapjoyVideo tapjoyVideo = null;
/*  17: 30 */   private static TapjoyEvent tapjoyEvent = null;
/*  18: 31 */   private static TapjoyDailyRewardAd tapjoyDailyRewardAd = null;
/*  19: 34 */   private static Hashtable<String, String> connectFlags = null;
/*  20:    */   
/*  21:    */   public static void setFlagKeyValue(String key, String value)
/*  22:    */   {
/*  23: 45 */     if (connectFlags == null) {
/*  24: 46 */       connectFlags = new Hashtable();
/*  25:    */     }
/*  26: 47 */     connectFlags.put(key, value);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void setExternalResource(String key, Object value)
/*  30:    */   {
/*  31: 54 */     TapjoyUtil.setResource(key, value);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static void enableLogging(boolean enable)
/*  35:    */   {
/*  36: 63 */     TapjoyLog.enableLogging(enable);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static boolean requestTapjoyConnect(Context context, String appID, String secretKey)
/*  40:    */   {
/*  41: 79 */     return requestTapjoyConnect(context, appID, secretKey, connectFlags);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static boolean requestTapjoyConnect(Context context, String appID, String secretKey, Hashtable<String, String> flags)
/*  45:    */   {
/*  46: 98 */     return requestTapjoyConnect(context, appID, secretKey, flags, null);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static boolean requestTapjoyConnect(Context context, String appID, String secretKey, Hashtable<String, String> flags, TapjoyConnectNotifier notifier)
/*  50:    */   {
/*  51:120 */     TapjoyConnectCore.setSDKType("offers");
/*  52:    */     try
/*  53:    */     {
/*  54:123 */       tapjoyConnectInstance = new TapjoyConnect(context, appID, secretKey, flags, notifier);
/*  55:    */     }
/*  56:    */     catch (TapjoyIntegrationException e)
/*  57:    */     {
/*  58:127 */       Log.e("TapjoyConnect", "IntegrationException: " + e.getMessage());
/*  59:128 */       if (notifier != null) {
/*  60:129 */         notifier.connectFail();
/*  61:    */       }
/*  62:130 */       return false;
/*  63:    */     }
/*  64:    */     catch (TapjoyException e)
/*  65:    */     {
/*  66:134 */       Log.e("TapjoyConnect", "TapjoyException: " + e.getMessage());
/*  67:135 */       if (notifier != null) {
/*  68:136 */         notifier.connectFail();
/*  69:    */       }
/*  70:137 */       return false;
/*  71:    */     }
/*  72:139 */     tapjoyOffers = new TJCOffers(context);
/*  73:140 */     tapjoyPoints = new TJPoints(context);
/*  74:141 */     tapjoyFullScreenAd = new TapjoyFullScreenAd(context);
/*  75:142 */     tapjoyDisplayAd = new TapjoyDisplayAd(context);
/*  76:143 */     tapjoyVideo = new TapjoyVideo(context);
/*  77:144 */     tapjoyEvent = new TapjoyEvent(context);
/*  78:145 */     tapjoyDailyRewardAd = new TapjoyDailyRewardAd(context);
/*  79:    */     
/*  80:    */ 
/*  81:148 */     connectFlags = null;
/*  82:    */     
/*  83:150 */     return true;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public static TapjoyConnect getTapjoyConnectInstance()
/*  87:    */   {
/*  88:160 */     if (tapjoyConnectInstance == null)
/*  89:    */     {
/*  90:162 */       Log.e("TapjoyConnect", "----------------------------------------");
/*  91:163 */       Log.e("TapjoyConnect", "ERROR -- call requestTapjoyConnect before any other Tapjoy methods");
/*  92:164 */       Log.e("TapjoyConnect", "----------------------------------------");
/*  93:    */     }
/*  94:167 */     return tapjoyConnectInstance;
/*  95:    */   }
/*  96:    */   
/*  97:    */   private TapjoyConnect(Context context, String appID, String secretKey, Hashtable<String, String> flags, TapjoyConnectNotifier notifier)
/*  98:    */     throws TapjoyException
/*  99:    */   {
/* 100:182 */     TapjoyConnectCore.requestTapjoyConnect(context, appID, secretKey, flags, notifier);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public void appPause()
/* 104:    */   {
/* 105:191 */     TapjoyConnectCore.getInstance().appPause();
/* 106:    */   }
/* 107:    */   
/* 108:    */   public void appResume()
/* 109:    */   {
/* 110:199 */     TapjoyConnectCore.getInstance().appResume();
/* 111:    */   }
/* 112:    */   
/* 113:    */   public void setUserID(String userID)
/* 114:    */   {
/* 115:211 */     TapjoyConnectCore.setUserID(userID);
/* 116:    */   }
/* 117:    */   
/* 118:    */   public String getUserID()
/* 119:    */   {
/* 120:221 */     return TapjoyConnectCore.getUserID();
/* 121:    */   }
/* 122:    */   
/* 123:    */   public String getAppID()
/* 124:    */   {
/* 125:231 */     return TapjoyConnectCore.getAppID();
/* 126:    */   }
/* 127:    */   
/* 128:    */   public void enablePaidAppWithActionID(String paidAppPayPerActionID)
/* 129:    */   {
/* 130:246 */     TapjoyConnectCore.getInstance().enablePaidAppWithActionID(paidAppPayPerActionID);
/* 131:    */   }
/* 132:    */   
/* 133:    */   public void setCurrencyMultiplier(float multiplier)
/* 134:    */   {
/* 135:257 */     TapjoyConnectCore.getInstance().setCurrencyMultiplier(multiplier);
/* 136:    */   }
/* 137:    */   
/* 138:    */   public float getCurrencyMultiplier()
/* 139:    */   {
/* 140:267 */     return TapjoyConnectCore.getInstance().getCurrencyMultiplier();
/* 141:    */   }
/* 142:    */   
/* 143:    */   public void setTapjoyViewNotifier(TapjoyViewNotifier notifier)
/* 144:    */   {
/* 145:277 */     TapjoyConnectCore.getInstance().setTapjoyViewNotifier(notifier);
/* 146:    */   }
/* 147:    */   
/* 148:    */   public void actionComplete(String actionID)
/* 149:    */   {
/* 150:293 */     TapjoyConnectCore.getInstance().actionComplete(actionID);
/* 151:    */   }
/* 152:    */   
/* 153:    */   public void showOffers()
/* 154:    */   {
/* 155:307 */     tapjoyOffers.showOffers(null);
/* 156:    */   }
/* 157:    */   
/* 158:    */   public void showOffersWithCurrencyID(String currencyID, boolean enableCurrencySelector)
/* 159:    */   {
/* 160:318 */     tapjoyOffers.showOffersWithCurrencyID(currencyID, enableCurrencySelector, null);
/* 161:    */   }
/* 162:    */   
/* 163:    */   public void showOffers(TapjoyOffersNotifier notifier)
/* 164:    */   {
/* 165:328 */     tapjoyOffers.showOffers(notifier);
/* 166:    */   }
/* 167:    */   
/* 168:    */   public void showOffersWithCurrencyID(String currencyID, boolean enableCurrencySelector, TapjoyOffersNotifier notifier)
/* 169:    */   {
/* 170:341 */     tapjoyOffers.showOffersWithCurrencyID(currencyID, enableCurrencySelector, notifier);
/* 171:    */   }
/* 172:    */   
/* 173:    */   public void getTapPoints(TapjoyNotifier notifier)
/* 174:    */   {
/* 175:351 */     tapjoyPoints.getTapPoints(notifier);
/* 176:    */   }
/* 177:    */   
/* 178:    */   public void spendTapPoints(int amount, TapjoySpendPointsNotifier notifier)
/* 179:    */   {
/* 180:362 */     tapjoyPoints.spendTapPoints(amount, notifier);
/* 181:    */   }
/* 182:    */   
/* 183:    */   public void awardTapPoints(int amount, TapjoyAwardPointsNotifier notifier)
/* 184:    */   {
/* 185:373 */     tapjoyPoints.awardTapPoints(amount, notifier);
/* 186:    */   }
/* 187:    */   
/* 188:    */   public void setEarnedPointsNotifier(TapjoyEarnedPointsNotifier notifier)
/* 189:    */   {
/* 190:383 */     tapjoyPoints.setEarnedPointsNotifier(notifier);
/* 191:    */   }
/* 192:    */   
/* 193:    */   public void getFullScreenAd(TapjoyFullScreenAdNotifier notifier)
/* 194:    */   {
/* 195:400 */     tapjoyFullScreenAd.getFullScreenAd(notifier);
/* 196:    */   }
/* 197:    */   
/* 198:    */   public void getFullScreenAdWithCurrencyID(String currencyID, TapjoyFullScreenAdNotifier notifier)
/* 199:    */   {
/* 200:414 */     tapjoyFullScreenAd.getFullScreenAd(currencyID, notifier);
/* 201:    */   }
/* 202:    */   
/* 203:    */   public void showFullScreenAd()
/* 204:    */   {
/* 205:425 */     tapjoyFullScreenAd.showFullScreenAd();
/* 206:    */   }
/* 207:    */   
/* 208:    */   /**
/* 209:    */    * @deprecated
/* 210:    */    */
/* 211:    */   public void getFeaturedApp(TapjoyFeaturedAppNotifier notifier)
/* 212:    */   {
/* 213:437 */     tapjoyFullScreenAd.getFeaturedApp(notifier);
/* 214:    */   }
/* 215:    */   
/* 216:    */   /**
/* 217:    */    * @deprecated
/* 218:    */    */
/* 219:    */   public void getFeaturedAppWithCurrencyID(String currencyID, TapjoyFeaturedAppNotifier notifier)
/* 220:    */   {
/* 221:451 */     tapjoyFullScreenAd.getFeaturedApp(currencyID, notifier);
/* 222:    */   }
/* 223:    */   
/* 224:    */   /**
/* 225:    */    * @deprecated
/* 226:    */    */
/* 227:    */   public void setFeaturedAppDisplayCount(int count)
/* 228:    */   {
/* 229:462 */     tapjoyFullScreenAd.setDisplayCount(count);
/* 230:    */   }
/* 231:    */   
/* 232:    */   /**
/* 233:    */    * @deprecated
/* 234:    */    */
/* 235:    */   public void showFeaturedAppFullScreenAd()
/* 236:    */   {
/* 237:474 */     tapjoyFullScreenAd.showFeaturedAppFullScreenAd();
/* 238:    */   }
/* 239:    */   
/* 240:    */   /**
/* 241:    */    * @deprecated
/* 242:    */    */
/* 243:    */   public void getDailyRewardAd(TapjoyDailyRewardAdNotifier notifier)
/* 244:    */   {
/* 245:492 */     tapjoyDailyRewardAd.getDailyRewardAd(notifier);
/* 246:    */   }
/* 247:    */   
/* 248:    */   /**
/* 249:    */    * @deprecated
/* 250:    */    */
/* 251:    */   public void getDailyRewardAdWithCurrencyID(String currencyID, TapjoyDailyRewardAdNotifier notifier)
/* 252:    */   {
/* 253:508 */     tapjoyDailyRewardAd.getDailyRewardAdWithCurrencyID(currencyID, notifier);
/* 254:    */   }
/* 255:    */   
/* 256:    */   /**
/* 257:    */    * @deprecated
/* 258:    */    */
/* 259:    */   public void showDailyRewardAd()
/* 260:    */   {
/* 261:522 */     tapjoyDailyRewardAd.showDailyRewardAd();
/* 262:    */   }
/* 263:    */   
/* 264:    */   public void setDisplayAdSize(String dimensions)
/* 265:    */   {
/* 266:541 */     tapjoyDisplayAd.setDisplayAdSize(dimensions);
/* 267:    */   }
/* 268:    */   
/* 269:    */   /**
/* 270:    */    * @deprecated
/* 271:    */    */
/* 272:    */   public void setBannerAdSize(String dimensions)
/* 273:    */   {
/* 274:557 */     tapjoyDisplayAd.setBannerAdSize(dimensions);
/* 275:    */   }
/* 276:    */   
/* 277:    */   public void enableDisplayAdAutoRefresh(boolean shouldAutoRefresh)
/* 278:    */   {
/* 279:567 */     tapjoyDisplayAd.enableAutoRefresh(shouldAutoRefresh);
/* 280:    */   }
/* 281:    */   
/* 282:    */   /**
/* 283:    */    * @deprecated
/* 284:    */    */
/* 285:    */   public void enableBannerAdAutoRefresh(boolean shouldAutoRefresh)
/* 286:    */   {
/* 287:579 */     tapjoyDisplayAd.enableAutoRefresh(shouldAutoRefresh);
/* 288:    */   }
/* 289:    */   
/* 290:    */   /**
/* 291:    */    * @deprecated
/* 292:    */    */
/* 293:    */   public void getDisplayAd(TapjoyDisplayAdNotifier notifier)
/* 294:    */   {
/* 295:592 */     tapjoyDisplayAd.getDisplayAd(null, notifier);
/* 296:    */   }
/* 297:    */   
/* 298:    */   /**
/* 299:    */    * @deprecated
/* 300:    */    */
/* 301:    */   public void getDisplayAdWithCurrencyID(String currencyID, TapjoyDisplayAdNotifier notifier)
/* 302:    */   {
/* 303:607 */     tapjoyDisplayAd.getDisplayAd(null, currencyID, notifier);
/* 304:    */   }
/* 305:    */   
/* 306:    */   public void getDisplayAd(Activity activity, TapjoyDisplayAdNotifier notifier)
/* 307:    */   {
/* 308:619 */     tapjoyDisplayAd.getDisplayAd(activity, notifier);
/* 309:    */   }
/* 310:    */   
/* 311:    */   public void getDisplayAdWithCurrencyID(Activity activity, String currencyID, TapjoyDisplayAdNotifier notifier)
/* 312:    */   {
/* 313:633 */     tapjoyDisplayAd.getDisplayAd(activity, currencyID, notifier);
/* 314:    */   }
/* 315:    */   
/* 316:    */   /**
/* 317:    */    * @deprecated
/* 318:    */    */
/* 319:    */   public void initVideoAd(TapjoyVideoNotifier notifier)
/* 320:    */   {
/* 321:649 */     tapjoyVideo.initVideoAd(notifier);
/* 322:    */   }
/* 323:    */   
/* 324:    */   public void setVideoCacheCount(int count)
/* 325:    */   {
/* 326:659 */     tapjoyVideo.setVideoCacheCount(count);
/* 327:    */   }
/* 328:    */   
/* 329:    */   /**
/* 330:    */    * @deprecated
/* 331:    */    */
/* 332:    */   public void enableVideoCache(boolean enable)
/* 333:    */   {
/* 334:669 */     tapjoyVideo.enableVideoCache(enable);
/* 335:    */   }
/* 336:    */   
/* 337:    */   public void cacheVideos()
/* 338:    */   {
/* 339:680 */     tapjoyVideo.cacheVideos();
/* 340:    */   }
/* 341:    */   
/* 342:    */   public void setVideoNotifier(TapjoyVideoNotifier notifier)
/* 343:    */   {
/* 344:689 */     tapjoyVideo.setVideoNotifier(notifier);
/* 345:    */   }
/* 346:    */   
/* 347:    */   public void sendShutDownEvent()
/* 348:    */   {
/* 349:701 */     tapjoyEvent.sendShutDownEvent();
/* 350:    */   }
/* 351:    */   
/* 352:    */   public void sendIAPEvent(String name, float price, int quantity, String currencyCode)
/* 353:    */   {
/* 354:714 */     tapjoyEvent.sendIAPEvent(name, price, quantity, currencyCode);
/* 355:    */   }
/* 356:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyConnect
 * JD-Core Version:    0.7.0.1
 */