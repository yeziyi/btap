/*  1:   */ package com.tapjoy;
/*  2:   */ 
/*  3:   */ public class TJError
/*  4:   */ {
/*  5:   */   public int code;
/*  6:   */   public String message;
/*  7:   */   
/*  8:   */   public TJError(int errorCode, String errorMessage)
/*  9:   */   {
/* 10:10 */     this.code = errorCode;
/* 11:11 */     this.message = errorMessage;
/* 12:   */   }
/* 13:   */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TJError
 * JD-Core Version:    0.7.0.1
 */