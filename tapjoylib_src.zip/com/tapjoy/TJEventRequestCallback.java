package com.tapjoy;

public abstract interface TJEventRequestCallback
{
  public abstract void completed();
  
  public abstract void cancelled();
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TJEventRequestCallback
 * JD-Core Version:    0.7.0.1
 */