/*   1:    */ package com.tapjoy;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.content.res.AssetManager;
/*   5:    */ import android.graphics.Bitmap;
/*   6:    */ import android.graphics.Bitmap.Config;
/*   7:    */ import android.graphics.Canvas;
/*   8:    */ import android.net.Uri;
/*   9:    */ import android.view.View;
/*  10:    */ import android.view.ViewGroup.LayoutParams;
/*  11:    */ import android.webkit.WebSettings;
/*  12:    */ import android.webkit.WebView;
/*  13:    */ import java.io.ByteArrayInputStream;
/*  14:    */ import java.io.File;
/*  15:    */ import java.io.InputStream;
/*  16:    */ import java.io.UnsupportedEncodingException;
/*  17:    */ import java.net.URL;
/*  18:    */ import java.security.MessageDigest;
/*  19:    */ import java.security.NoSuchAlgorithmException;
/*  20:    */ import java.util.HashMap;
/*  21:    */ import java.util.Map;
/*  22:    */ import java.util.Map.Entry;
/*  23:    */ import java.util.jar.JarEntry;
/*  24:    */ import java.util.jar.JarFile;
/*  25:    */ import javax.xml.parsers.DocumentBuilder;
/*  26:    */ import javax.xml.parsers.DocumentBuilderFactory;
/*  27:    */ import org.w3c.dom.Document;
/*  28:    */ import org.w3c.dom.Element;
/*  29:    */ import org.w3c.dom.Node;
/*  30:    */ import org.w3c.dom.NodeList;
/*  31:    */ 
/*  32:    */ public class TapjoyUtil
/*  33:    */ {
/*  34:    */   private static final String TAG = "TapjoyUtil";
/*  35: 37 */   private static String mraidJs = null;
/*  36: 39 */   private static HashMap<String, Object> _resources = new HashMap();
/*  37:    */   
/*  38:    */   public static String SHA1(String text)
/*  39:    */     throws NoSuchAlgorithmException, UnsupportedEncodingException
/*  40:    */   {
/*  41: 52 */     return hashAlgorithm("SHA-1", text);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static String SHA256(String text)
/*  45:    */     throws NoSuchAlgorithmException, UnsupportedEncodingException
/*  46:    */   {
/*  47: 67 */     return hashAlgorithm("SHA-256", text);
/*  48:    */   }
/*  49:    */   
/*  50:    */   private static String hashAlgorithm(String hash, String text)
/*  51:    */     throws NoSuchAlgorithmException, UnsupportedEncodingException
/*  52:    */   {
/*  53: 84 */     byte[] sha1hash = new byte[40];
/*  54:    */     
/*  55:    */ 
/*  56: 87 */     MessageDigest md = MessageDigest.getInstance(hash);
/*  57: 88 */     md.update(text.getBytes("iso-8859-1"), 0, text.length());
/*  58: 89 */     sha1hash = md.digest();
/*  59:    */     
/*  60: 91 */     return convertToHex(sha1hash);
/*  61:    */   }
/*  62:    */   
/*  63:    */   private static String convertToHex(byte[] data)
/*  64:    */   {
/*  65:103 */     StringBuffer buf = new StringBuffer();
/*  66:105 */     for (int i = 0; i < data.length; i++)
/*  67:    */     {
/*  68:107 */       int halfbyte = data[i] >>> 4 & 0xF;
/*  69:108 */       int two_halfs = 0;
/*  70:    */       do
/*  71:    */       {
/*  72:112 */         if ((0 <= halfbyte) && (halfbyte <= 9)) {
/*  73:113 */           buf.append((char)(48 + halfbyte));
/*  74:    */         } else {
/*  75:115 */           buf.append((char)(97 + (halfbyte - 10)));
/*  76:    */         }
/*  77:116 */         halfbyte = data[i] & 0xF;
/*  78:119 */       } while (two_halfs++ < 1);
/*  79:    */     }
/*  80:122 */     return buf.toString();
/*  81:    */   }
/*  82:    */   
/*  83:    */   public static Document buildDocument(String xml)
/*  84:    */   {
/*  85:134 */     Document document = null;
/*  86:    */     try
/*  87:    */     {
/*  88:138 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/*  89:    */       
/*  90:    */ 
/*  91:    */ 
/*  92:142 */       InputStream is = new ByteArrayInputStream(xml.getBytes("UTF-8"));
/*  93:    */       
/*  94:144 */       DocumentBuilder documentBuilder = factory.newDocumentBuilder();
/*  95:145 */       document = documentBuilder.parse(is);
/*  96:    */     }
/*  97:    */     catch (Exception e)
/*  98:    */     {
/*  99:149 */       TapjoyLog.e("TapjoyUtil", "buildDocument exception: " + e.toString());
/* 100:    */     }
/* 101:152 */     return document;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public static String getNodeTrimValue(NodeList nodeList)
/* 105:    */   {
/* 106:163 */     Element element = (Element)nodeList.item(0);
/* 107:164 */     String nodeValue = "";
/* 108:166 */     if (element != null)
/* 109:    */     {
/* 110:168 */       NodeList itemNodeList = element.getChildNodes();
/* 111:    */       
/* 112:170 */       int length = itemNodeList.getLength();
/* 113:172 */       for (int i = 0; i < length; i++)
/* 114:    */       {
/* 115:174 */         Node node = itemNodeList.item(i);
/* 116:175 */         if (node != null) {
/* 117:176 */           nodeValue = nodeValue + node.getNodeValue();
/* 118:    */         }
/* 119:    */       }
/* 120:179 */       if ((nodeValue != null) && (!nodeValue.equals(""))) {
/* 121:181 */         return nodeValue.trim();
/* 122:    */       }
/* 123:185 */       return null;
/* 124:    */     }
/* 125:188 */     return null;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public static void deleteFileOrDirectory(File fileOrDirectory)
/* 129:    */   {
/* 130:199 */     if (fileOrDirectory.isDirectory()) {
/* 131:201 */       for (File child : fileOrDirectory.listFiles()) {
/* 132:202 */         deleteFileOrDirectory(child);
/* 133:    */       }
/* 134:    */     }
/* 135:205 */     TapjoyLog.i("TapjoyUtil", "****************************************");
/* 136:206 */     TapjoyLog.i("TapjoyUtil", "deleteFileOrDirectory: " + fileOrDirectory.getAbsolutePath());
/* 137:207 */     TapjoyLog.i("TapjoyUtil", "****************************************");
/* 138:208 */     fileOrDirectory.delete();
/* 139:    */   }
/* 140:    */   
/* 141:    */   public static Bitmap createBitmapFromView(View v)
/* 142:    */   {
/* 143:219 */     Bitmap b = null;
/* 144:221 */     if ((v != null) && (v.getLayoutParams().width > 0) && (v.getLayoutParams().height > 0)) {
/* 145:    */       try
/* 146:    */       {
/* 147:225 */         b = Bitmap.createBitmap(v.getLayoutParams().width, v.getLayoutParams().height, Bitmap.Config.ARGB_8888);
/* 148:226 */         Canvas c = new Canvas(b);
/* 149:227 */         v.layout(v.getLeft(), v.getTop(), v.getRight(), v.getBottom());
/* 150:228 */         v.draw(c);
/* 151:    */       }
/* 152:    */       catch (Exception e)
/* 153:    */       {
/* 154:232 */         TapjoyLog.i("TapjoyUtil", "error creating bitmap: " + e.toString());
/* 155:    */       }
/* 156:    */     }
/* 157:236 */     return b;
/* 158:    */   }
/* 159:    */   
/* 160:    */   public static View scaleDisplayAd(View adView, int targetWidth)
/* 161:    */   {
/* 162:247 */     int adWidth = adView.getLayoutParams().width;
/* 163:248 */     int adHeight = adView.getLayoutParams().height;
/* 164:    */     
/* 165:250 */     TapjoyLog.i("TapjoyUtil", "wxh: " + adWidth + "x" + adHeight);
/* 166:253 */     if (adWidth > targetWidth)
/* 167:    */     {
/* 168:256 */       int width = targetWidth;
/* 169:257 */       Double val = Double.valueOf(Double.valueOf(width).doubleValue() / Double.valueOf(adWidth).doubleValue());
/* 170:258 */       val = Double.valueOf(val.doubleValue() * 100.0D);
/* 171:259 */       int scale = val.intValue();
/* 172:    */       
/* 173:261 */       ((WebView)adView).getSettings().setSupportZoom(true);
/* 174:262 */       ((WebView)adView).setPadding(0, 0, 0, 0);
/* 175:263 */       ((WebView)adView).setVerticalScrollBarEnabled(false);
/* 176:264 */       ((WebView)adView).setHorizontalScrollBarEnabled(false);
/* 177:265 */       ((WebView)adView).setInitialScale(scale);
/* 178:    */       
/* 179:    */ 
/* 180:268 */       ViewGroup.LayoutParams layout = new ViewGroup.LayoutParams(targetWidth, targetWidth * adHeight / adWidth);
/* 181:269 */       adView.setLayoutParams(layout);
/* 182:    */     }
/* 183:272 */     return adView;
/* 184:    */   }
/* 185:    */   
/* 186:    */   public static void safePut(Map<String, String> map, String key, String value, boolean encode)
/* 187:    */   {
/* 188:284 */     if ((key != null) && (key.length() > 0) && (value != null) && (value.length() > 0)) {
/* 189:286 */       if (encode) {
/* 190:287 */         map.put(Uri.encode(key), Uri.encode(value));
/* 191:    */       } else {
/* 192:289 */         map.put(key, value);
/* 193:    */       }
/* 194:    */     }
/* 195:    */   }
/* 196:    */   
/* 197:    */   public static String convertURLParams(Map<String, String> source, boolean encode)
/* 198:    */   {
/* 199:301 */     String result = "";
/* 200:303 */     for (Map.Entry<String, String> entry : source.entrySet())
/* 201:    */     {
/* 202:306 */       if (result.length() > 0) {
/* 203:307 */         result = result + "&";
/* 204:    */       }
/* 205:309 */       if (encode) {
/* 206:310 */         result = result + Uri.encode((String)entry.getKey()) + "=" + Uri.encode((String)entry.getValue());
/* 207:    */       } else {
/* 208:312 */         result = result + (String)entry.getKey() + "=" + (String)entry.getValue();
/* 209:    */       }
/* 210:    */     }
/* 211:315 */     return result;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public static Map<String, String> convertURLParams(String source, boolean decode)
/* 215:    */   {
/* 216:326 */     Map<String, String> result = new HashMap();
/* 217:    */     
/* 218:328 */     int index = 0;
/* 219:    */     
/* 220:330 */     int KEY = 0;
/* 221:331 */     int VALUE = 1;
/* 222:332 */     int mode = 0;
/* 223:    */     
/* 224:334 */     String word = "";
/* 225:335 */     String key = "";
/* 226:336 */     String value = "";
/* 227:339 */     while ((index < source.length()) && (index != -1))
/* 228:    */     {
/* 229:342 */       char c = source.charAt(index);
/* 230:345 */       if (mode == 0)
/* 231:    */       {
/* 232:348 */         if (c == '=')
/* 233:    */         {
/* 234:350 */           mode = 1;
/* 235:351 */           if (decode) {
/* 236:352 */             key = Uri.decode(word);
/* 237:    */           } else {
/* 238:354 */             key = word;
/* 239:    */           }
/* 240:355 */           word = "";
/* 241:    */         }
/* 242:    */         else
/* 243:    */         {
/* 244:360 */           word = word + c;
/* 245:    */         }
/* 246:    */       }
/* 247:365 */       else if (mode == 1) {
/* 248:368 */         if (c == '&')
/* 249:    */         {
/* 250:370 */           mode = 0;
/* 251:372 */           if (decode) {
/* 252:373 */             value = Uri.decode(word);
/* 253:    */           } else {
/* 254:375 */             value = word;
/* 255:    */           }
/* 256:376 */           word = "";
/* 257:    */           
/* 258:    */ 
/* 259:379 */           result.put(key, value);
/* 260:    */         }
/* 261:    */         else
/* 262:    */         {
/* 263:384 */           word = word + c;
/* 264:    */         }
/* 265:    */       }
/* 266:388 */       index++;
/* 267:    */     }
/* 268:392 */     if ((mode == 1) && (word.length() > 0))
/* 269:    */     {
/* 270:394 */       if (decode) {
/* 271:395 */         value = Uri.decode(word);
/* 272:    */       } else {
/* 273:397 */         value = word;
/* 274:    */       }
/* 275:399 */       result.put(key, value);
/* 276:    */     }
/* 277:402 */     return result;
/* 278:    */   }
/* 279:    */   
/* 280:    */   public static String copyTextFromJarIntoString(String source)
/* 281:    */   {
/* 282:411 */     return copyTextFromJarIntoString(source, null);
/* 283:    */   }
/* 284:    */   
/* 285:    */   public static String copyTextFromJarIntoString(String source, Context context)
/* 286:    */   {
/* 287:421 */     byte[] buff = new byte[1024];
/* 288:422 */     StringBuffer buffer = new StringBuffer();
/* 289:423 */     InputStream in = null;
/* 290:424 */     URL url = TapjoyUtil.class.getClassLoader().getResource(source);
/* 291:    */     try
/* 292:    */     {
/* 293:427 */       if ((context != null) && (url == null))
/* 294:    */       {
/* 295:429 */         AssetManager am = context.getAssets();
/* 296:430 */         in = am.open(source);
/* 297:    */       }
/* 298:    */       else
/* 299:    */       {
/* 300:434 */         String file = url.getFile();
/* 301:435 */         if (file.startsWith("jar:")) {
/* 302:436 */           file = file.substring(4);
/* 303:    */         }
/* 304:438 */         if (file.startsWith("file:")) {
/* 305:439 */           file = file.substring(5);
/* 306:    */         }
/* 307:441 */         int pos = file.indexOf("!");
/* 308:442 */         if (pos > 0) {
/* 309:443 */           file = file.substring(0, pos);
/* 310:    */         }
/* 311:444 */         JarFile jf = new JarFile(file);
/* 312:445 */         JarEntry entry = jf.getJarEntry(source);
/* 313:446 */         in = jf.getInputStream(entry);
/* 314:    */       }
/* 315:    */       int numread;
/* 316:    */       for (;;)
/* 317:    */       {
/* 318:450 */         numread = in.read(buff);
/* 319:451 */         if (numread <= 0) {
/* 320:    */           break;
/* 321:    */         }
/* 322:453 */         String bstring = new String(buff);
/* 323:454 */         buffer.append(bstring.substring(0, numread));
/* 324:    */       }
/* 325:456 */       return buffer.toString();
/* 326:    */     }
/* 327:    */     catch (Exception e)
/* 328:    */     {
/* 329:459 */       TapjoyLog.d("TapjoyUtil", "file exception: " + e.toString());
/* 330:460 */       e.printStackTrace();
/* 331:    */     }
/* 332:    */     finally
/* 333:    */     {
/* 334:462 */       if (in != null)
/* 335:    */       {
/* 336:    */         try
/* 337:    */         {
/* 338:464 */           in.close();
/* 339:    */         }
/* 340:    */         catch (Exception e) {}
/* 341:468 */         in = null;
/* 342:    */       }
/* 343:    */     }
/* 344:471 */     return null;
/* 345:    */   }
/* 346:    */   
/* 347:    */   public static void setResource(String key, Object value)
/* 348:    */   {
/* 349:476 */     _resources.put(key, value);
/* 350:    */   }
/* 351:    */   
/* 352:    */   public static Object getResource(String key)
/* 353:    */   {
/* 354:484 */     return _resources.get(key);
/* 355:    */   }
/* 356:    */   
/* 357:    */   public static String getRedirectDomain(String hostURL)
/* 358:    */   {
/* 359:492 */     String redirectDomain = "";
/* 360:493 */     if (hostURL != null) {
/* 361:494 */       redirectDomain = hostURL.substring(hostURL.indexOf("//") + "//".length(), hostURL.lastIndexOf("/"));
/* 362:    */     }
/* 363:496 */     return redirectDomain;
/* 364:    */   }
/* 365:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyUtil
 * JD-Core Version:    0.7.0.1
 */