package com.tapjoy;

public abstract interface TapjoySpendPointsNotifier
{
  public abstract void getSpendPointsResponse(String paramString, int paramInt);
  
  public abstract void getSpendPointsResponseFailed(String paramString);
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoySpendPointsNotifier
 * JD-Core Version:    0.7.0.1
 */