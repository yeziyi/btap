package com.tapjoy;

import java.io.Serializable;

public class TJEventData
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  public String name;
  public String value;
  public String guid;
  public int httpStatusCode;
  public String httpResponse;
  public String url;
  public String baseURL;
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TJEventData
 * JD-Core Version:    0.7.0.1
 */