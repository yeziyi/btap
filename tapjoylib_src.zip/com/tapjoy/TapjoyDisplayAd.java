/*   1:    */ package com.tapjoy;
/*   2:    */ 
/*   3:    */ import android.annotation.TargetApi;
/*   4:    */ import android.app.Activity;
/*   5:    */ import android.content.Context;
/*   6:    */ import android.content.Intent;
/*   7:    */ import android.graphics.Bitmap;
/*   8:    */ import android.net.Uri;
/*   9:    */ import android.os.AsyncTask;
/*  10:    */ import android.util.Log;
/*  11:    */ import android.view.View;
/*  12:    */ import android.webkit.ConsoleMessage;
/*  13:    */ import android.webkit.WebSettings;
/*  14:    */ import android.webkit.WebView;
/*  15:    */ import android.widget.LinearLayout.LayoutParams;
/*  16:    */ import com.tapjoy.mraid.listener.MraidViewListener;
/*  17:    */ import com.tapjoy.mraid.view.MraidView;
/*  18:    */ import com.tapjoy.mraid.view.MraidView.PLACEMENT_TYPE;
/*  19:    */ import com.tapjoy.mraid.view.MraidView.VIEW_STATE;
/*  20:    */ import java.util.Locale;
/*  21:    */ import java.util.Map;
/*  22:    */ import java.util.Timer;
/*  23:    */ import java.util.TimerTask;
/*  24:    */ 
/*  25:    */ public class TapjoyDisplayAd
/*  26:    */ {
/*  27:    */   private static TapjoyDisplayAdNotifier displayAdNotifier;
/*  28: 30 */   private static TapjoyURLConnection tapjoyURLConnection = null;
/*  29:    */   private Activity activityContext;
/*  30:    */   private boolean autoRefresh;
/*  31:    */   public static Map<String, String> displayAdURLParams;
/*  32:    */   private static String displayAdSize;
/*  33:    */   private static String htmlData;
/*  34:    */   private static String lastCurrencyID;
/*  35:    */   MraidView webView;
/*  36:    */   View adView;
/*  37:    */   Bitmap lastAd;
/*  38:    */   Timer timer;
/*  39:    */   Timer resumeTimer;
/*  40:    */   long elapsed_time;
/*  41:    */   private static int bannerWidth;
/*  42:    */   private static int bannerHeight;
/*  43:    */   private static final String TAG = "Banner Ad";
/*  44:    */   
/*  45:    */   public TapjoyDisplayAd(Context ctx)
/*  46:    */   {
/*  47: 56 */     setDisplayAdSize("640x100");
/*  48: 57 */     tapjoyURLConnection = new TapjoyURLConnection();
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setDisplayAdSize(String dimensions)
/*  52:    */   {
/*  53: 71 */     displayAdSize = dimensions;
/*  54: 73 */     if (dimensions.equals("320x50"))
/*  55:    */     {
/*  56: 75 */       bannerWidth = 320;
/*  57: 76 */       bannerHeight = 50;
/*  58:    */     }
/*  59: 79 */     else if (dimensions.equals("640x100"))
/*  60:    */     {
/*  61: 81 */       bannerWidth = 640;
/*  62: 82 */       bannerHeight = 100;
/*  63:    */     }
/*  64: 85 */     else if (dimensions.equals("768x90"))
/*  65:    */     {
/*  66: 87 */       bannerWidth = 768;
/*  67: 88 */       bannerHeight = 90;
/*  68:    */     }
/*  69:    */   }
/*  70:    */   
/*  71:    */   public String getDisplayAdSize()
/*  72:    */   {
/*  73: 99 */     return displayAdSize;
/*  74:    */   }
/*  75:    */   
/*  76:    */   /**
/*  77:    */    * @deprecated
/*  78:    */    */
/*  79:    */   public void setBannerAdSize(String dimensions)
/*  80:    */   {
/*  81:115 */     setDisplayAdSize(dimensions);
/*  82:    */   }
/*  83:    */   
/*  84:    */   /**
/*  85:    */    * @deprecated
/*  86:    */    */
/*  87:    */   public String getBannerAdSize()
/*  88:    */   {
/*  89:127 */     return getDisplayAdSize();
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void enableAutoRefresh(boolean shouldAutoRefresh)
/*  93:    */   {
/*  94:137 */     this.autoRefresh = shouldAutoRefresh;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public void getDisplayAd(Activity activity, TapjoyDisplayAdNotifier notifier)
/*  98:    */   {
/*  99:148 */     TapjoyLog.i("Banner Ad", "Get Banner Ad");
/* 100:149 */     getDisplayAd(activity, null, notifier);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public void getDisplayAd(Activity activity, String currencyID, TapjoyDisplayAdNotifier notifier)
/* 104:    */   {
/* 105:161 */     TapjoyLog.i("Banner Ad", "Get Banner Ad, currencyID: " + currencyID);
/* 106:    */     
/* 107:163 */     displayAdNotifier = notifier;
/* 108:165 */     if (activity == null)
/* 109:    */     {
/* 110:167 */       Log.e("Banner Ad", "getDisplayAd must take an Activity context");
/* 111:169 */       if (displayAdNotifier != null) {
/* 112:170 */         displayAdNotifier.getDisplayAdResponseFailed("getDisplayAd must take an Activity context");
/* 113:    */       }
/* 114:172 */       return;
/* 115:    */     }
/* 116:175 */     this.activityContext = activity;
/* 117:    */     
/* 118:    */ 
/* 119:178 */     this.activityContext.runOnUiThread(new Runnable()
/* 120:    */     {
/* 121:    */       public void run()
/* 122:    */       {
/* 123:183 */         TapjoyDisplayAd.this.webView = new MraidView(TapjoyDisplayAd.this.activityContext);
/* 124:    */       }
/* 125:186 */     });
/* 126:187 */     lastCurrencyID = currencyID;
/* 127:    */     
/* 128:    */ 
/* 129:190 */     displayAdURLParams = TapjoyConnectCore.getURLParams();
/* 130:191 */     TapjoyUtil.safePut(displayAdURLParams, "size", displayAdSize, true);
/* 131:192 */     TapjoyUtil.safePut(displayAdURLParams, "currency_id", currencyID, true);
/* 132:    */     
/* 133:    */ 
/* 134:195 */     new GetBannerAdTask(null).execute(new Object[] { TapjoyConnectCore.getHostURL() + "display_ad.html?", displayAdURLParams });
/* 135:    */   }
/* 136:    */   
/* 137:    */   private class RefreshTimer
/* 138:    */     extends TimerTask
/* 139:    */   {
/* 140:    */     private RefreshTimer() {}
/* 141:    */     
/* 142:    */     public void run()
/* 143:    */     {
/* 144:204 */       if (TapjoyDisplayAd.this.webView.getState().equals(MraidView.VIEW_STATE.DEFAULT.toString().toLowerCase(Locale.ENGLISH)))
/* 145:    */       {
/* 146:206 */         TapjoyLog.i("Banner Ad", "refreshing banner ad...");
/* 147:    */         
/* 148:208 */         TapjoyDisplayAd.this.getDisplayAd(TapjoyDisplayAd.this.activityContext, TapjoyDisplayAd.lastCurrencyID, TapjoyDisplayAd.displayAdNotifier);
/* 149:    */         
/* 150:210 */         TapjoyDisplayAd.this.timer.cancel();
/* 151:211 */         TapjoyDisplayAd.this.timer = null;
/* 152:    */       }
/* 153:    */       else
/* 154:    */       {
/* 155:215 */         TapjoyLog.i("Banner Ad", "ad is not in default state.  will try refreshing again in 60000s...");
/* 156:216 */         TapjoyDisplayAd.this.timer.cancel();
/* 157:217 */         TapjoyDisplayAd.this.timer = null;
/* 158:218 */         TapjoyDisplayAd.this.timer = new Timer();
/* 159:219 */         TapjoyDisplayAd.this.timer.schedule(new RefreshTimer(TapjoyDisplayAd.this), 60000L);
/* 160:    */       }
/* 161:    */     }
/* 162:    */   }
/* 163:    */   
/* 164:    */   private class CheckForResumeTimer
/* 165:    */     extends TimerTask
/* 166:    */   {
/* 167:    */     private CheckForResumeTimer() {}
/* 168:    */     
/* 169:    */     public void run()
/* 170:    */     {
/* 171:232 */       TapjoyDisplayAd.this.elapsed_time += 10000L;
/* 172:    */       
/* 173:234 */       TapjoyLog.i("Banner Ad", "banner elapsed_time: " + TapjoyDisplayAd.this.elapsed_time + " (" + TapjoyDisplayAd.this.elapsed_time / 1000L / 60L + "m " + TapjoyDisplayAd.this.elapsed_time / 1000L % 60L + "s)");
/* 174:237 */       if (TapjoyDisplayAd.this.adView == null)
/* 175:    */       {
/* 176:239 */         cancel();
/* 177:    */       }
/* 178:    */       else
/* 179:    */       {
/* 180:244 */         TapjoyLog.i("Banner Ad", "adView.isShown: " + TapjoyDisplayAd.this.adView.isShown());
/* 181:247 */         if (TapjoyDisplayAd.this.adView.isShown()) {
/* 182:249 */           if (TapjoyConnectCore.getInstance() != null)
/* 183:    */           {
/* 184:251 */             TapjoyLog.i("Banner Ad", "call connect");
/* 185:252 */             TapjoyConnectCore.getInstance().callConnect();
/* 186:253 */             cancel();
/* 187:    */           }
/* 188:    */         }
/* 189:258 */         if (TapjoyDisplayAd.this.elapsed_time >= 1200000L) {
/* 190:260 */           cancel();
/* 191:    */         }
/* 192:    */       }
/* 193:    */     }
/* 194:    */   }
/* 195:    */   
/* 196:    */   public static String getHtmlString()
/* 197:    */   {
/* 198:273 */     return htmlData;
/* 199:    */   }
/* 200:    */   
/* 201:    */   private class GetBannerAdTask
/* 202:    */     extends AsyncTask<Object, Void, TapjoyHttpURLResponse>
/* 203:    */   {
/* 204:    */     private GetBannerAdTask() {}
/* 205:    */     
/* 206:    */     protected void onProgressUpdate(Void... progress) {}
/* 207:    */     
/* 208:    */     protected void onPostExecute(TapjoyHttpURLResponse httpResponse)
/* 209:    */     {
/* 210:290 */       if (httpResponse != null) {
/* 211:292 */         switch (httpResponse.statusCode)
/* 212:    */         {
/* 213:    */         case 200: 
/* 214:297 */           TapjoyDisplayAd.access$402(httpResponse.response);
/* 215:299 */           if (TapjoyDisplayAd.htmlData == null)
/* 216:    */           {
/* 217:300 */             TapjoyLog.d("Banner Ad", "unexpected 200 response with no content");
/* 218:301 */             TapjoyDisplayAd.displayAdNotifier.getDisplayAdResponseFailed("No ad to display.");
/* 219:302 */             return;
/* 220:    */           }
/* 221:306 */           WebSettings webSettings = TapjoyDisplayAd.this.webView.getSettings();
/* 222:307 */           webSettings.setJavaScriptEnabled(true);
/* 223:308 */           TapjoyDisplayAd.this.webView.setPlacementType(MraidView.PLACEMENT_TYPE.INLINE);
/* 224:    */           
/* 225:310 */           TapjoyLog.i("Banner Ad", "response: " + httpResponse.response);
/* 226:    */           
/* 227:    */ 
/* 228:313 */           LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(TapjoyDisplayAd.bannerWidth, TapjoyDisplayAd.bannerHeight);
/* 229:314 */           TapjoyDisplayAd.this.webView.setLayoutParams(layout);
/* 230:    */           
/* 231:    */ 
/* 232:317 */           TapjoyDisplayAd.this.webView.setInitialScale(100);
/* 233:    */           
/* 234:    */ 
/* 235:320 */           TapjoyDisplayAd.this.webView.setBackgroundColor(0);
/* 236:321 */           TapjoyDisplayAd.this.webView.loadDataWithBaseURL(null, httpResponse.response, "text/html", "utf-8", null);
/* 237:    */           
/* 238:    */ 
/* 239:324 */           TapjoyLog.i("Banner Ad", "isMraid: " + TapjoyDisplayAd.this.webView.isMraid());
/* 240:327 */           if (!TapjoyDisplayAd.this.webView.isMraid()) {
/* 241:329 */             TapjoyDisplayAd.this.webView.setListener(new MraidViewListener()
/* 242:    */             {
/* 243:    */               public boolean onReady()
/* 244:    */               {
/* 245:332 */                 return false;
/* 246:    */               }
/* 247:    */               
/* 248:    */               public boolean onClose()
/* 249:    */               {
/* 250:335 */                 return false;
/* 251:    */               }
/* 252:    */               
/* 253:    */               public boolean onResize()
/* 254:    */               {
/* 255:338 */                 return false;
/* 256:    */               }
/* 257:    */               
/* 258:    */               public boolean onExpand()
/* 259:    */               {
/* 260:341 */                 return false;
/* 261:    */               }
/* 262:    */               
/* 263:    */               public boolean onExpandClose()
/* 264:    */               {
/* 265:344 */                 return false;
/* 266:    */               }
/* 267:    */               
/* 268:    */               public boolean onResizeClose()
/* 269:    */               {
/* 270:347 */                 return false;
/* 271:    */               }
/* 272:    */               
/* 273:    */               public boolean onEventFired()
/* 274:    */               {
/* 275:350 */                 return false;
/* 276:    */               }
/* 277:    */               
/* 278:    */               public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {}
/* 279:    */               
/* 280:    */               @TargetApi(8)
/* 281:    */               public boolean onConsoleMessage(ConsoleMessage consoleMessage)
/* 282:    */               {
/* 283:357 */                 return false;
/* 284:    */               }
/* 285:    */               
/* 286:    */               public void onPageStarted(WebView view, String url, Bitmap favicon) {}
/* 287:    */               
/* 288:    */               public void onPageFinished(WebView view, String url) {}
/* 289:    */               
/* 290:    */               public boolean shouldOverrideUrlLoading(WebView view, String url)
/* 291:    */               {
/* 292:368 */                 TapjoyLog.i("Banner Ad", "shouldOverrideUrlLoading: " + url);
/* 293:370 */                 if ((url.contains("ws.tapjoyads.com")) || (url.contains("tjyoutubevideo=true")))
/* 294:    */                 {
/* 295:372 */                   TapjoyLog.i("Banner Ad", "Open redirecting URL = [" + url + "]");
/* 296:373 */                   ((MraidView)view).loadUrlStandard(url);
/* 297:    */                 }
/* 298:    */                 else
/* 299:    */                 {
/* 300:377 */                   Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
/* 301:378 */                   TapjoyDisplayAd.this.activityContext.startActivity(intent);
/* 302:    */                 }
/* 303:384 */                 if (TapjoyDisplayAd.this.resumeTimer != null) {
/* 304:386 */                   TapjoyDisplayAd.this.resumeTimer.cancel();
/* 305:    */                 }
/* 306:389 */                 TapjoyDisplayAd.this.elapsed_time = 0L;
/* 307:390 */                 TapjoyDisplayAd.this.resumeTimer = new Timer();
/* 308:391 */                 TapjoyDisplayAd.this.resumeTimer.schedule(new TapjoyDisplayAd.CheckForResumeTimer(TapjoyDisplayAd.this, null), 10000L, 10000L);
/* 309:392 */                 return true;
/* 310:    */               }
/* 311:    */             });
/* 312:    */           }
/* 313:398 */           if (TapjoyDisplayAd.this.adView != null) {
/* 314:399 */             TapjoyDisplayAd.this.lastAd = TapjoyUtil.createBitmapFromView(TapjoyDisplayAd.this.adView);
/* 315:    */           }
/* 316:401 */           TapjoyDisplayAd.this.adView = TapjoyDisplayAd.this.webView;
/* 317:    */           
/* 318:    */ 
/* 319:    */ 
/* 320:    */ 
/* 321:    */ 
/* 322:    */ 
/* 323:    */ 
/* 324:409 */           TapjoyDisplayAd.displayAdNotifier.getDisplayAdResponse(TapjoyDisplayAd.this.adView);
/* 325:412 */           if (TapjoyDisplayAd.this.timer != null)
/* 326:    */           {
/* 327:414 */             TapjoyDisplayAd.this.timer.cancel();
/* 328:415 */             TapjoyDisplayAd.this.timer = null;
/* 329:    */           }
/* 330:419 */           if ((TapjoyDisplayAd.this.autoRefresh) && (TapjoyDisplayAd.this.timer == null))
/* 331:    */           {
/* 332:421 */             TapjoyLog.i("Banner Ad", "will refresh banner ad in 60000ms...");
/* 333:422 */             TapjoyDisplayAd.this.timer = new Timer();
/* 334:423 */             TapjoyDisplayAd.this.timer.schedule(new TapjoyDisplayAd.RefreshTimer(TapjoyDisplayAd.this, null), 60000L);
/* 335:    */           }
/* 336:    */           break;
/* 337:    */         default: 
/* 338:430 */           TapjoyDisplayAd.displayAdNotifier.getDisplayAdResponseFailed("No ad to display.");
/* 339:    */         }
/* 340:    */       }
/* 341:    */     }
/* 342:    */     
/* 343:    */     protected TapjoyHttpURLResponse doInBackground(Object... params)
/* 344:    */     {
/* 345:440 */       String url = (String)params[0];
/* 346:441 */       Map<String, String> urlParams = (Map)params[1];
/* 347:442 */       TapjoyHttpURLResponse httpResponse = TapjoyDisplayAd.tapjoyURLConnection.getResponseFromURL(url, urlParams);
/* 348:443 */       return httpResponse;
/* 349:    */     }
/* 350:    */   }
/* 351:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyDisplayAd
 * JD-Core Version:    0.7.0.1
 */