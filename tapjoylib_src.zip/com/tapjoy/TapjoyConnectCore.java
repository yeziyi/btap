/*    1:     */ package com.tapjoy;
/*    2:     */ 
/*    3:     */ import android.content.Context;
/*    4:     */ import android.content.Intent;
/*    5:     */ import android.content.SharedPreferences;
/*    6:     */ import android.content.SharedPreferences.Editor;
/*    7:     */ import android.content.pm.ActivityInfo;
/*    8:     */ import android.content.pm.ApplicationInfo;
/*    9:     */ import android.content.pm.FeatureInfo;
/*   10:     */ import android.content.pm.PackageInfo;
/*   11:     */ import android.content.pm.PackageManager;
/*   12:     */ import android.content.pm.PackageManager.NameNotFoundException;
/*   13:     */ import android.content.pm.ResolveInfo;
/*   14:     */ import android.content.res.Resources;
/*   15:     */ import android.net.ConnectivityManager;
/*   16:     */ import android.net.NetworkInfo;
/*   17:     */ import android.net.Uri;
/*   18:     */ import android.net.wifi.WifiInfo;
/*   19:     */ import android.net.wifi.WifiManager;
/*   20:     */ import android.os.Build;
/*   21:     */ import android.os.Build.VERSION;
/*   22:     */ import android.os.Bundle;
/*   23:     */ import android.provider.Settings.Secure;
/*   24:     */ import android.telephony.TelephonyManager;
/*   25:     */ import android.util.Log;
/*   26:     */ import java.lang.reflect.Field;
/*   27:     */ import java.util.ArrayList;
/*   28:     */ import java.util.Arrays;
/*   29:     */ import java.util.Enumeration;
/*   30:     */ import java.util.HashMap;
/*   31:     */ import java.util.Hashtable;
/*   32:     */ import java.util.Iterator;
/*   33:     */ import java.util.List;
/*   34:     */ import java.util.Locale;
/*   35:     */ import java.util.Map;
/*   36:     */ import java.util.Map.Entry;
/*   37:     */ import java.util.Properties;
/*   38:     */ import java.util.Set;
/*   39:     */ import java.util.Timer;
/*   40:     */ import java.util.TimerTask;
/*   41:     */ import java.util.Vector;
/*   42:     */ import org.w3c.dom.Document;
/*   43:     */ 
/*   44:     */ public class TapjoyConnectCore
/*   45:     */ {
/*   46:  47 */   private static Context context = null;
/*   47:  49 */   private static TapjoyConnectCore tapjoyConnectCore = null;
/*   48:  50 */   private static TapjoyURLConnection tapjoyURLConnection = null;
/*   49:  51 */   private static TapjoyConnectNotifier connectNotifier = null;
/*   50:  52 */   private static TapjoyViewNotifier viewNotifier = null;
/*   51:  55 */   private static Vector<String> dependencyClassesRequired = new Vector(Arrays.asList(TapjoyConstants.dependencyClassNames));
/*   52:  58 */   private static String androidID = "";
/*   53:  59 */   private static String sessionID = "";
/*   54:  60 */   private static String deviceID = "";
/*   55:  61 */   private static String sha2DeviceID = "";
/*   56:  62 */   private static String macAddress = "";
/*   57:  63 */   private static String deviceModel = "";
/*   58:  64 */   private static String deviceManufacturer = "";
/*   59:  65 */   private static String deviceType = "";
/*   60:  66 */   private static String deviceOSVersion = "";
/*   61:  67 */   private static String deviceCountryCode = "";
/*   62:  68 */   private static String deviceLanguage = "";
/*   63:  69 */   private static String appID = "";
/*   64:  70 */   private static String appVersion = "";
/*   65:  71 */   private static String libraryVersion = "";
/*   66:  72 */   private static String bridgeVersion = "";
/*   67:  73 */   private static int deviceScreenDensity = 1;
/*   68:  74 */   private static float deviceScreenDensityScale = 1.0F;
/*   69:  75 */   private static int deviceScreenLayoutSize = 1;
/*   70:  76 */   private static String userID = "";
/*   71:  77 */   private static boolean deviceLocation = false;
/*   72:  79 */   private static String platformName = "";
/*   73:  80 */   private static String carrierName = "";
/*   74:  81 */   private static String carrierCountryCode = "";
/*   75:  82 */   private static String mobileCountryCode = "";
/*   76:  83 */   private static String mobileNetworkCode = "";
/*   77:  84 */   private static String connectionType = "";
/*   78:  85 */   private static String connectionSubType = "";
/*   79:  86 */   private static String storeName = "";
/*   80:  88 */   private static String secretKey = "";
/*   81:  90 */   private static String plugin = "native";
/*   82:  91 */   private static String sdkType = "";
/*   83:  93 */   private static String redirectDomain = "";
/*   84:  95 */   private static boolean videoEnabled = false;
/*   85:  96 */   private static String videoIDs = "";
/*   86:  97 */   private static float currencyMultiplier = 1.0F;
/*   87:  99 */   private static boolean shareFacebook = false;
/*   88: 100 */   private static boolean shareTwitter = false;
/*   89: 102 */   private static boolean shareGooglePlus = false;
/*   90: 103 */   private static boolean shareLinkedIn = false;
/*   91: 105 */   private static boolean storeView = false;
/*   92:     */   private static final String TAG = "TapjoyConnect";
/*   93: 110 */   private static String paidAppActionID = null;
/*   94: 111 */   private long elapsed_time = 0L;
/*   95: 112 */   private Timer timer = null;
/*   96: 114 */   private boolean appPaused = false;
/*   97: 115 */   private static long lastTimeStamp = 0L;
/*   98: 116 */   private boolean initialized = false;
/*   99:     */   private static PackageManager packageManager;
/*  100: 120 */   private static Hashtable<String, String> connectFlags = null;
/*  101: 121 */   private static String matchingPackageNames = "";
/*  102:     */   
/*  103:     */   public static TapjoyConnectCore getInstance()
/*  104:     */   {
/*  105: 130 */     return tapjoyConnectCore;
/*  106:     */   }
/*  107:     */   
/*  108:     */   public static void requestTapjoyConnect(Context applicationContext, String app_ID, String secret_Key)
/*  109:     */     throws TapjoyException
/*  110:     */   {
/*  111: 142 */     requestTapjoyConnect(applicationContext, app_ID, secret_Key, null);
/*  112:     */   }
/*  113:     */   
/*  114:     */   public static void requestTapjoyConnect(Context applicationContext, String app_ID, String secret_Key, Hashtable<String, String> flags)
/*  115:     */     throws TapjoyException
/*  116:     */   {
/*  117: 155 */     requestTapjoyConnect(applicationContext, app_ID, secret_Key, flags, null);
/*  118:     */   }
/*  119:     */   
/*  120:     */   public static void requestTapjoyConnect(Context applicationContext, String app_ID, String secret_Key, Hashtable<String, String> flags, TapjoyConnectNotifier notifier)
/*  121:     */     throws TapjoyException
/*  122:     */   {
/*  123: 169 */     appID = app_ID;
/*  124: 170 */     secretKey = secret_Key;
/*  125: 171 */     connectFlags = flags;
/*  126: 172 */     connectNotifier = notifier;
/*  127: 173 */     tapjoyConnectCore = new TapjoyConnectCore(applicationContext);
/*  128:     */   }
/*  129:     */   
/*  130:     */   public TapjoyConnectCore(Context applicationContext)
/*  131:     */     throws TapjoyException
/*  132:     */   {
/*  133: 183 */     context = applicationContext;
/*  134: 184 */     tapjoyURLConnection = new TapjoyURLConnection();
/*  135: 186 */     if (init())
/*  136:     */     {
/*  137: 189 */       TapjoyLog.i("TapjoyConnect", "URL parameters: " + getURLParams());
/*  138:     */       
/*  139: 191 */       callConnect();
/*  140:     */       
/*  141:     */ 
/*  142: 194 */       sendOfflineLogs();
/*  143: 197 */       if ((getConnectFlagValue("user_id") != null) && (getConnectFlagValue("user_id").length() > 0))
/*  144:     */       {
/*  145: 199 */         TapjoyLog.i("TapjoyConnect", "Setting userID to: " + getConnectFlagValue("user_id"));
/*  146: 200 */         setUserID(getConnectFlagValue("user_id"));
/*  147:     */       }
/*  148: 203 */       this.initialized = true;
/*  149:     */     }
/*  150:     */   }
/*  151:     */   
/*  152:     */   public void callConnect()
/*  153:     */   {
/*  154: 213 */     new Thread(new ConnectThread()).start();
/*  155:     */   }
/*  156:     */   
/*  157:     */   public void appPause()
/*  158:     */   {
/*  159: 221 */     this.appPaused = true;
/*  160:     */   }
/*  161:     */   
/*  162:     */   public void appResume()
/*  163:     */   {
/*  164: 230 */     if (this.appPaused)
/*  165:     */     {
/*  166: 232 */       generateSessionID();
/*  167: 233 */       this.appPaused = false;
/*  168:     */     }
/*  169:     */   }
/*  170:     */   
/*  171:     */   public static Map<String, String> getURLParams()
/*  172:     */   {
/*  173: 243 */     Map<String, String> params = getGenericURLParams();
/*  174: 244 */     params.putAll(getTimeStampAndVerifierParams());
/*  175: 245 */     return params;
/*  176:     */   }
/*  177:     */   
/*  178:     */   public static Map<String, String> getGenericURLParams()
/*  179:     */   {
/*  180: 257 */     Map<String, String> params = getParamsWithoutAppID();
/*  181: 258 */     TapjoyUtil.safePut(params, "app_id", appID, true);
/*  182: 259 */     return params;
/*  183:     */   }
/*  184:     */   
/*  185:     */   private static Map<String, String> getParamsWithoutAppID()
/*  186:     */   {
/*  187: 270 */     Map<String, String> params = new HashMap();
/*  188: 274 */     if ((getConnectFlagValue("sha_2_udid") != null) && (getConnectFlagValue("sha_2_udid").equals("true"))) {
/*  189: 276 */       TapjoyUtil.safePut(params, "sha2_udid", sha2DeviceID, true);
/*  190:     */     } else {
/*  191: 280 */       TapjoyUtil.safePut(params, "udid", deviceID, true);
/*  192:     */     }
/*  193: 283 */     TapjoyUtil.safePut(params, "publisher_user_id", userID, true);
/*  194: 284 */     TapjoyUtil.safePut(params, "android_id", androidID, true);
/*  195: 285 */     TapjoyUtil.safePut(params, "mac_address", macAddress, true);
/*  196: 286 */     TapjoyUtil.safePut(params, "device_name", deviceModel, true);
/*  197: 287 */     TapjoyUtil.safePut(params, "device_type", deviceType, true);
/*  198: 288 */     TapjoyUtil.safePut(params, "os_version", deviceOSVersion, true);
/*  199: 289 */     TapjoyUtil.safePut(params, "country_code", deviceCountryCode, true);
/*  200: 290 */     TapjoyUtil.safePut(params, "language_code", deviceLanguage, true);
/*  201: 291 */     TapjoyUtil.safePut(params, "app_version", appVersion, true);
/*  202: 292 */     TapjoyUtil.safePut(params, "library_version", libraryVersion, true);
/*  203: 293 */     TapjoyUtil.safePut(params, "bridge_version", bridgeVersion, true);
/*  204: 294 */     TapjoyUtil.safePut(params, "platform", platformName, true);
/*  205: 295 */     TapjoyUtil.safePut(params, "display_multiplier", Float.toString(currencyMultiplier), true);
/*  206: 296 */     TapjoyUtil.safePut(params, "carrier_name", carrierName, true);
/*  207: 297 */     TapjoyUtil.safePut(params, "carrier_country_code", carrierCountryCode, true);
/*  208: 298 */     TapjoyUtil.safePut(params, "mobile_country_code", mobileCountryCode, true);
/*  209: 299 */     TapjoyUtil.safePut(params, "mobile_network_code", mobileNetworkCode, true);
/*  210: 300 */     TapjoyUtil.safePut(params, "device_manufacturer", deviceManufacturer, true);
/*  211: 301 */     TapjoyUtil.safePut(params, "screen_density", "" + deviceScreenDensity, true);
/*  212: 302 */     TapjoyUtil.safePut(params, "screen_layout_size", "" + deviceScreenLayoutSize, true);
/*  213:     */     
/*  214:     */ 
/*  215: 305 */     connectionType = getConnectionType();
/*  216: 306 */     TapjoyUtil.safePut(params, "connection_type", connectionType, true);
/*  217:     */     
/*  218:     */ 
/*  219: 309 */     connectionSubType = getConnectionSubType();
/*  220: 310 */     TapjoyUtil.safePut(params, "connection_subtype", connectionSubType, true);
/*  221:     */     
/*  222: 312 */     TapjoyUtil.safePut(params, "plugin", plugin, true);
/*  223: 313 */     TapjoyUtil.safePut(params, "sdk_type", sdkType, true);
/*  224: 314 */     TapjoyUtil.safePut(params, "store_name", storeName, true);
/*  225:     */     
/*  226:     */ 
/*  227: 317 */     TapjoyUtil.safePut(params, "device_location", String.valueOf(deviceLocation), true);
/*  228:     */     
/*  229:     */ 
/*  230:     */ 
/*  231:     */ 
/*  232:     */ 
/*  233:     */ 
/*  234:     */ 
/*  235: 325 */     TapjoyUtil.safePut(params, "store_view", String.valueOf(storeView), true);
/*  236: 329 */     if ((sessionID == null) || (sessionID.length() == 0) || (System.currentTimeMillis() - lastTimeStamp > 1800000L)) {
/*  237: 331 */       sessionID = generateSessionID();
/*  238:     */     } else {
/*  239: 336 */       lastTimeStamp = System.currentTimeMillis();
/*  240:     */     }
/*  241: 339 */     TapjoyUtil.safePut(params, "session_id", sessionID, true);
/*  242:     */     
/*  243: 341 */     return params;
/*  244:     */   }
/*  245:     */   
/*  246:     */   private boolean init()
/*  247:     */     throws TapjoyException
/*  248:     */   {
/*  249: 351 */     packageManager = context.getPackageManager();
/*  250:     */     
/*  251:     */ 
/*  252: 354 */     loadConfigurations();
/*  253: 357 */     if (getConnectFlagValue("skip_integrations") == "") {
/*  254: 358 */       integrationCheck();
/*  255:     */     }
/*  256: 361 */     obtainDeviceInformation();
/*  257: 364 */     if (getConnectFlagValue("TJC_SERVICE_URL") == "") {
/*  258: 365 */       setHostURL("https://ws.tapjoyads.com/");
/*  259:     */     }
/*  260: 368 */     if ((getConnectFlagValue("debug_host_url") != null) && (getConnectFlagValue("debug_host_url").length() > 0)) {
/*  261: 369 */       setHostURL(getConnectFlagValue("debug_host_url"));
/*  262:     */     }
/*  263: 371 */     String hostURL = getConnectFlagValue("TJC_SERVICE_URL");
/*  264: 372 */     redirectDomain = TapjoyUtil.getRedirectDomain(hostURL);
/*  265:     */     
/*  266: 374 */     TapjoyLog.i("TapjoyConnect", "deviceID: " + deviceID + ((getConnectFlagValue("debug_device_id") != null) && (getConnectFlagValue("debug_device_id").length() > 0) ? " *debug_device_id*" : ""));
/*  267: 375 */     TapjoyLog.i("TapjoyConnect", "sha2_udid: " + sha2DeviceID);
/*  268:     */     
/*  269:     */ 
/*  270: 378 */     Map<String, String> params = getGenericURLParams();
/*  271: 379 */     for (Map.Entry<String, String> entry : params.entrySet()) {
/*  272: 381 */       TapjoyLog.i("TapjoyConnect", (String)entry.getKey() + ": " + (String)entry.getValue());
/*  273:     */     }
/*  274: 384 */     if (connectFlags != null) {
/*  275: 386 */       logConnectFlags();
/*  276:     */     }
/*  277: 389 */     return true;
/*  278:     */   }
/*  279:     */   
/*  280:     */   private void logConnectFlags()
/*  281:     */   {
/*  282: 397 */     TapjoyLog.i("TapjoyConnect", "Connect Flags:");
/*  283: 398 */     TapjoyLog.i("TapjoyConnect", "--------------------");
/*  284:     */     
/*  285: 400 */     Set<Map.Entry<String, String>> entries = connectFlags.entrySet();
/*  286: 401 */     Iterator<Map.Entry<String, String>> iterator = entries.iterator();
/*  287: 403 */     while (iterator.hasNext())
/*  288:     */     {
/*  289: 405 */       Map.Entry<String, String> item = (Map.Entry)iterator.next();
/*  290: 406 */       TapjoyLog.i("TapjoyConnect", "key: " + (String)item.getKey() + ", value: " + Uri.encode((String)item.getValue()));
/*  291: 409 */       if ((((String)item.getKey()).equals("sha_2_udid")) && (!sdkType.equals("connect")))
/*  292:     */       {
/*  293: 411 */         TapjoyLog.w("TapjoyConnect", "WARNING -- only the Connect/Advertiser SDK can support sha_2_udid");
/*  294: 412 */         connectFlags.remove("sha_2_udid");
/*  295:     */       }
/*  296:     */     }
/*  297: 416 */     TapjoyLog.i("TapjoyConnect", "hostURL: [" + getConnectFlagValue("TJC_SERVICE_URL") + "]");
/*  298: 417 */     TapjoyLog.i("TapjoyConnect", "redirectDomain: [" + redirectDomain + "]");
/*  299:     */     
/*  300: 419 */     TapjoyLog.i("TapjoyConnect", "--------------------");
/*  301:     */   }
/*  302:     */   
/*  303:     */   private void obtainDeviceInformation()
/*  304:     */     throws TapjoyException
/*  305:     */   {
/*  306: 429 */     androidID = Settings.Secure.getString(context.getContentResolver(), "android_id");
/*  307: 432 */     if (androidID != null) {
/*  308: 433 */       androidID = androidID.toLowerCase();
/*  309:     */     }
/*  310:     */     try
/*  311:     */     {
/*  312: 438 */       appVersion = packageManager.getPackageInfo(context.getPackageName(), 0).versionName;
/*  313:     */     }
/*  314:     */     catch (PackageManager.NameNotFoundException e)
/*  315:     */     {
/*  316: 441 */       throw new TapjoyException(e.getMessage());
/*  317:     */     }
/*  318: 445 */     deviceType = "android";
/*  319: 446 */     platformName = "android";
/*  320:     */     
/*  321:     */ 
/*  322: 449 */     deviceModel = Build.MODEL;
/*  323: 450 */     deviceManufacturer = Build.MANUFACTURER;
/*  324:     */     
/*  325:     */ 
/*  326: 453 */     deviceOSVersion = Build.VERSION.RELEASE;
/*  327:     */     
/*  328:     */ 
/*  329: 456 */     deviceCountryCode = Locale.getDefault().getCountry();
/*  330: 457 */     deviceLanguage = Locale.getDefault().getLanguage();
/*  331:     */     
/*  332:     */ 
/*  333: 460 */     libraryVersion = "9.1.3";
/*  334: 461 */     bridgeVersion = "1.0.4";
/*  335:     */     
/*  336: 463 */     obtainScreenInformation();
/*  337: 464 */     obtainMacAddress();
/*  338: 465 */     obtainCarrierInformation();
/*  339: 466 */     determineUserID();
/*  340: 467 */     setDeviceCapabilityFlags();
/*  341:     */   }
/*  342:     */   
/*  343:     */   private void obtainScreenInformation()
/*  344:     */   {
/*  345:     */     try
/*  346:     */     {
/*  347: 481 */       if (Build.VERSION.SDK_INT > 3)
/*  348:     */       {
/*  349: 483 */         TapjoyDisplayMetricsUtil displayMetricsUtil = new TapjoyDisplayMetricsUtil(context);
/*  350:     */         
/*  351: 485 */         deviceScreenDensity = displayMetricsUtil.getScreenDensityDPI();
/*  352: 486 */         deviceScreenDensityScale = displayMetricsUtil.getScreenDensityScale();
/*  353: 487 */         deviceScreenLayoutSize = displayMetricsUtil.getScreenLayoutSize();
/*  354:     */       }
/*  355:     */     }
/*  356:     */     catch (Exception e)
/*  357:     */     {
/*  358: 492 */       TapjoyLog.e("TapjoyConnect", "Error getting screen density/dimensions/layout: " + e.toString());
/*  359:     */     }
/*  360:     */   }
/*  361:     */   
/*  362:     */   private void obtainMacAddress()
/*  363:     */   {
/*  364: 502 */     if (isPermissionGranted("android.permission.ACCESS_WIFI_STATE")) {
/*  365:     */       try
/*  366:     */       {
/*  367: 506 */         WifiManager wifiManager = (WifiManager)context.getSystemService("wifi");
/*  368: 508 */         if (wifiManager != null)
/*  369:     */         {
/*  370: 510 */           WifiInfo wifiInfo = wifiManager.getConnectionInfo();
/*  371: 512 */           if (wifiInfo != null)
/*  372:     */           {
/*  373: 514 */             macAddress = wifiInfo.getMacAddress();
/*  374: 516 */             if (macAddress != null) {
/*  375: 519 */               macAddress = macAddress.replace(":", "").toLowerCase();
/*  376:     */             }
/*  377:     */           }
/*  378:     */         }
/*  379:     */       }
/*  380:     */       catch (Exception e)
/*  381:     */       {
/*  382: 526 */         TapjoyLog.e("TapjoyConnect", "Error getting device mac address: " + e.toString());
/*  383:     */       }
/*  384:     */     } else {
/*  385: 531 */       TapjoyLog.i("TapjoyConnect", "*** ignore macAddress");
/*  386:     */     }
/*  387:     */   }
/*  388:     */   
/*  389:     */   private void obtainCarrierInformation()
/*  390:     */   {
/*  391: 540 */     TelephonyManager telephonyManager = (TelephonyManager)context.getSystemService("phone");
/*  392: 541 */     if (telephonyManager != null)
/*  393:     */     {
/*  394: 543 */       carrierName = telephonyManager.getNetworkOperatorName();
/*  395: 544 */       carrierCountryCode = telephonyManager.getNetworkCountryIso();
/*  396: 549 */       if ((telephonyManager.getNetworkOperator() != null) && ((telephonyManager.getNetworkOperator().length() == 5) || (telephonyManager.getNetworkOperator().length() == 6)))
/*  397:     */       {
/*  398: 551 */         mobileCountryCode = telephonyManager.getNetworkOperator().substring(0, 3);
/*  399: 552 */         mobileNetworkCode = telephonyManager.getNetworkOperator().substring(3);
/*  400:     */       }
/*  401: 556 */       if (isPermissionGranted("android.permission.READ_PHONE_STATE")) {
/*  402:     */         try
/*  403:     */         {
/*  404: 561 */           if ((getConnectFlagValue("debug_device_id") != null) && (getConnectFlagValue("debug_device_id").length() > 0)) {
/*  405: 562 */             deviceID = getConnectFlagValue("debug_device_id");
/*  406:     */           } else {
/*  407: 564 */             deviceID = telephonyManager.getDeviceId();
/*  408:     */           }
/*  409: 566 */           TapjoyLog.i("TapjoyConnect", "deviceID: " + deviceID);
/*  410:     */           
/*  411: 568 */           boolean validDeviceID = false;
/*  412: 571 */           if (deviceID == null)
/*  413:     */           {
/*  414: 573 */             TapjoyLog.e("TapjoyConnect", "Device id is null.");
/*  415:     */           }
/*  416: 577 */           else if ((deviceID.length() == 0) || (deviceID.equals("000000000000000")) || (deviceID.equals("0")))
/*  417:     */           {
/*  418: 579 */             TapjoyLog.e("TapjoyConnect", "Device id is empty or an emulator.");
/*  419:     */           }
/*  420:     */           else
/*  421:     */           {
/*  422: 585 */             deviceID = deviceID.toLowerCase(Locale.getDefault());
/*  423: 586 */             validDeviceID = true;
/*  424:     */           }
/*  425: 589 */           TapjoyLog.i("TapjoyConnect", "ANDROID SDK VERSION: " + Build.VERSION.SDK_INT);
/*  426: 593 */           if (Build.VERSION.SDK_INT >= 9)
/*  427:     */           {
/*  428: 595 */             TapjoyLog.i("TapjoyConnect", "TRYING TO GET SERIAL OF 2.3+ DEVICE...");
/*  429:     */             
/*  430: 597 */             String serialID = getSerial();
/*  431: 600 */             if (!validDeviceID) {
/*  432: 602 */               deviceID = serialID;
/*  433:     */             }
/*  434: 606 */             if (deviceID == null)
/*  435:     */             {
/*  436: 608 */               TapjoyLog.e("TapjoyConnect", "SERIAL: Device id is null.");
/*  437:     */             }
/*  438: 612 */             else if ((deviceID.length() == 0) || (deviceID.equals("000000000000000")) || (deviceID.equals("0")) || (deviceID.equals("unknown")))
/*  439:     */             {
/*  440: 614 */               TapjoyLog.e("TapjoyConnect", "SERIAL: Device id is empty or an emulator.");
/*  441:     */             }
/*  442:     */             else
/*  443:     */             {
/*  444: 620 */               deviceID = deviceID.toLowerCase(Locale.getDefault());
/*  445: 621 */               validDeviceID = true;
/*  446:     */             }
/*  447:     */           }
/*  448: 625 */           if (validDeviceID) {
/*  449: 628 */             sha2DeviceID = TapjoyUtil.SHA256(deviceID);
/*  450:     */           }
/*  451:     */         }
/*  452:     */         catch (Exception e)
/*  453:     */         {
/*  454: 633 */           TapjoyLog.e("TapjoyConnect", "Cannot get deviceID. e: " + e.toString());
/*  455: 634 */           deviceID = null;
/*  456:     */         }
/*  457:     */       } else {
/*  458: 639 */         TapjoyLog.i("TapjoyConnect", "*** ignore deviceID");
/*  459:     */       }
/*  460:     */     }
/*  461:     */   }
/*  462:     */   
/*  463:     */   private void determineUserID()
/*  464:     */     throws TapjoyException
/*  465:     */   {
/*  466: 650 */     if ((deviceID != null) && (deviceID.length() > 0)) {
/*  467: 652 */       userID = deviceID;
/*  468: 655 */     } else if ((macAddress != null) && (macAddress.length() > 0)) {
/*  469: 657 */       userID = macAddress;
/*  470: 660 */     } else if ((androidID != null) && (androidID.length() > 0)) {
/*  471: 662 */       userID = androidID;
/*  472:     */     } else {
/*  473: 667 */       throw new TapjoyException("ERROR -- No valid device identifier");
/*  474:     */     }
/*  475:     */   }
/*  476:     */   
/*  477:     */   private void setDeviceCapabilityFlags()
/*  478:     */   {
/*  479:     */     try
/*  480:     */     {
/*  481: 679 */       deviceLocation = detectCapability("android.hardware.location", "android.permission.ACCESS_FINE_LOCATION");
/*  482:     */     }
/*  483:     */     catch (Exception e)
/*  484:     */     {
/*  485: 683 */       TapjoyLog.e("TapjoyConnect", "Error trying to detect capabilities on devicee: " + e.toString());
/*  486:     */     }
/*  487:     */     try
/*  488:     */     {
/*  489: 689 */       shareFacebook = detectSharingApplication("com.facebook.");
/*  490: 690 */       shareTwitter = detectSharingApplication("com.twitter.");
/*  491: 691 */       shareGooglePlus = detectSharingApplication("com.google.android.apps.plus");
/*  492: 692 */       shareLinkedIn = detectSharingApplication("com.linkedin.");
/*  493:     */     }
/*  494:     */     catch (Exception e)
/*  495:     */     {
/*  496: 696 */       TapjoyLog.e("TapjoyConnect", "Error trying to detect sharing applications installed on devicee: " + e.toString());
/*  497:     */     }
/*  498: 700 */     if ((getConnectFlagValue("store_name") != null) && (getConnectFlagValue("store_name").length() > 0))
/*  499:     */     {
/*  500: 702 */       storeName = getConnectFlagValue("store_name");
/*  501:     */       
/*  502:     */ 
/*  503: 705 */       ArrayList<String> supportedStores = new ArrayList(Arrays.asList(TapjoyConnectFlag.STORE_ARRAY));
/*  504: 708 */       if (!supportedStores.contains(storeName)) {
/*  505: 710 */         TapjoyLog.w("TapjoyConnect", "Warning -- undefined STORE_NAME: " + storeName);
/*  506:     */       }
/*  507:     */     }
/*  508:     */     try
/*  509:     */     {
/*  510: 717 */       storeView = detectStore(storeName);
/*  511:     */     }
/*  512:     */     catch (Exception e)
/*  513:     */     {
/*  514: 721 */       TapjoyLog.e("TapjoyConnect", "Error trying to detect store intent on devicee: " + e.toString());
/*  515:     */     }
/*  516:     */   }
/*  517:     */   
/*  518:     */   private void loadConfigurations()
/*  519:     */   {
/*  520: 733 */     if (connectFlags == null) {
/*  521: 734 */       connectFlags = new Hashtable();
/*  522:     */     }
/*  523: 737 */     if ((getConnectFlagValue("enable_logging") != null) && (getConnectFlagValue("enable_logging").equals("true"))) {
/*  524: 738 */       TapjoyLog.enableLogging(true);
/*  525:     */     }
/*  526: 741 */     checkManifestForConfigurations();
/*  527:     */     
/*  528:     */ 
/*  529: 744 */     checkResourceFileForConfigurations();
/*  530:     */   }
/*  531:     */   
/*  532:     */   private void checkManifestForConfigurations()
/*  533:     */   {
/*  534:     */     try
/*  535:     */     {
/*  536: 754 */       if (packageManager != null)
/*  537:     */       {
/*  538: 756 */         ApplicationInfo appInfo = packageManager.getApplicationInfo(context.getPackageName(), 128);
/*  539: 759 */         if ((appInfo != null) && (appInfo.metaData != null))
/*  540:     */         {
/*  541: 761 */           for (String key : TapjoyConnectFlag.FLAG_ARRAY)
/*  542:     */           {
/*  543: 763 */             String value = appInfo.metaData.getString("tapjoy." + key);
/*  544: 764 */             if (value != null)
/*  545:     */             {
/*  546: 766 */               TapjoyLog.i("TapjoyConnect", "Found manifest flag: " + key + ", " + value);
/*  547: 767 */               connectFlags.put(key, value);
/*  548:     */             }
/*  549:     */           }
/*  550: 770 */           TapjoyLog.i("TapjoyConnect", "Metadata successfully loaded");
/*  551:     */         }
/*  552:     */         else
/*  553:     */         {
/*  554: 774 */           TapjoyLog.i("TapjoyConnect", "No metadata present.");
/*  555:     */         }
/*  556:     */       }
/*  557:     */     }
/*  558:     */     catch (Exception e)
/*  559:     */     {
/*  560: 780 */       TapjoyLog.e("TapjoyConnect", "Error reading manifest meta-data: " + e.toString());
/*  561:     */     }
/*  562:     */   }
/*  563:     */   
/*  564:     */   private void checkResourceFileForConfigurations()
/*  565:     */   {
/*  566: 789 */     Resources resources = context.getResources();
/*  567:     */     
/*  568:     */ 
/*  569:     */ 
/*  570:     */ 
/*  571: 794 */     int resId = resources.getIdentifier("raw/tapjoy_config", null, context.getPackageName());
/*  572: 795 */     Properties properties = new Properties();
/*  573:     */     try
/*  574:     */     {
/*  575: 798 */       properties.load(context.getResources().openRawResource(resId));
/*  576: 799 */       parsePropertiesIntoConfigFlags(properties);
/*  577:     */     }
/*  578:     */     catch (Exception e)
/*  579:     */     {
/*  580: 802 */       TapjoyLog.i("TapjoyConnect", "No raw/tapjoy_config file present.");
/*  581:     */     }
/*  582:     */   }
/*  583:     */   
/*  584:     */   private void parsePropertiesIntoConfigFlags(Properties properties)
/*  585:     */   {
/*  586: 811 */     Enumeration<Object> keys = properties.keys();
/*  587: 813 */     while (keys.hasMoreElements()) {
/*  588:     */       try
/*  589:     */       {
/*  590: 817 */         String key = (String)keys.nextElement();
/*  591: 818 */         String value = (String)properties.get(key);
/*  592: 819 */         connectFlags.put(key, value);
/*  593:     */       }
/*  594:     */       catch (ClassCastException e)
/*  595:     */       {
/*  596: 822 */         TapjoyLog.e("TapjoyConnect", "Error parsing configuration properties in tapjoy_config.txt");
/*  597:     */       }
/*  598:     */     }
/*  599:     */   }
/*  600:     */   
/*  601:     */   private void integrationCheck()
/*  602:     */     throws TapjoyIntegrationException
/*  603:     */   {
/*  604:     */     try
/*  605:     */     {
/*  606: 835 */       PackageInfo packageActivityInfo = packageManager.getPackageInfo(context.getPackageName(), 1);
/*  607:     */       
/*  608: 837 */       List<ActivityInfo> activityInfoList = Arrays.asList(packageActivityInfo.activities);
/*  609: 838 */       if (activityInfoList != null) {
/*  610: 840 */         for (ActivityInfo activityInfo : activityInfoList) {
/*  611: 841 */           checkForDependency(activityInfo);
/*  612:     */         }
/*  613:     */       }
/*  614:     */     }
/*  615:     */     catch (PackageManager.NameNotFoundException e1)
/*  616:     */     {
/*  617: 846 */       throw new TapjoyIntegrationException("NameNotFoundException: Could not find package.");
/*  618:     */     }
/*  619: 849 */     if (dependencyClassesRequired.size() != 0)
/*  620:     */     {
/*  621: 851 */       if (dependencyClassesRequired.size() == 1) {
/*  622: 852 */         throw new TapjoyIntegrationException("Missing " + dependencyClassesRequired.size() + " dependency class in manifest: " + dependencyClassesRequired.toString());
/*  623:     */       }
/*  624: 854 */       throw new TapjoyIntegrationException("Missing " + dependencyClassesRequired.size() + " dependency classes in manifest: " + dependencyClassesRequired.toString());
/*  625:     */     }
/*  626: 858 */     checkPermissions();
/*  627:     */     
/*  628:     */ 
/*  629: 861 */     resolveJSBridgeMethods();
/*  630:     */   }
/*  631:     */   
/*  632:     */   private void checkPermissions()
/*  633:     */     throws TapjoyIntegrationException
/*  634:     */   {
/*  635: 870 */     Vector<String> missingPermissions = new Vector();
/*  636: 871 */     for (String permission : TapjoyConstants.dependencyPermissions) {
/*  637: 873 */       if (!isPermissionGranted(permission)) {
/*  638: 875 */         missingPermissions.add(permission);
/*  639:     */       }
/*  640:     */     }
/*  641: 879 */     if (missingPermissions.size() != 0)
/*  642:     */     {
/*  643: 881 */       if (missingPermissions.size() == 1) {
/*  644: 882 */         throw new TapjoyIntegrationException("Missing 1 permission in manifest: " + missingPermissions.toString());
/*  645:     */       }
/*  646: 884 */       throw new TapjoyIntegrationException("Missing " + missingPermissions.size() + " permissions in manifest: " + missingPermissions.toString());
/*  647:     */     }
/*  648: 888 */     missingPermissions = new Vector();
/*  649: 889 */     for (String permission : TapjoyConstants.optionalPermissions) {
/*  650: 891 */       if (!isPermissionGranted(permission)) {
/*  651: 893 */         missingPermissions.add(permission);
/*  652:     */       }
/*  653:     */     }
/*  654: 897 */     if (missingPermissions.size() != 0) {
/*  655: 899 */       if (missingPermissions.size() == 1) {
/*  656: 900 */         TapjoyLog.w("TapjoyConnect", "WARNING -- " + missingPermissions.toString() + " permission was not found in manifest. The exclusion of this permission could cause problems.");
/*  657:     */       } else {
/*  658: 902 */         TapjoyLog.w("TapjoyConnect", "WARNING -- " + missingPermissions.toString() + " permissions were not found in manifest. The exclusion of these permissions could cause problems.");
/*  659:     */       }
/*  660:     */     }
/*  661:     */   }
/*  662:     */   
/*  663:     */   private void resolveJSBridgeMethods()
/*  664:     */     throws TapjoyIntegrationException
/*  665:     */   {
/*  666:     */     Class jsBridge;
/*  667:     */     try
/*  668:     */     {
/*  669: 915 */       jsBridge = Class.forName("com.tapjoy.TJAdUnitJSBridge");
/*  670:     */     }
/*  671:     */     catch (ClassNotFoundException e)
/*  672:     */     {
/*  673: 919 */       throw new TapjoyIntegrationException("ClassNotFoundException: com.tapjoy.TJAdUnitJSBridge was not found.");
/*  674:     */     }
/*  675:     */     try
/*  676:     */     {
/*  677: 925 */       jsBridge.getMethod("closeRequested", new Class[0]);
/*  678:     */     }
/*  679:     */     catch (NoSuchMethodException e)
/*  680:     */     {
/*  681: 930 */       throw new TapjoyIntegrationException("Try configuring Proguard or other code obfuscators to ignore com.tapjoy classes. Visit http://kc.tapjoy.com for more information.");
/*  682:     */     }
/*  683: 936 */     String mraidString = (String)TapjoyUtil.getResource("mraid.js");
/*  684: 939 */     if (mraidString == null) {
/*  685: 940 */       mraidString = TapjoyUtil.copyTextFromJarIntoString("js/mraid.js", context);
/*  686:     */     }
/*  687: 942 */     if (mraidString == null) {
/*  688: 943 */       throw new TapjoyIntegrationException("ClassNotFoundException: mraid.js was not found.");
/*  689:     */     }
/*  690:     */   }
/*  691:     */   
/*  692:     */   private void checkForDependency(ActivityInfo activityInfo)
/*  693:     */     throws TapjoyIntegrationException
/*  694:     */   {
/*  695: 952 */     if (dependencyClassesRequired.contains(activityInfo.name))
/*  696:     */     {
/*  697: 954 */       int index = dependencyClassesRequired.indexOf(activityInfo.name);
/*  698:     */       try
/*  699:     */       {
/*  700: 957 */         Class.forName((String)dependencyClassesRequired.get(index));
/*  701:     */         
/*  702: 959 */         Vector<String> missingConfigChanges = new Vector();
/*  703: 962 */         if ((activityInfo.configChanges & 0x80) != 128) {
/*  704: 963 */           missingConfigChanges.add("orientation");
/*  705:     */         }
/*  706: 966 */         if ((activityInfo.configChanges & 0x20) != 32) {
/*  707: 967 */           missingConfigChanges.add("keyboardHidden");
/*  708:     */         }
/*  709: 970 */         if ((Build.VERSION.SDK_INT >= 13) && ((activityInfo.configChanges & 0x400) != 1024)) {
/*  710: 971 */           missingConfigChanges.add("screenSize");
/*  711:     */         }
/*  712: 973 */         if (missingConfigChanges.size() != 0)
/*  713:     */         {
/*  714: 974 */           if (missingConfigChanges.size() == 1) {
/*  715: 975 */             throw new TapjoyIntegrationException(missingConfigChanges.toString() + " property is not specified in manifest configChanges for " + (String)dependencyClassesRequired.get(index));
/*  716:     */           }
/*  717: 977 */           throw new TapjoyIntegrationException(missingConfigChanges.toString() + " properties are not specified in manifest configChanges for " + (String)dependencyClassesRequired.get(index));
/*  718:     */         }
/*  719: 981 */         if ((Build.VERSION.SDK_INT >= 11) && (activityInfo.name.equals("com.tapjoy.TJAdUnitView")) && ((activityInfo.flags & 0x200) != 512)) {
/*  720: 982 */           throw new TapjoyIntegrationException("'hardwareAccelerated' property not specified in manifest for " + (String)dependencyClassesRequired.get(index));
/*  721:     */         }
/*  722: 984 */         dependencyClassesRequired.remove(index);
/*  723:     */       }
/*  724:     */       catch (ClassNotFoundException e)
/*  725:     */       {
/*  726: 988 */         throw new TapjoyIntegrationException("[ClassNotFoundException] Could not find dependency class " + (String)dependencyClassesRequired.get(index));
/*  727:     */       }
/*  728:     */     }
/*  729:     */   }
/*  730:     */   
/*  731:     */   private class PaidAppTimerTask
/*  732:     */     extends TimerTask
/*  733:     */   {
/*  734:     */     private PaidAppTimerTask() {}
/*  735:     */     
/*  736:     */     public void run()
/*  737:     */     {
/*  738:1000 */       TapjoyConnectCore.access$014(TapjoyConnectCore.this, 10000L);
/*  739:     */       
/*  740:1002 */       TapjoyLog.i("TapjoyConnect", "elapsed_time: " + TapjoyConnectCore.this.elapsed_time + " (" + TapjoyConnectCore.this.elapsed_time / 1000L / 60L + "m " + TapjoyConnectCore.this.elapsed_time / 1000L % 60L + "s)");
/*  741:     */       
/*  742:1004 */       SharedPreferences prefs = TapjoyConnectCore.context.getSharedPreferences("tjcPrefrences", 0);
/*  743:1005 */       SharedPreferences.Editor editor = prefs.edit();
/*  744:1006 */       editor.putLong("tapjoy_elapsed_time", TapjoyConnectCore.this.elapsed_time);
/*  745:1007 */       editor.commit();
/*  746:1010 */       if (TapjoyConnectCore.this.elapsed_time >= 900000L)
/*  747:     */       {
/*  748:1012 */         TapjoyLog.i("TapjoyConnect", "timer done...");
/*  749:1015 */         if ((TapjoyConnectCore.paidAppActionID != null) && (TapjoyConnectCore.paidAppActionID.length() > 0))
/*  750:     */         {
/*  751:1017 */           TapjoyLog.i("TapjoyConnect", "Calling PPA actionComplete...");
/*  752:     */           
/*  753:1019 */           TapjoyConnectCore.this.actionComplete(TapjoyConnectCore.paidAppActionID);
/*  754:     */         }
/*  755:1022 */         cancel();
/*  756:     */       }
/*  757:     */     }
/*  758:     */   }
/*  759:     */   
/*  760:     */   private static boolean handleConnectResponse(String response)
/*  761:     */   {
/*  762:1035 */     Document document = TapjoyUtil.buildDocument(response);
/*  763:1037 */     if (document != null)
/*  764:     */     {
/*  765:1039 */       String nodeValue = TapjoyUtil.getNodeTrimValue(document.getElementsByTagName("PackageNames"));
/*  766:     */       Vector<String> allPackageNames;
/*  767:1042 */       if ((nodeValue != null) && (nodeValue.length() > 0))
/*  768:     */       {
/*  769:1044 */         String data = nodeValue;
/*  770:1045 */         allPackageNames = new Vector();
/*  771:     */         
/*  772:1047 */         int current = 0;
/*  773:1048 */         int index = -1;
/*  774:     */         for (;;)
/*  775:     */         {
/*  776:1052 */           index = data.indexOf(',', current);
/*  777:1055 */           if (index == -1)
/*  778:     */           {
/*  779:1058 */             TapjoyLog.i("TapjoyConnect", "parse: " + data.substring(current).trim());
/*  780:1059 */             allPackageNames.add(data.substring(current).trim());
/*  781:1060 */             break;
/*  782:     */           }
/*  783:1066 */           TapjoyLog.i("TapjoyConnect", "parse: " + data.substring(current, index).trim());
/*  784:1067 */           allPackageNames.add(data.substring(current, index).trim());
/*  785:1068 */           current = index + 1;
/*  786:     */         }
/*  787:1072 */         matchingPackageNames = "";
/*  788:     */         
/*  789:1074 */         List<ApplicationInfo> applications = packageManager.getInstalledApplications(0);
/*  790:1075 */         for (ApplicationInfo appInfo : applications) {
/*  791:1078 */           if ((appInfo.flags & 0x1) != 1) {
/*  792:1085 */             if (allPackageNames.contains(appInfo.packageName))
/*  793:     */             {
/*  794:1087 */               TapjoyLog.i("TapjoyConnect", "MATCH: installed packageName: " + appInfo.packageName);
/*  795:1090 */               if (matchingPackageNames.length() > 0) {
/*  796:1091 */                 matchingPackageNames += ",";
/*  797:     */               }
/*  798:1093 */               matchingPackageNames += appInfo.packageName;
/*  799:     */             }
/*  800:     */           }
/*  801:     */         }
/*  802:     */       }
/*  803:1099 */       nodeValue = TapjoyUtil.getNodeTrimValue(document.getElementsByTagName("Success"));
/*  804:1102 */       if ((nodeValue != null) && (nodeValue.equals("true"))) {
/*  805:1104 */         return true;
/*  806:     */       }
/*  807:1108 */       return false;
/*  808:     */     }
/*  809:1112 */     return true;
/*  810:     */   }
/*  811:     */   
/*  812:     */   private boolean handlePayPerActionResponse(String response)
/*  813:     */   {
/*  814:1124 */     Document document = TapjoyUtil.buildDocument(response);
/*  815:1126 */     if (document != null)
/*  816:     */     {
/*  817:1128 */       String nodeValue = TapjoyUtil.getNodeTrimValue(document.getElementsByTagName("Success"));
/*  818:1131 */       if ((nodeValue != null) && (nodeValue.equals("true")))
/*  819:     */       {
/*  820:1133 */         TapjoyLog.i("TapjoyConnect", "Successfully sent completed Pay-Per-Action to Tapjoy server.");
/*  821:1134 */         return true;
/*  822:     */       }
/*  823:1138 */       TapjoyLog.e("TapjoyConnect", "Completed Pay-Per-Action call failed.");
/*  824:     */     }
/*  825:1142 */     return false;
/*  826:     */   }
/*  827:     */   
/*  828:     */   public void release()
/*  829:     */   {
/*  830:1151 */     tapjoyConnectCore = null;
/*  831:1152 */     tapjoyURLConnection = null;
/*  832:     */     
/*  833:1154 */     TapjoyLog.i("TapjoyConnect", "Releasing core static instance.");
/*  834:     */   }
/*  835:     */   
/*  836:     */   public static String getAppID()
/*  837:     */   {
/*  838:1168 */     return appID;
/*  839:     */   }
/*  840:     */   
/*  841:     */   public static String getDeviceID()
/*  842:     */   {
/*  843:1177 */     return deviceID;
/*  844:     */   }
/*  845:     */   
/*  846:     */   public static String getUserID()
/*  847:     */   {
/*  848:1186 */     return userID;
/*  849:     */   }
/*  850:     */   
/*  851:     */   public static String getHostURL()
/*  852:     */   {
/*  853:1195 */     return getConnectFlagValue("TJC_SERVICE_URL");
/*  854:     */   }
/*  855:     */   
/*  856:     */   public static String getRedirectDomain()
/*  857:     */   {
/*  858:1200 */     return redirectDomain;
/*  859:     */   }
/*  860:     */   
/*  861:     */   public static Map<String, String> getVideoParams()
/*  862:     */   {
/*  863:1218 */     Map<String, String> params = new HashMap();
/*  864:1221 */     if (videoEnabled)
/*  865:     */     {
/*  866:1225 */       if (videoIDs.length() > 0) {
/*  867:1226 */         TapjoyUtil.safePut(params, "video_offer_ids", videoIDs, true);
/*  868:     */       }
/*  869:     */     }
/*  870:     */     else {
/*  871:1231 */       TapjoyUtil.safePut(params, "hide_videos", String.valueOf(true), true);
/*  872:     */     }
/*  873:1234 */     TapjoyLog.i("TapjoyConnect", "video parameters: " + params);
/*  874:     */     
/*  875:1236 */     return params;
/*  876:     */   }
/*  877:     */   
/*  878:     */   public static String getCarrierName()
/*  879:     */   {
/*  880:1245 */     return carrierName;
/*  881:     */   }
/*  882:     */   
/*  883:     */   public String getSerial()
/*  884:     */   {
/*  885:1254 */     String serial = null;
/*  886:     */     try
/*  887:     */     {
/*  888:1258 */       Class<?> clazz = Class.forName("android.os.Build");
/*  889:1259 */       Field field = clazz.getDeclaredField("SERIAL");
/*  890:1261 */       if (!field.isAccessible()) {
/*  891:1262 */         field.setAccessible(true);
/*  892:     */       }
/*  893:1264 */       serial = field.get(Build.class).toString();
/*  894:     */       
/*  895:1266 */       TapjoyLog.i("TapjoyConnect", "serial: " + serial);
/*  896:     */     }
/*  897:     */     catch (Exception e)
/*  898:     */     {
/*  899:1270 */       TapjoyLog.e("TapjoyConnect", e.toString());
/*  900:     */     }
/*  901:1273 */     return serial;
/*  902:     */   }
/*  903:     */   
/*  904:     */   public static String getConnectionType()
/*  905:     */   {
/*  906:1282 */     String type = "";
/*  907:     */     try
/*  908:     */     {
/*  909:1288 */       ConnectivityManager connectivityManager = (ConnectivityManager)context.getSystemService("connectivity");
/*  910:1291 */       if ((connectivityManager != null) && (connectivityManager.getActiveNetworkInfo() != null))
/*  911:     */       {
/*  912:1293 */         switch (connectivityManager.getActiveNetworkInfo().getType())
/*  913:     */         {
/*  914:     */         case 1: 
/*  915:     */         case 6: 
/*  916:1297 */           type = "wifi";
/*  917:1298 */           break;
/*  918:     */         default: 
/*  919:1300 */           type = "mobile";
/*  920:     */         }
/*  921:1304 */         TapjoyLog.i("TapjoyConnect", "connectivity: " + connectivityManager.getActiveNetworkInfo().getType());
/*  922:1305 */         TapjoyLog.i("TapjoyConnect", "connection_type: " + type);
/*  923:     */       }
/*  924:     */     }
/*  925:     */     catch (Exception e)
/*  926:     */     {
/*  927:1310 */       TapjoyLog.e("TapjoyConnect", "getConnectionType error: " + e.toString());
/*  928:     */     }
/*  929:1313 */     return type;
/*  930:     */   }
/*  931:     */   
/*  932:     */   public static String getConnectionSubType()
/*  933:     */   {
/*  934:1323 */     String subType = "";
/*  935:     */     try
/*  936:     */     {
/*  937:1329 */       ConnectivityManager connectivityManager = (ConnectivityManager)context.getSystemService("connectivity");
/*  938:1332 */       if (connectivityManager != null)
/*  939:     */       {
/*  940:1334 */         subType = connectivityManager.getActiveNetworkInfo().getSubtypeName();
/*  941:1335 */         TapjoyLog.i("TapjoyConnect", "connection_sub_type: " + subType);
/*  942:     */       }
/*  943:     */     }
/*  944:     */     catch (Exception e)
/*  945:     */     {
/*  946:1340 */       TapjoyLog.e("TapjoyConnect", "getConnectionSubType error: " + e.toString());
/*  947:     */     }
/*  948:1343 */     return subType;
/*  949:     */   }
/*  950:     */   
/*  951:     */   public static Map<String, String> getTimeStampAndVerifierParams()
/*  952:     */   {
/*  953:1352 */     Map<String, String> params = new HashMap();
/*  954:1353 */     String verifier = "";
/*  955:     */     
/*  956:     */ 
/*  957:1356 */     long time = System.currentTimeMillis() / 1000L;
/*  958:1357 */     verifier = getVerifier(time);
/*  959:     */     
/*  960:1359 */     TapjoyUtil.safePut(params, "timestamp", String.valueOf(time), true);
/*  961:1360 */     TapjoyUtil.safePut(params, "verifier", verifier, true);
/*  962:     */     
/*  963:1362 */     return params;
/*  964:     */   }
/*  965:     */   
/*  966:     */   protected boolean detectApplication(String name)
/*  967:     */   {
/*  968:1374 */     List<ApplicationInfo> applications = packageManager.getInstalledApplications(0);
/*  969:1377 */     for (ApplicationInfo application : applications) {
/*  970:1379 */       if (application.packageName.startsWith(name)) {
/*  971:1381 */         return true;
/*  972:     */       }
/*  973:     */     }
/*  974:1387 */     return false;
/*  975:     */   }
/*  976:     */   
/*  977:     */   protected boolean detectSharingApplication(String name)
/*  978:     */   {
/*  979:1399 */     Intent sendIntent = new Intent("android.intent.action.SEND");
/*  980:1400 */     sendIntent.setType("text/plain");
/*  981:1401 */     List<ResolveInfo> activities = packageManager.queryIntentActivities(sendIntent, 0);
/*  982:1404 */     for (ResolveInfo activity : activities) {
/*  983:1406 */       if (activity.activityInfo.packageName.startsWith(name)) {
/*  984:1408 */         return true;
/*  985:     */       }
/*  986:     */     }
/*  987:1414 */     return false;
/*  988:     */   }
/*  989:     */   
/*  990:     */   protected boolean detectCapability(String name, String permission)
/*  991:     */   {
/*  992:1426 */     FeatureInfo[] featuresList = packageManager.getSystemAvailableFeatures();
/*  993:1429 */     for (FeatureInfo feature : featuresList) {
/*  994:1430 */       if (feature.name.matches(name))
/*  995:     */       {
/*  996:1433 */         if (permission == null) {
/*  997:1436 */           return true;
/*  998:     */         }
/*  999:1439 */         if (packageManager.checkPermission(permission, context.getPackageName()) == 0) {
/* 1000:1442 */           return true;
/* 1001:     */         }
/* 1002:1447 */         return false;
/* 1003:     */       }
/* 1004:     */     }
/* 1005:1453 */     return false;
/* 1006:     */   }
/* 1007:     */   
/* 1008:     */   protected boolean detectStore(String name)
/* 1009:     */   {
/* 1010:1463 */     boolean detected = false;
/* 1011:     */     
/* 1012:     */ 
/* 1013:1466 */     Intent sendIntent = new Intent("android.intent.action.VIEW");
/* 1014:1469 */     if (name.length() < 1)
/* 1015:     */     {
/* 1016:1472 */       sendIntent.setData(Uri.parse("market://details"));
/* 1017:1473 */       List<ResolveInfo> activities = packageManager.queryIntentActivities(sendIntent, 0);
/* 1018:1476 */       if (activities.size() > 0) {
/* 1019:1477 */         detected = true;
/* 1020:     */       }
/* 1021:     */     }
/* 1022:1479 */     else if (name.equals("gfan"))
/* 1023:     */     {
/* 1024:1482 */       detected = detectApplication("com.mappn.gfan");
/* 1025:     */     }
/* 1026:1484 */     else if (name.equals("skt"))
/* 1027:     */     {
/* 1028:1487 */       detected = detectApplication("com.skt.skaf.TSCINSTALL");
/* 1029:     */     }
/* 1030:1491 */     if (detected) {}
/* 1031:1499 */     return detected;
/* 1032:     */   }
/* 1033:     */   
/* 1034:     */   private static String generateSessionID()
/* 1035:     */   {
/* 1036:1508 */     String id = null;
/* 1037:     */     
/* 1038:1510 */     TapjoyLog.i("TapjoyConnect", "generating sessionID...");
/* 1039:     */     try
/* 1040:     */     {
/* 1041:1514 */       id = TapjoyUtil.SHA256(System.currentTimeMillis() / 1000L + appID + deviceID);
/* 1042:1515 */       lastTimeStamp = System.currentTimeMillis();
/* 1043:     */     }
/* 1044:     */     catch (Exception e)
/* 1045:     */     {
/* 1046:1519 */       TapjoyLog.e("TapjoyConnect", "unable to generate session id: " + e.toString());
/* 1047:     */     }
/* 1048:1522 */     return id;
/* 1049:     */   }
/* 1050:     */   
/* 1051:     */   public static Context getContext()
/* 1052:     */   {
/* 1053:1531 */     return context;
/* 1054:     */   }
/* 1055:     */   
/* 1056:     */   private static String getVerifierID()
/* 1057:     */   {
/* 1058:1541 */     if ((deviceID != null) && (deviceID.length() > 0)) {
/* 1059:1543 */       return deviceID;
/* 1060:     */     }
/* 1061:1546 */     if ((macAddress != null) && (macAddress.length() > 0)) {
/* 1062:1548 */       return macAddress;
/* 1063:     */     }
/* 1064:1551 */     if ((androidID != null) && (androidID.length() > 0)) {
/* 1065:1553 */       return androidID;
/* 1066:     */     }
/* 1067:1558 */     Log.e("TapjoyConnect", "Error -- no valid device identifier");
/* 1068:1559 */     return null;
/* 1069:     */   }
/* 1070:     */   
/* 1071:     */   private static String getVerifier(long time)
/* 1072:     */   {
/* 1073:1572 */     String verifier = "";
/* 1074:     */     try
/* 1075:     */     {
/* 1076:1578 */       verifier = TapjoyUtil.SHA256(appID + ":" + getVerifierID() + ":" + time + ":" + secretKey);
/* 1077:     */     }
/* 1078:     */     catch (Exception e)
/* 1079:     */     {
/* 1080:1582 */       TapjoyLog.e("TapjoyConnect", "getVerifier ERROR: " + e.toString());
/* 1081:     */     }
/* 1082:1585 */     return verifier;
/* 1083:     */   }
/* 1084:     */   
/* 1085:     */   public static String getAwardPointsVerifier(long time, int amount, String guid)
/* 1086:     */   {
/* 1087:1597 */     String verifier = "";
/* 1088:     */     try
/* 1089:     */     {
/* 1090:1603 */       verifier = TapjoyUtil.SHA256(appID + ":" + getVerifierID() + ":" + time + ":" + secretKey + ":" + amount + ":" + guid);
/* 1091:     */     }
/* 1092:     */     catch (Exception e)
/* 1093:     */     {
/* 1094:1607 */       TapjoyLog.e("TapjoyConnect", "getAwardPointsVerifier ERROR: " + e.toString());
/* 1095:     */     }
/* 1096:1610 */     return verifier;
/* 1097:     */   }
/* 1098:     */   
/* 1099:     */   private static String getPackageNamesVerifier(long time, String packageNames)
/* 1100:     */   {
/* 1101:1622 */     String verifier = "";
/* 1102:     */     try
/* 1103:     */     {
/* 1104:1628 */       verifier = TapjoyUtil.SHA256(appID + ":" + deviceID + ":" + time + ":" + secretKey + ":" + packageNames);
/* 1105:     */     }
/* 1106:     */     catch (Exception e)
/* 1107:     */     {
/* 1108:1632 */       TapjoyLog.e("TapjoyConnect", "getVerifier ERROR: " + e.toString());
/* 1109:     */     }
/* 1110:1635 */     return verifier;
/* 1111:     */   }
/* 1112:     */   
/* 1113:     */   public boolean isInitialized()
/* 1114:     */   {
/* 1115:1645 */     return this.initialized;
/* 1116:     */   }
/* 1117:     */   
/* 1118:     */   public static void setPlugin(String name)
/* 1119:     */   {
/* 1120:1654 */     plugin = name;
/* 1121:     */   }
/* 1122:     */   
/* 1123:     */   public static void setSDKType(String name)
/* 1124:     */   {
/* 1125:1663 */     sdkType = name;
/* 1126:     */   }
/* 1127:     */   
/* 1128:     */   public static void setUserID(String id)
/* 1129:     */   {
/* 1130:1674 */     userID = id;
/* 1131:     */     
/* 1132:1676 */     TapjoyLog.i("TapjoyConnect", "URL parameters: " + getURLParams());
/* 1133:     */     
/* 1134:     */ 
/* 1135:1679 */     new Thread(new Runnable()
/* 1136:     */     {
/* 1137:     */       public void run()
/* 1138:     */       {
/* 1139:1683 */         TapjoyLog.i("TapjoyConnect", "setUserID...");
/* 1140:     */         
/* 1141:     */ 
/* 1142:1686 */         TapjoyHttpURLResponse response = TapjoyConnectCore.tapjoyURLConnection.getResponseFromURL(TapjoyConnectCore.getHostURL() + "set_publisher_user_id?", TapjoyConnectCore.getURLParams());
/* 1143:1689 */         if (response.response != null)
/* 1144:     */         {
/* 1145:1691 */           if (TapjoyConnectCore.handleConnectResponse(response.response)) {}
/* 1146:1692 */           TapjoyLog.i("TapjoyConnect", "setUserID successful...");
/* 1147:     */         }
/* 1148:     */       }
/* 1149:     */     }).start();
/* 1150:     */   }
/* 1151:     */   
/* 1152:     */   public static void setVideoIDs(String ids)
/* 1153:     */   {
/* 1154:1704 */     videoIDs = ids;
/* 1155:     */   }
/* 1156:     */   
/* 1157:     */   public static void setVideoEnabled(boolean enabled)
/* 1158:     */   {
/* 1159:1713 */     videoEnabled = enabled;
/* 1160:     */   }
/* 1161:     */   
/* 1162:     */   public void setTapjoyViewNotifier(TapjoyViewNotifier notifier)
/* 1163:     */   {
/* 1164:1722 */     viewNotifier = notifier;
/* 1165:     */   }
/* 1166:     */   
/* 1167:     */   public static void viewWillClose(int type)
/* 1168:     */   {
/* 1169:1731 */     if (viewNotifier != null) {
/* 1170:1732 */       viewNotifier.viewWillClose(type);
/* 1171:     */     }
/* 1172:     */   }
/* 1173:     */   
/* 1174:     */   public static void viewDidClose(int type)
/* 1175:     */   {
/* 1176:1741 */     if (viewNotifier != null) {
/* 1177:1742 */       viewNotifier.viewDidClose(type);
/* 1178:     */     }
/* 1179:     */   }
/* 1180:     */   
/* 1181:     */   public static void viewWillOpen(int type)
/* 1182:     */   {
/* 1183:1751 */     if (viewNotifier != null) {
/* 1184:1752 */       viewNotifier.viewWillOpen(type);
/* 1185:     */     }
/* 1186:     */   }
/* 1187:     */   
/* 1188:     */   public static void viewDidOpen(int type)
/* 1189:     */   {
/* 1190:1761 */     if (viewNotifier != null) {
/* 1191:1762 */       viewNotifier.viewDidOpen(type);
/* 1192:     */     }
/* 1193:     */   }
/* 1194:     */   
/* 1195:     */   public static void setHostURL(String url)
/* 1196:     */   {
/* 1197:1771 */     if (!url.endsWith("/")) {
/* 1198:1772 */       url = url + "/";
/* 1199:     */     }
/* 1200:1773 */     connectFlags.put("TJC_SERVICE_URL", url);
/* 1201:     */   }
/* 1202:     */   
/* 1203:     */   private boolean isPermissionGranted(String permission)
/* 1204:     */   {
/* 1205:1783 */     int status = packageManager.checkPermission(permission, context.getPackageName());
/* 1206:1785 */     if (status != 0) {
/* 1207:1787 */       return false;
/* 1208:     */     }
/* 1209:1790 */     return true;
/* 1210:     */   }
/* 1211:     */   
/* 1212:     */   public static void saveOfflineLog(String message)
/* 1213:     */   {
/* 1214:1795 */     String saveMessage = message;
/* 1215:     */     
/* 1216:     */ 
/* 1217:1798 */     saveMessage = saveMessage + "&original_timestamp=" + System.currentTimeMillis() / 1000L;
/* 1218:1799 */     saveMessage = saveMessage + "&offline=true";
/* 1219:     */     
/* 1220:     */ 
/* 1221:1802 */     SharedPreferences settings = context.getSharedPreferences("tapjoyOfflineLog", 0);
/* 1222:1803 */     SharedPreferences.Editor editor = settings.edit();
/* 1223:1804 */     editor.putString(Long.toString(System.currentTimeMillis()), saveMessage);
/* 1224:1805 */     editor.commit();
/* 1225:     */   }
/* 1226:     */   
/* 1227:     */   public static Map<String, ?> getOfflineLogs()
/* 1228:     */   {
/* 1229:1811 */     SharedPreferences settings = context.getSharedPreferences("tapjoyOfflineLog", 0);
/* 1230:1812 */     return settings.getAll();
/* 1231:     */   }
/* 1232:     */   
/* 1233:     */   public static void removeOfflineLog(String key)
/* 1234:     */   {
/* 1235:1817 */     SharedPreferences settings = context.getSharedPreferences("tapjoyOfflineLog", 0);
/* 1236:1818 */     SharedPreferences.Editor editor = settings.edit();
/* 1237:1819 */     editor.remove(key);
/* 1238:1820 */     editor.commit();
/* 1239:     */   }
/* 1240:     */   
/* 1241:     */   public static void sendOfflineLogs()
/* 1242:     */   {
/* 1243:1826 */     new Thread(new Runnable()
/* 1244:     */     {
/* 1245:     */       public void run()
/* 1246:     */       {
/* 1247:1830 */         TapjoyURLConnection connection = new TapjoyURLConnection();
/* 1248:1831 */         Map<String, ?> requests = TapjoyConnectCore.getOfflineLogs();
/* 1249:1834 */         for (Map.Entry<String, ?> entry : requests.entrySet())
/* 1250:     */         {
/* 1251:1836 */           TapjoyLog.i("TapjoyConnect", "sending offline log: ");
/* 1252:     */           
/* 1253:1838 */           String httpRequest = (String)entry.getValue() + "&" + TapjoyUtil.convertURLParams(TapjoyConnectCore.getTimeStampAndVerifierParams(), false);
/* 1254:1839 */           TapjoyHttpURLResponse response = connection.getResponseFromURL(httpRequest, "");
/* 1255:1841 */           if (response != null) {
/* 1256:1844 */             if (response.statusCode == 200) {
/* 1257:1847 */               TapjoyConnectCore.removeOfflineLog((String)entry.getKey());
/* 1258:     */             }
/* 1259:     */           }
/* 1260:     */         }
/* 1261:     */       }
/* 1262:     */     }).start();
/* 1263:     */   }
/* 1264:     */   
/* 1265:     */   public void actionComplete(String actionID)
/* 1266:     */   {
/* 1267:1866 */     TapjoyLog.i("TapjoyConnect", "actionComplete: " + actionID);
/* 1268:     */     
/* 1269:     */ 
/* 1270:1869 */     Map<String, String> actionURLParams = getParamsWithoutAppID();
/* 1271:1870 */     TapjoyUtil.safePut(actionURLParams, "app_id", actionID, true);
/* 1272:1871 */     actionURLParams.putAll(getTimeStampAndVerifierParams());
/* 1273:     */     
/* 1274:1873 */     TapjoyLog.i("TapjoyConnect", "PPA URL parameters: " + actionURLParams);
/* 1275:     */     
/* 1276:1875 */     new Thread(new PPAThread(actionURLParams)).start();
/* 1277:     */   }
/* 1278:     */   
/* 1279:     */   public void enablePaidAppWithActionID(String paidAppPayPerActionID)
/* 1280:     */   {
/* 1281:1889 */     TapjoyLog.i("TapjoyConnect", "enablePaidAppWithActionID: " + paidAppPayPerActionID);
/* 1282:     */     
/* 1283:1891 */     paidAppActionID = paidAppPayPerActionID;
/* 1284:     */     
/* 1285:1893 */     SharedPreferences prefs = context.getSharedPreferences("tjcPrefrences", 0);
/* 1286:     */     
/* 1287:     */ 
/* 1288:1896 */     this.elapsed_time = prefs.getLong("tapjoy_elapsed_time", 0L);
/* 1289:     */     
/* 1290:1898 */     TapjoyLog.i("TapjoyConnect", "paidApp elapsed: " + this.elapsed_time);
/* 1291:1901 */     if (this.elapsed_time >= 900000L)
/* 1292:     */     {
/* 1293:1904 */       if ((paidAppActionID != null) && (paidAppActionID.length() > 0))
/* 1294:     */       {
/* 1295:1906 */         TapjoyLog.i("TapjoyConnect", "Calling PPA actionComplete...");
/* 1296:     */         
/* 1297:1908 */         actionComplete(paidAppActionID);
/* 1298:     */       }
/* 1299:     */     }
/* 1300:1913 */     else if (this.timer == null)
/* 1301:     */     {
/* 1302:1915 */       this.timer = new Timer();
/* 1303:1916 */       this.timer.schedule(new PaidAppTimerTask(null), 10000L, 10000L);
/* 1304:     */     }
/* 1305:     */   }
/* 1306:     */   
/* 1307:     */   public class ConnectThread
/* 1308:     */     implements Runnable
/* 1309:     */   {
/* 1310:     */     public ConnectThread() {}
/* 1311:     */     
/* 1312:     */     public void run()
/* 1313:     */     {
/* 1314:1927 */       TapjoyLog.i("TapjoyConnect", "starting connect call...");
/* 1315:     */       
/* 1316:1929 */       String connectHostURL = "https://connect.tapjoy.com/";
/* 1317:1932 */       if (TapjoyConnectCore.getHostURL() != "https://ws.tapjoyads.com/") {
/* 1318:1933 */         connectHostURL = TapjoyConnectCore.getHostURL();
/* 1319:     */       }
/* 1320:1936 */       TapjoyHttpURLResponse httpResponse = TapjoyConnectCore.tapjoyURLConnection.getResponseFromURL(connectHostURL + "connect?", TapjoyConnectCore.getURLParams());
/* 1321:1939 */       if ((httpResponse != null) && (httpResponse.statusCode == 200))
/* 1322:     */       {
/* 1323:1941 */         if (TapjoyConnectCore.handleConnectResponse(httpResponse.response))
/* 1324:     */         {
/* 1325:1943 */           TapjoyLog.i("TapjoyConnect", "Successfully connected to tapjoy site.");
/* 1326:1945 */           if (TapjoyConnectCore.connectNotifier != null) {
/* 1327:1946 */             TapjoyConnectCore.connectNotifier.connectSuccess();
/* 1328:     */           }
/* 1329:     */         }
/* 1330:1951 */         else if (TapjoyConnectCore.connectNotifier != null)
/* 1331:     */         {
/* 1332:1952 */           TapjoyConnectCore.connectNotifier.connectFail();
/* 1333:     */         }
/* 1334:1956 */         if (TapjoyConnectCore.matchingPackageNames.length() > 0)
/* 1335:     */         {
/* 1336:1958 */           Map<String, String> params = TapjoyConnectCore.getGenericURLParams();
/* 1337:1959 */           TapjoyUtil.safePut(params, "package_names", TapjoyConnectCore.matchingPackageNames, true);
/* 1338:     */           
/* 1339:     */ 
/* 1340:1962 */           long time = System.currentTimeMillis() / 1000L;
/* 1341:1963 */           String verifier = TapjoyConnectCore.getPackageNamesVerifier(time, TapjoyConnectCore.matchingPackageNames);
/* 1342:1964 */           TapjoyUtil.safePut(params, "timestamp", String.valueOf(time), true);
/* 1343:1965 */           TapjoyUtil.safePut(params, "verifier", verifier, true);
/* 1344:     */           
/* 1345:1967 */           httpResponse = new TapjoyURLConnection().getResponseFromURL(TapjoyConnectCore.getHostURL() + "apps_installed?", params);
/* 1346:1970 */           if ((httpResponse != null) && (httpResponse.statusCode == 200)) {
/* 1347:1971 */             TapjoyLog.i("TapjoyConnect", "Successfully pinged sdkless api.");
/* 1348:     */           }
/* 1349:     */         }
/* 1350:     */       }
/* 1351:1977 */       else if (TapjoyConnectCore.connectNotifier != null)
/* 1352:     */       {
/* 1353:1978 */         TapjoyConnectCore.connectNotifier.connectFail();
/* 1354:     */       }
/* 1355:     */     }
/* 1356:     */   }
/* 1357:     */   
/* 1358:     */   public class PPAThread
/* 1359:     */     implements Runnable
/* 1360:     */   {
/* 1361:     */     private Map<String, String> params;
/* 1362:     */     
/* 1363:     */     public PPAThread()
/* 1364:     */     {
/* 1365:1993 */       this.params = urlParams;
/* 1366:     */     }
/* 1367:     */     
/* 1368:     */     public void run()
/* 1369:     */     {
/* 1370:1999 */       TapjoyHttpURLResponse response = TapjoyConnectCore.tapjoyURLConnection.getResponseFromURL(TapjoyConnectCore.getHostURL() + "connect?", this.params);
/* 1371:2002 */       if (response.response != null) {
/* 1372:2003 */         TapjoyConnectCore.this.handlePayPerActionResponse(response.response);
/* 1373:     */       }
/* 1374:     */     }
/* 1375:     */   }
/* 1376:     */   
/* 1377:     */   public void setCurrencyMultiplier(float multiplier)
/* 1378:     */   {
/* 1379:2014 */     TapjoyLog.i("TapjoyConnect", "setVirtualCurrencyMultiplier: " + multiplier);
/* 1380:2015 */     currencyMultiplier = multiplier;
/* 1381:     */   }
/* 1382:     */   
/* 1383:     */   public float getCurrencyMultiplier()
/* 1384:     */   {
/* 1385:2024 */     return currencyMultiplier;
/* 1386:     */   }
/* 1387:     */   
/* 1388:     */   public static String getConnectFlagValue(String key)
/* 1389:     */   {
/* 1390:2034 */     String flag = "";
/* 1391:2036 */     if (connectFlags != null) {
/* 1392:2038 */       flag = (String)connectFlags.get(key);
/* 1393:     */     }
/* 1394:2042 */     if (flag == null) {
/* 1395:2043 */       flag = "";
/* 1396:     */     }
/* 1397:2045 */     return flag;
/* 1398:     */   }
/* 1399:     */   
/* 1400:     */   public static String getSecretKey()
/* 1401:     */   {
/* 1402:2055 */     return secretKey;
/* 1403:     */   }
/* 1404:     */   
/* 1405:     */   public static String getSha2DeviceID()
/* 1406:     */   {
/* 1407:2065 */     return sha2DeviceID;
/* 1408:     */   }
/* 1409:     */   
/* 1410:     */   public static String getAndroidID()
/* 1411:     */   {
/* 1412:2070 */     return androidID;
/* 1413:     */   }
/* 1414:     */   
/* 1415:     */   public static String getSha1MacAddress()
/* 1416:     */   {
/* 1417:2080 */     String sha1MacAddress = null;
/* 1418:     */     try
/* 1419:     */     {
/* 1420:2084 */       sha1MacAddress = TapjoyUtil.SHA1(macAddress);
/* 1421:     */     }
/* 1422:     */     catch (Exception e)
/* 1423:     */     {
/* 1424:2088 */       TapjoyLog.e("TapjoyConnect", "Error generating sha1 of macAddress: " + e.toString());
/* 1425:     */     }
/* 1426:2091 */     return sha1MacAddress;
/* 1427:     */   }
/* 1428:     */   
/* 1429:     */   public static String getMacAddress()
/* 1430:     */   {
/* 1431:2101 */     return macAddress;
/* 1432:     */   }
/* 1433:     */   
/* 1434:     */   public static float getDeviceScreenDensityScale()
/* 1435:     */   {
/* 1436:2111 */     return deviceScreenDensityScale;
/* 1437:     */   }
/* 1438:     */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyConnectCore
 * JD-Core Version:    0.7.0.1
 */