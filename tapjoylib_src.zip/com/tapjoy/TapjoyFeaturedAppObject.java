/*  1:   */ package com.tapjoy;
/*  2:   */ 
/*  3:   */ /**
/*  4:   */  * @deprecated
/*  5:   */  */
/*  6:   */ public class TapjoyFeaturedAppObject
/*  7:   */ {
/*  8:19 */   public String cost = "";
/*  9:22 */   public String storeID = "";
/* 10:25 */   public String name = "";
/* 11:28 */   public String description = "";
/* 12:   */   public int amount;
/* 13:34 */   public String iconURL = "";
/* 14:37 */   public String redirectURL = "";
/* 15:   */   public int maxTimesToDisplayThisApp;
/* 16:43 */   public String fullScreenAdURL = "";
/* 17:   */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyFeaturedAppObject
 * JD-Core Version:    0.7.0.1
 */