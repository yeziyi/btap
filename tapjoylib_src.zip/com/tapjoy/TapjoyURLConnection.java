/*   1:    */ package com.tapjoy;
/*   2:    */ 
/*   3:    */ import java.io.BufferedReader;
/*   4:    */ import java.io.InputStreamReader;
/*   5:    */ import java.net.HttpURLConnection;
/*   6:    */ import java.net.URL;
/*   7:    */ import java.util.Map;
/*   8:    */ import org.apache.http.HttpEntity;
/*   9:    */ import org.apache.http.HttpResponse;
/*  10:    */ import org.apache.http.StatusLine;
/*  11:    */ import org.apache.http.client.HttpClient;
/*  12:    */ import org.apache.http.client.methods.HttpGet;
/*  13:    */ import org.apache.http.client.methods.HttpPost;
/*  14:    */ import org.apache.http.impl.client.DefaultHttpClient;
/*  15:    */ 
/*  16:    */ public class TapjoyURLConnection
/*  17:    */ {
/*  18:    */   public static final int TYPE_GET = 0;
/*  19:    */   public static final int TYPE_POST = 1;
/*  20: 25 */   public static boolean unitTestMode = false;
/*  21:    */   private static final String TAG = "TapjoyURLConnection";
/*  22:    */   
/*  23:    */   public TapjoyHttpURLResponse getRedirectFromURL(String url)
/*  24:    */   {
/*  25: 33 */     return getResponseFromURL(url, "", 0, true);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public TapjoyHttpURLResponse getResponseFromURL(String url, Map<String, String> params)
/*  29:    */   {
/*  30: 38 */     return getResponseFromURL(url, TapjoyUtil.convertURLParams(params, false), 0);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public TapjoyHttpURLResponse getResponseFromURL(String url, Map<String, String> params, int type)
/*  34:    */   {
/*  35: 43 */     return getResponseFromURL(url, TapjoyUtil.convertURLParams(params, false), type);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public TapjoyHttpURLResponse getResponseFromURL(String url)
/*  39:    */   {
/*  40: 48 */     return getResponseFromURL(url, "", 0);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public TapjoyHttpURLResponse getResponseFromURL(String url, String params)
/*  44:    */   {
/*  45: 53 */     return getResponseFromURL(url, params, 0);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public TapjoyHttpURLResponse getResponseFromURL(String url, String params, int type)
/*  49:    */   {
/*  50: 58 */     return getResponseFromURL(url, params, 0, false);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public TapjoyHttpURLResponse getResponseFromURL(String url, String params, int type, boolean getRedirectOnly)
/*  54:    */   {
/*  55: 63 */     TapjoyHttpURLResponse tapjoyResponse = new TapjoyHttpURLResponse();
/*  56: 64 */     HttpURLConnection connection = null;
/*  57: 65 */     BufferedReader rd = null;
/*  58: 66 */     StringBuilder sb = null;
/*  59: 67 */     String line = null;
/*  60:    */     try
/*  61:    */     {
/*  62: 71 */       String requestURL = url + params;
/*  63:    */       
/*  64: 73 */       TapjoyLog.i("TapjoyURLConnection", "http " + (type == 0 ? "get" : "post") + ": " + requestURL);
/*  65: 76 */       if (unitTestMode)
/*  66:    */       {
/*  67: 78 */         HttpClient client = new DefaultHttpClient();
/*  68:    */         HttpResponse response;
/*  69:    */         HttpResponse response;
/*  70: 81 */         if (type == 1)
/*  71:    */         {
/*  72: 83 */           HttpPost request = new HttpPost(requestURL);
/*  73: 84 */           response = client.execute(request);
/*  74:    */         }
/*  75:    */         else
/*  76:    */         {
/*  77: 88 */           HttpGet request = new HttpGet(requestURL);
/*  78: 89 */           response = client.execute(request);
/*  79:    */         }
/*  80: 92 */         tapjoyResponse.statusCode = response.getStatusLine().getStatusCode();
/*  81:    */         
/*  82: 94 */         rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
/*  83:    */       }
/*  84:    */       else
/*  85:    */       {
/*  86: 98 */         URL httpURL = new URL(requestURL);
/*  87: 99 */         connection = (HttpURLConnection)httpURL.openConnection();
/*  88:102 */         if (getRedirectOnly) {
/*  89:103 */           connection.setInstanceFollowRedirects(false);
/*  90:    */         }
/*  91:105 */         connection.setConnectTimeout(15000);
/*  92:106 */         connection.setReadTimeout(30000);
/*  93:109 */         if (type == 1) {
/*  94:111 */           connection.setRequestMethod("POST");
/*  95:    */         }
/*  96:114 */         connection.connect();
/*  97:    */         
/*  98:116 */         tapjoyResponse.statusCode = connection.getResponseCode();
/*  99:119 */         if (!getRedirectOnly) {
/* 100:122 */           rd = new BufferedReader(new InputStreamReader(connection.getInputStream()));
/* 101:    */         }
/* 102:    */       }
/* 103:127 */       if (!getRedirectOnly)
/* 104:    */       {
/* 105:129 */         sb = new StringBuilder();
/* 106:131 */         while ((line = rd.readLine()) != null) {
/* 107:133 */           sb.append(line + '\n');
/* 108:    */         }
/* 109:136 */         tapjoyResponse.response = sb.toString();
/* 110:    */       }
/* 111:139 */       if (tapjoyResponse.statusCode == 302) {
/* 112:140 */         tapjoyResponse.redirectURL = connection.getHeaderField("Location");
/* 113:    */       }
/* 114:142 */       String contentLength = connection.getHeaderField("content-length");
/* 115:144 */       if (contentLength != null) {
/* 116:    */         try
/* 117:    */         {
/* 118:148 */           tapjoyResponse.contentLength = Integer.valueOf(contentLength).intValue();
/* 119:    */         }
/* 120:    */         catch (Exception e)
/* 121:    */         {
/* 122:152 */           TapjoyLog.e("TapjoyURLConnection", "Exception: " + e.toString());
/* 123:    */         }
/* 124:    */       }
/* 125:156 */       if (rd != null)
/* 126:    */       {
/* 127:158 */         rd.close();
/* 128:159 */         rd = null;
/* 129:    */       }
/* 130:162 */       connection = null;
/* 131:    */     }
/* 132:    */     catch (Exception e)
/* 133:    */     {
/* 134:166 */       TapjoyLog.e("TapjoyURLConnection", "Exception: " + e.toString());
/* 135:    */       try
/* 136:    */       {
/* 137:172 */         if ((connection != null) && (tapjoyResponse.response == null))
/* 138:    */         {
/* 139:175 */           rd = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
/* 140:176 */           sb = new StringBuilder();
/* 141:178 */           while ((line = rd.readLine()) != null) {
/* 142:180 */             sb.append(line + '\n');
/* 143:    */           }
/* 144:183 */           tapjoyResponse.response = sb.toString();
/* 145:    */         }
/* 146:    */       }
/* 147:    */       catch (Exception ex)
/* 148:    */       {
/* 149:188 */         TapjoyLog.e("TapjoyURLConnection", "Exception trying to get error code/content: " + ex.toString());
/* 150:    */       }
/* 151:    */     }
/* 152:192 */     TapjoyLog.i("TapjoyURLConnection", "--------------------");
/* 153:193 */     TapjoyLog.i("TapjoyURLConnection", "response status: " + tapjoyResponse.statusCode);
/* 154:194 */     TapjoyLog.i("TapjoyURLConnection", "response size: " + tapjoyResponse.contentLength);
/* 155:195 */     TapjoyLog.v("TapjoyURLConnection", "response: ");
/* 156:196 */     TapjoyLog.v("TapjoyURLConnection", "" + tapjoyResponse.response);
/* 157:197 */     if ((tapjoyResponse.redirectURL != null) && (tapjoyResponse.redirectURL.length() > 0)) {
/* 158:198 */       TapjoyLog.i("TapjoyURLConnection", "redirectURL: " + tapjoyResponse.redirectURL);
/* 159:    */     }
/* 160:199 */     TapjoyLog.i("TapjoyURLConnection", "--------------------");
/* 161:    */     
/* 162:201 */     return tapjoyResponse;
/* 163:    */   }
/* 164:    */   
/* 165:    */   public String getContentLength(String url)
/* 166:    */   {
/* 167:211 */     String contentLength = null;
/* 168:    */     try
/* 169:    */     {
/* 170:214 */       String requestURL = url;
/* 171:    */       
/* 172:    */ 
/* 173:217 */       requestURL = requestURL.replaceAll(" ", "%20");
/* 174:    */       
/* 175:219 */       TapjoyLog.i("TapjoyURLConnection", "requestURL: " + requestURL);
/* 176:    */       
/* 177:221 */       URL httpURL = new URL(requestURL);
/* 178:222 */       HttpURLConnection connection = (HttpURLConnection)httpURL.openConnection();
/* 179:223 */       connection.setConnectTimeout(15000);
/* 180:224 */       connection.setReadTimeout(30000);
/* 181:225 */       contentLength = connection.getHeaderField("content-length");
/* 182:    */     }
/* 183:    */     catch (Exception e)
/* 184:    */     {
/* 185:229 */       TapjoyLog.e("TapjoyURLConnection", "Exception: " + e.toString());
/* 186:    */     }
/* 187:232 */     TapjoyLog.i("TapjoyURLConnection", "content-length: " + contentLength);
/* 188:    */     
/* 189:234 */     return contentLength;
/* 190:    */   }
/* 191:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyURLConnection
 * JD-Core Version:    0.7.0.1
 */