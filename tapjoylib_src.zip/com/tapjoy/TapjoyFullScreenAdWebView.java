/*  1:   */ package com.tapjoy;
/*  2:   */ 
/*  3:   */ import android.os.Bundle;
/*  4:   */ 
/*  5:   */ public class TapjoyFullScreenAdWebView
/*  6:   */   extends TJAdUnitView
/*  7:   */ {
/*  8:   */   private static final String TAG = "Full Screen Ad";
/*  9:   */   
/* 10:   */   protected void onCreate(Bundle savedInstanceState)
/* 11:   */   {
/* 12:18 */     TapjoyLog.i("Full Screen Ad", "TapjoyFullScreenAdWebView onCreate");
/* 13:19 */     super.onCreate(savedInstanceState);
/* 14:   */     
/* 15:21 */     TapjoyConnectCore.viewWillOpen(1);
/* 16:22 */     TapjoyConnectCore.viewDidOpen(1);
/* 17:   */   }
/* 18:   */   
/* 19:   */   protected void onDestroy()
/* 20:   */   {
/* 21:28 */     super.onDestroy();
/* 22:30 */     if (isFinishing())
/* 23:   */     {
/* 24:32 */       TapjoyConnectCore.viewWillClose(1);
/* 25:33 */       TapjoyConnectCore.viewDidClose(1);
/* 26:   */     }
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyFullScreenAdWebView
 * JD-Core Version:    0.7.0.1
 */