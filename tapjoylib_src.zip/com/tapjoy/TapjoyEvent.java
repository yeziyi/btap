/*   1:    */ package com.tapjoy;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.Map;
/*   6:    */ 
/*   7:    */ public class TapjoyEvent
/*   8:    */ {
/*   9: 13 */   private static TapjoyURLConnection tapjoyURLConnection = null;
/*  10:    */   private Context context;
/*  11:    */   public static final int EVENT_TYPE_IAP = 1;
/*  12:    */   public static final int EVENT_TYPE_SHUTDOWN = 2;
/*  13:    */   private static final String TAG = "Event";
/*  14:    */   
/*  15:    */   public TapjoyEvent(Context ctx)
/*  16:    */   {
/*  17: 27 */     this.context = ctx;
/*  18: 28 */     tapjoyURLConnection = new TapjoyURLConnection();
/*  19:    */   }
/*  20:    */   
/*  21:    */   public void sendShutDownEvent()
/*  22:    */   {
/*  23: 37 */     sendEvent(2, null);
/*  24:    */   }
/*  25:    */   
/*  26:    */   public void sendIAPEvent(String name, float price, int quantity, String currencyCode)
/*  27:    */   {
/*  28: 50 */     Map<String, String> params = new HashMap();
/*  29: 51 */     TapjoyUtil.safePut(params, createEventParameter("name"), name, true);
/*  30: 52 */     TapjoyUtil.safePut(params, createEventParameter("price"), String.valueOf(price), true);
/*  31: 53 */     TapjoyUtil.safePut(params, createEventParameter("quantity"), String.valueOf(quantity), true);
/*  32: 54 */     TapjoyUtil.safePut(params, createEventParameter("currency_code"), currencyCode, true);
/*  33: 55 */     sendEvent(1, params);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public String createEventParameter(String parameter)
/*  37:    */   {
/*  38: 66 */     return "ue[" + parameter + "]";
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void sendEvent(int type, Map<String, String> eventData)
/*  42:    */   {
/*  43: 77 */     TapjoyLog.i("Event", "sendEvent type: " + type);
/*  44:    */     
/*  45:    */ 
/*  46: 80 */     Map<String, String> eventURLParams = TapjoyConnectCore.getGenericURLParams();
/*  47: 81 */     TapjoyUtil.safePut(eventURLParams, "event_type_id", String.valueOf(type), true);
/*  48: 83 */     if (eventData != null) {
/*  49: 84 */       eventURLParams.putAll(eventData);
/*  50:    */     }
/*  51: 86 */     new Thread(new EventThread(eventURLParams)).start();
/*  52:    */   }
/*  53:    */   
/*  54:    */   public class EventThread
/*  55:    */     implements Runnable
/*  56:    */   {
/*  57:    */     private Map<String, String> params;
/*  58:    */     
/*  59:    */     public EventThread()
/*  60:    */     {
/*  61: 99 */       this.params = urlParams;
/*  62:    */     }
/*  63:    */     
/*  64:    */     public void run()
/*  65:    */     {
/*  66:104 */       String url = TapjoyConnectCore.getHostURL() + "user_events?";
/*  67:    */       
/*  68:    */ 
/*  69:107 */       TapjoyHttpURLResponse httpResponse = TapjoyEvent.tapjoyURLConnection.getResponseFromURL(url, this.params, 1);
/*  70:109 */       if (httpResponse != null) {
/*  71:111 */         switch (httpResponse.statusCode)
/*  72:    */         {
/*  73:    */         case 0: 
/*  74:116 */           TapjoyLog.e("Event", "Event network error: " + httpResponse.statusCode);
/*  75:117 */           TapjoyConnectCore.saveOfflineLog(url + "?" + this.params);
/*  76:118 */           break;
/*  77:    */         case 200: 
/*  78:122 */           TapjoyLog.i("Event", "Successfully sent Tapjoy event");
/*  79:123 */           break;
/*  80:    */         case 400: 
/*  81:128 */           TapjoyLog.e("Event", "Error sending event: " + httpResponse.response);
/*  82:129 */           break;
/*  83:    */         default: 
/*  84:132 */           TapjoyLog.e("Event", "Unknown error: " + httpResponse.statusCode);
/*  85:133 */           break;
/*  86:    */         }
/*  87:    */       } else {
/*  88:138 */         TapjoyLog.e("Event", "Server/network error");
/*  89:    */       }
/*  90:    */     }
/*  91:    */   }
/*  92:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyEvent
 * JD-Core Version:    0.7.0.1
 */