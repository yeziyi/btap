/*  1:   */ package com.tapjoy;
/*  2:   */ 
/*  3:   */ import java.util.LinkedHashMap;
/*  4:   */ import java.util.Map;
/*  5:   */ import java.util.Map.Entry;
/*  6:   */ 
/*  7:   */ public class TJEventManager
/*  8:   */ {
/*  9: 8 */   private static Map<String, TJEvent> eventsTable = new LinkedHashMap()
/* 10:   */   {
/* 11:   */     private static final long serialVersionUID = 5794666578643304105L;
/* 12:   */     
/* 13:   */     protected boolean removeEldestEntry(Map.Entry<String, TJEvent> eldest)
/* 14:   */     {
/* 15:16 */       return size() > 20;
/* 16:   */     }
/* 17:   */   };
/* 18:   */   
/* 19:   */   public static TJEvent get(String guid)
/* 20:   */   {
/* 21:22 */     return (TJEvent)eventsTable.get(guid);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public static void put(String guid, TJEvent event)
/* 25:   */   {
/* 26:27 */     eventsTable.put(guid, event);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public static void remove(String guid)
/* 30:   */   {
/* 31:32 */     eventsTable.remove(guid);
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TJEventManager
 * JD-Core Version:    0.7.0.1
 */