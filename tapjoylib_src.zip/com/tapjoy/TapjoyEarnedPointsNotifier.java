package com.tapjoy;

public abstract interface TapjoyEarnedPointsNotifier
{
  public abstract void earnedTapPoints(int paramInt);
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyEarnedPointsNotifier
 * JD-Core Version:    0.7.0.1
 */