/*   1:    */ package com.tapjoy;
/*   2:    */ 
/*   3:    */ import android.app.Activity;
/*   4:    */ import android.app.AlertDialog.Builder;
/*   5:    */ import android.app.Dialog;
/*   6:    */ import android.content.BroadcastReceiver;
/*   7:    */ import android.content.Context;
/*   8:    */ import android.content.DialogInterface;
/*   9:    */ import android.content.DialogInterface.OnCancelListener;
/*  10:    */ import android.content.DialogInterface.OnClickListener;
/*  11:    */ import android.content.Intent;
/*  12:    */ import android.content.IntentFilter;
/*  13:    */ import android.graphics.Bitmap;
/*  14:    */ import android.graphics.Typeface;
/*  15:    */ import android.media.MediaPlayer;
/*  16:    */ import android.media.MediaPlayer.OnCompletionListener;
/*  17:    */ import android.media.MediaPlayer.OnErrorListener;
/*  18:    */ import android.media.MediaPlayer.OnPreparedListener;
/*  19:    */ import android.net.Uri;
/*  20:    */ import android.os.Build.VERSION;
/*  21:    */ import android.os.Bundle;
/*  22:    */ import android.os.Handler;
/*  23:    */ import android.view.KeyEvent;
/*  24:    */ import android.widget.ImageView;
/*  25:    */ import android.widget.RelativeLayout;
/*  26:    */ import android.widget.RelativeLayout.LayoutParams;
/*  27:    */ import android.widget.TextView;
/*  28:    */ import android.widget.VideoView;
/*  29:    */ import java.util.Timer;
/*  30:    */ import java.util.TimerTask;
/*  31:    */ 
/*  32:    */ public class TapjoyVideoView
/*  33:    */   extends Activity
/*  34:    */   implements MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener, MediaPlayer.OnPreparedListener
/*  35:    */ {
/*  36:    */   private VideoView videoView;
/*  37:    */   private TextView overlayText;
/*  38:    */   private String videoURL;
/*  39:    */   private String webviewURL;
/*  40:    */   private String cancelMessage;
/*  41:    */   private String connectivityMessage;
/*  42:    */   private RelativeLayout relativeLayout;
/*  43:    */   private Bitmap watermark;
/*  44:    */   private TapjoyVideoBroadcastReceiver videoBroadcastReceiver;
/*  45:    */   Dialog dialog;
/*  46:    */   Timer timer;
/*  47: 51 */   private static boolean videoError = false;
/*  48: 52 */   private static boolean streamingVideo = false;
/*  49:    */   private static TapjoyVideoObject videoData;
/*  50:    */   private boolean dialogShowing;
/*  51:    */   private static final String BUNDLE_DIALOG_SHOWING = "dialog_showing";
/*  52:    */   private static final String BUNDLE_SEEK_TIME = "seek_time";
/*  53:    */   private boolean sendClick;
/*  54:    */   private boolean clickRequestSuccess;
/*  55:    */   private boolean allowBackKey;
/*  56:    */   private boolean shouldDismiss;
/*  57:    */   private int timeRemaining;
/*  58:    */   private int seekTime;
/*  59:    */   private static final int DIALOG_WARNING_ID = 0;
/*  60:    */   private static final int DIALOG_CONNECTIVITY_LOST_ID = 1;
/*  61:    */   private static final String videoWillResumeText = "";
/*  62:    */   private static final String videoSecondsText = " seconds";
/*  63:    */   private ImageView tapjoyImage;
/*  64:    */   private static final String TAG = "VideoView";
/*  65:    */   final Handler mHandler;
/*  66: 83 */   static int textSize = 16;
/*  67:    */   final Runnable mUpdateResults;
/*  68:    */   
/*  69:    */   protected void onCreate(Bundle savedInstanceState)
/*  70:    */   {
/*  71: 89 */     TapjoyLog.i("VideoView", "onCreate");
/*  72: 90 */     super.onCreate(savedInstanceState);
/*  73:    */     
/*  74: 92 */     TapjoyConnectCore.viewWillOpen(3);
/*  75: 94 */     if (savedInstanceState != null)
/*  76:    */     {
/*  77: 96 */       TapjoyLog.i("VideoView", "*** Loading saved data from bundle ***");
/*  78: 97 */       this.seekTime = savedInstanceState.getInt("seek_time");
/*  79: 98 */       this.dialogShowing = savedInstanceState.getBoolean("dialog_showing");
/*  80:    */     }
/*  81:101 */     Bundle extras = getIntent().getExtras();
/*  82:103 */     if (extras != null)
/*  83:    */     {
/*  84:105 */       videoData = (TapjoyVideoObject)extras.getSerializable("VIDEO_DATA");
/*  85:    */       
/*  86:107 */       this.videoURL = extras.getString("VIDEO_URL");
/*  87:109 */       if (extras.containsKey("VIDEO_CANCEL_MESSAGE")) {
/*  88:110 */         this.cancelMessage = extras.getString("VIDEO_CANCEL_MESSAGE");
/*  89:    */       }
/*  90:112 */       if (extras.containsKey("VIDEO_SHOULD_DISMISS")) {
/*  91:113 */         this.shouldDismiss = extras.getBoolean("VIDEO_SHOULD_DISMISS");
/*  92:    */       }
/*  93:    */     }
/*  94:116 */     TapjoyLog.i("VideoView", "dialogShowing: " + this.dialogShowing + ", seekTime: " + this.seekTime);
/*  95:119 */     if (videoData != null)
/*  96:    */     {
/*  97:121 */       this.sendClick = true;
/*  98:122 */       streamingVideo = false;
/*  99:125 */       if (TapjoyVideo.getInstance() == null)
/* 100:    */       {
/* 101:127 */         TapjoyLog.i("VideoView", "null video");
/* 102:128 */         finishWithResult(false);
/* 103:129 */         return;
/* 104:    */       }
/* 105:133 */       this.videoURL = videoData.dataLocation;
/* 106:134 */       this.webviewURL = videoData.webviewURL;
/* 107:137 */       if ((this.videoURL == null) || (this.videoURL.length() == 0))
/* 108:    */       {
/* 109:139 */         TapjoyLog.i("VideoView", "no cached video, try streaming video at location: " + videoData.videoURL);
/* 110:140 */         this.videoURL = videoData.videoURL;
/* 111:141 */         streamingVideo = true;
/* 112:    */       }
/* 113:144 */       TapjoyLog.i("VideoView", "videoPath: " + this.videoURL);
/* 114:    */     }
/* 115:148 */     else if (this.videoURL != null)
/* 116:    */     {
/* 117:150 */       streamingVideo = true;
/* 118:151 */       this.sendClick = false;
/* 119:    */       
/* 120:153 */       TapjoyLog.i("VideoView", "playing video only: " + this.videoURL);
/* 121:    */     }
/* 122:157 */     requestWindowFeature(1);
/* 123:158 */     this.relativeLayout = new RelativeLayout(this);
/* 124:159 */     RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(-1, -1);
/* 125:160 */     this.relativeLayout.setLayoutParams(params);
/* 126:161 */     setContentView(this.relativeLayout);
/* 127:164 */     if (Build.VERSION.SDK_INT > 3)
/* 128:    */     {
/* 129:166 */       TapjoyDisplayMetricsUtil displayMetricsUtil = new TapjoyDisplayMetricsUtil(this);
/* 130:    */       
/* 131:168 */       int deviceScreenLayoutSize = displayMetricsUtil.getScreenLayoutSize();
/* 132:    */       
/* 133:170 */       TapjoyLog.i("VideoView", "deviceScreenLayoutSize: " + deviceScreenLayoutSize);
/* 134:174 */       if (deviceScreenLayoutSize == 4) {
/* 135:176 */         textSize = 32;
/* 136:    */       }
/* 137:    */     }
/* 138:183 */     this.videoBroadcastReceiver = new TapjoyVideoBroadcastReceiver(null);
/* 139:184 */     registerReceiver(this.videoBroadcastReceiver, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
/* 140:    */     
/* 141:186 */     initVideoView();
/* 142:    */     
/* 143:188 */     TapjoyLog.i("VideoView", "onCreate DONE");
/* 144:    */     
/* 145:190 */     TapjoyConnectCore.viewDidOpen(3);
/* 146:    */   }
/* 147:    */   
/* 148:    */   protected void onPause()
/* 149:    */   {
/* 150:196 */     super.onPause();
/* 151:199 */     if (this.videoView.isPlaying())
/* 152:    */     {
/* 153:201 */       TapjoyLog.i("VideoView", "onPause");
/* 154:    */       
/* 155:203 */       this.videoView.pause();
/* 156:204 */       this.seekTime = this.videoView.getCurrentPosition();
/* 157:205 */       TapjoyLog.i("VideoView", "seekTime: " + this.seekTime);
/* 158:    */     }
/* 159:    */   }
/* 160:    */   
/* 161:    */   protected void onResume()
/* 162:    */   {
/* 163:213 */     TapjoyLog.i("VideoView", "onResume");
/* 164:214 */     super.onResume();
/* 165:    */     
/* 166:    */ 
/* 167:217 */     setRequestedOrientation(0);
/* 168:220 */     if (this.seekTime > 0)
/* 169:    */     {
/* 170:222 */       TapjoyLog.i("VideoView", "seekTime: " + this.seekTime);
/* 171:    */       
/* 172:224 */       this.videoView.seekTo(this.seekTime);
/* 173:227 */       if ((!this.dialogShowing) || (this.dialog == null) || (!this.dialog.isShowing())) {
/* 174:228 */         this.videoView.start();
/* 175:    */       }
/* 176:    */     }
/* 177:    */   }
/* 178:    */   
/* 179:    */   protected void onDestroy()
/* 180:    */   {
/* 181:236 */     super.onDestroy();
/* 182:238 */     if (isFinishing())
/* 183:    */     {
/* 184:240 */       unregisterReceiver(this.videoBroadcastReceiver);
/* 185:241 */       TapjoyConnectCore.viewWillClose(3);
/* 186:242 */       TapjoyConnectCore.viewDidClose(3);
/* 187:    */     }
/* 188:    */   }
/* 189:    */   
/* 190:    */   protected void onSaveInstanceState(Bundle outState)
/* 191:    */   {
/* 192:250 */     super.onSaveInstanceState(outState);
/* 193:    */     
/* 194:252 */     TapjoyLog.i("VideoView", "*** onSaveInstanceState ***");
/* 195:253 */     TapjoyLog.i("VideoView", "dialogShowing: " + this.dialogShowing + ", seekTime: " + this.seekTime);
/* 196:254 */     outState.putBoolean("dialog_showing", this.dialogShowing);
/* 197:255 */     outState.putInt("seek_time", this.seekTime);
/* 198:    */   }
/* 199:    */   
/* 200:    */   public void onWindowFocusChanged(boolean hasFocus)
/* 201:    */   {
/* 202:262 */     TapjoyLog.i("VideoView", "onWindowFocusChanged");
/* 203:263 */     super.onWindowFocusChanged(hasFocus);
/* 204:    */   }
/* 205:    */   
/* 206:    */   protected void onActivityResult(int requestCode, int resultCode, Intent data)
/* 207:    */   {
/* 208:270 */     super.onActivityResult(requestCode, resultCode, data);
/* 209:    */     
/* 210:272 */     TapjoyLog.i("VideoView", "onActivityResult requestCode:" + requestCode + ", resultCode: " + resultCode);
/* 211:    */     
/* 212:274 */     Bundle extras = null;
/* 213:276 */     if (data != null) {
/* 214:277 */       extras = data.getExtras();
/* 215:    */     }
/* 216:279 */     String result = extras != null ? extras.getString("result") : null;
/* 217:282 */     if ((result == null) || (result.length() == 0) || (result.equals("offer_wall"))) {
/* 218:284 */       finishWithResult(true);
/* 219:288 */     } else if (result.equals("tjvideo")) {
/* 220:290 */       initVideoView();
/* 221:    */     }
/* 222:    */   }
/* 223:    */   
/* 224:    */   private void initVideoView()
/* 225:    */   {
/* 226:296 */     this.relativeLayout.removeAllViews();
/* 227:297 */     this.relativeLayout.setBackgroundColor(-16777216);
/* 228:299 */     if ((this.videoView == null) && (this.overlayText == null))
/* 229:    */     {
/* 230:304 */       this.tapjoyImage = new ImageView(this);
/* 231:    */       
/* 232:    */ 
/* 233:307 */       this.watermark = TapjoyVideo.getWatermarkImage();
/* 234:309 */       if (this.watermark != null) {
/* 235:310 */         this.tapjoyImage.setImageBitmap(this.watermark);
/* 236:    */       }
/* 237:312 */       RelativeLayout.LayoutParams imageParams = new RelativeLayout.LayoutParams(-2, -2);
/* 238:313 */       imageParams.addRule(12);
/* 239:314 */       imageParams.addRule(11);
/* 240:315 */       this.tapjoyImage.setLayoutParams(imageParams);
/* 241:    */       
/* 242:    */ 
/* 243:    */ 
/* 244:    */ 
/* 245:320 */       this.videoView = new VideoView(this);
/* 246:321 */       this.videoView.setOnCompletionListener(this);
/* 247:322 */       this.videoView.setOnErrorListener(this);
/* 248:323 */       this.videoView.setOnPreparedListener(this);
/* 249:325 */       if (streamingVideo)
/* 250:    */       {
/* 251:327 */         TapjoyLog.i("VideoView", "streaming video: " + this.videoURL);
/* 252:328 */         this.videoView.setVideoURI(Uri.parse(this.videoURL));
/* 253:    */       }
/* 254:    */       else
/* 255:    */       {
/* 256:332 */         TapjoyLog.i("VideoView", "cached video: " + this.videoURL);
/* 257:333 */         this.videoView.setVideoPath(this.videoURL);
/* 258:    */       }
/* 259:336 */       RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
/* 260:337 */       layoutParams.addRule(13);
/* 261:338 */       this.videoView.setLayoutParams(layoutParams);
/* 262:    */       
/* 263:    */ 
/* 264:    */ 
/* 265:    */ 
/* 266:343 */       this.timeRemaining = (this.videoView.getDuration() / 1000);
/* 267:    */       
/* 268:345 */       TapjoyLog.i("VideoView", "videoView.getDuration(): " + this.videoView.getDuration());
/* 269:346 */       TapjoyLog.i("VideoView", "timeRemaining: " + this.timeRemaining);
/* 270:    */       
/* 271:348 */       this.overlayText = new TextView(this);
/* 272:349 */       this.overlayText.setTextSize(textSize);
/* 273:350 */       this.overlayText.setTypeface(Typeface.create("default", 1), 1);
/* 274:    */       
/* 275:352 */       RelativeLayout.LayoutParams textParams = new RelativeLayout.LayoutParams(-2, -2);
/* 276:353 */       textParams.addRule(12);
/* 277:354 */       this.overlayText.setLayoutParams(textParams);
/* 278:    */     }
/* 279:357 */     startVideo();
/* 280:    */     
/* 281:359 */     this.relativeLayout.addView(this.videoView);
/* 282:360 */     this.relativeLayout.addView(this.tapjoyImage);
/* 283:361 */     this.relativeLayout.addView(this.overlayText);
/* 284:    */   }
/* 285:    */   
/* 286:    */   private void showVideoCompletionScreen()
/* 287:    */   {
/* 288:367 */     if (this.shouldDismiss)
/* 289:    */     {
/* 290:369 */       finishWithResult(true);
/* 291:    */     }
/* 292:    */     else
/* 293:    */     {
/* 294:373 */       Intent intent = new Intent(this, TJAdUnitView.class);
/* 295:374 */       intent.putExtra("view_type", 4);
/* 296:375 */       intent.putExtra("url", this.webviewURL);
/* 297:376 */       intent.putExtra("legacy_view", true);
/* 298:    */       
/* 299:378 */       startActivityForResult(intent, 0);
/* 300:    */     }
/* 301:    */   }
/* 302:    */   
/* 303:    */   private void startVideo()
/* 304:    */   {
/* 305:388 */     this.videoView.requestFocus();
/* 306:391 */     if (this.dialogShowing)
/* 307:    */     {
/* 308:393 */       this.videoView.seekTo(this.seekTime);
/* 309:394 */       TapjoyLog.i("VideoView", "dialog is showing -- don't start");
/* 310:    */     }
/* 311:    */     else
/* 312:    */     {
/* 313:398 */       TapjoyLog.i("VideoView", "start");
/* 314:399 */       this.videoView.seekTo(0);
/* 315:400 */       this.videoView.start();
/* 316:    */       
/* 317:    */ 
/* 318:403 */       TapjoyVideo.videoNotifierStart();
/* 319:    */     }
/* 320:407 */     if (this.timer != null) {
/* 321:409 */       this.timer.cancel();
/* 322:    */     }
/* 323:413 */     this.timer = new Timer();
/* 324:414 */     this.timer.schedule(new RemainingTime(null), 500L, 100L);
/* 325:    */     
/* 326:    */ 
/* 327:417 */     this.clickRequestSuccess = false;
/* 328:420 */     if (this.sendClick)
/* 329:    */     {
/* 330:422 */       new Thread(new Runnable()
/* 331:    */       {
/* 332:    */         public void run()
/* 333:    */         {
/* 334:427 */           TapjoyLog.i("VideoView", "SENDING CLICK...");
/* 335:    */           
/* 336:429 */           TapjoyHttpURLResponse response = new TapjoyURLConnection().getResponseFromURL(TapjoyVideoView.videoData.clickURL);
/* 337:431 */           if ((response.response != null) && (response.response.contains("OK")))
/* 338:    */           {
/* 339:433 */             TapjoyLog.i("VideoView", "CLICK REQUEST SUCCESS!");
/* 340:434 */             TapjoyVideoView.this.clickRequestSuccess = true;
/* 341:    */           }
/* 342:    */         }
/* 343:438 */       }).start();
/* 344:439 */       this.sendClick = false;
/* 345:    */     }
/* 346:    */   }
/* 347:    */   
/* 348:    */   private void finishWithResult(boolean result)
/* 349:    */   {
/* 350:449 */     Intent returnIntent = new Intent();
/* 351:450 */     returnIntent.putExtra("result", result);
/* 352:451 */     returnIntent.putExtra("result_string1", Float.toString(this.videoView.getCurrentPosition() / 1000.0F));
/* 353:452 */     returnIntent.putExtra("result_string2", Float.toString(this.videoView.getDuration() / 1000.0F));
/* 354:453 */     returnIntent.putExtra("callback_id", getIntent().getStringExtra("callback_id"));
/* 355:454 */     setResult(-1, returnIntent);
/* 356:455 */     finish();
/* 357:    */   }
/* 358:    */   
/* 359:    */   private int getRemainingVideoTime()
/* 360:    */   {
/* 361:465 */     int timeRemaining = (this.videoView.getDuration() - this.videoView.getCurrentPosition()) / 1000;
/* 362:467 */     if (timeRemaining < 0) {
/* 363:468 */       timeRemaining = 0;
/* 364:    */     }
/* 365:470 */     return timeRemaining;
/* 366:    */   }
/* 367:    */   
/* 368:    */   private class RemainingTime
/* 369:    */     extends TimerTask
/* 370:    */   {
/* 371:    */     private RemainingTime() {}
/* 372:    */     
/* 373:    */     public void run()
/* 374:    */     {
/* 375:482 */       TapjoyVideoView.this.mHandler.post(TapjoyVideoView.this.mUpdateResults);
/* 376:    */     }
/* 377:    */   }
/* 378:    */   
/* 379:    */   public TapjoyVideoView()
/* 380:    */   {
/* 381: 38 */     this.videoView = null;
/* 382: 39 */     this.overlayText = null;
/* 383: 40 */     this.videoURL = null;
/* 384: 41 */     this.webviewURL = null;
/* 385: 42 */     this.cancelMessage = "Currency will not be awarded, are you sure you want to cancel the video?";
/* 386: 43 */     this.connectivityMessage = "A network connection is necessary to view videos. You will be able to complete the offer and receive your reward on the next connect.";
/* 387:    */     
/* 388:    */ 
/* 389:    */ 
/* 390:    */ 
/* 391:    */ 
/* 392: 49 */     this.timer = null;
/* 393:    */     
/* 394:    */ 
/* 395:    */ 
/* 396:    */ 
/* 397:    */ 
/* 398:    */ 
/* 399: 56 */     this.dialogShowing = false;
/* 400:    */     
/* 401:    */ 
/* 402:    */ 
/* 403: 60 */     this.sendClick = false;
/* 404: 61 */     this.clickRequestSuccess = false;
/* 405: 62 */     this.allowBackKey = false;
/* 406: 63 */     this.shouldDismiss = false;
/* 407: 64 */     this.timeRemaining = 0;
/* 408: 65 */     this.seekTime = 0;
/* 409:    */     
/* 410:    */ 
/* 411:    */ 
/* 412:    */ 
/* 413:    */ 
/* 414:    */ 
/* 415:    */ 
/* 416:    */ 
/* 417:    */ 
/* 418:    */ 
/* 419:    */ 
/* 420:    */ 
/* 421:    */ 
/* 422:    */ 
/* 423:    */ 
/* 424: 81 */     this.mHandler = new Handler();
/* 425:    */     
/* 426:    */ 
/* 427:    */ 
/* 428:    */ 
/* 429:    */ 
/* 430:    */ 
/* 431:    */ 
/* 432:    */ 
/* 433:    */ 
/* 434:    */ 
/* 435:    */ 
/* 436:    */ 
/* 437:    */ 
/* 438:    */ 
/* 439:    */ 
/* 440:    */ 
/* 441:    */ 
/* 442:    */ 
/* 443:    */ 
/* 444:    */ 
/* 445:    */ 
/* 446:    */ 
/* 447:    */ 
/* 448:    */ 
/* 449:    */ 
/* 450:    */ 
/* 451:    */ 
/* 452:    */ 
/* 453:    */ 
/* 454:    */ 
/* 455:    */ 
/* 456:    */ 
/* 457:    */ 
/* 458:    */ 
/* 459:    */ 
/* 460:    */ 
/* 461:    */ 
/* 462:    */ 
/* 463:    */ 
/* 464:    */ 
/* 465:    */ 
/* 466:    */ 
/* 467:    */ 
/* 468:    */ 
/* 469:    */ 
/* 470:    */ 
/* 471:    */ 
/* 472:    */ 
/* 473:    */ 
/* 474:    */ 
/* 475:    */ 
/* 476:    */ 
/* 477:    */ 
/* 478:    */ 
/* 479:    */ 
/* 480:    */ 
/* 481:    */ 
/* 482:    */ 
/* 483:    */ 
/* 484:    */ 
/* 485:    */ 
/* 486:    */ 
/* 487:    */ 
/* 488:    */ 
/* 489:    */ 
/* 490:    */ 
/* 491:    */ 
/* 492:    */ 
/* 493:    */ 
/* 494:    */ 
/* 495:    */ 
/* 496:    */ 
/* 497:    */ 
/* 498:    */ 
/* 499:    */ 
/* 500:    */ 
/* 501:    */ 
/* 502:    */ 
/* 503:    */ 
/* 504:    */ 
/* 505:    */ 
/* 506:    */ 
/* 507:    */ 
/* 508:    */ 
/* 509:    */ 
/* 510:    */ 
/* 511:    */ 
/* 512:    */ 
/* 513:    */ 
/* 514:    */ 
/* 515:    */ 
/* 516:    */ 
/* 517:    */ 
/* 518:    */ 
/* 519:    */ 
/* 520:    */ 
/* 521:    */ 
/* 522:    */ 
/* 523:    */ 
/* 524:    */ 
/* 525:    */ 
/* 526:    */ 
/* 527:    */ 
/* 528:    */ 
/* 529:    */ 
/* 530:    */ 
/* 531:    */ 
/* 532:    */ 
/* 533:    */ 
/* 534:    */ 
/* 535:    */ 
/* 536:    */ 
/* 537:    */ 
/* 538:    */ 
/* 539:    */ 
/* 540:    */ 
/* 541:    */ 
/* 542:    */ 
/* 543:    */ 
/* 544:    */ 
/* 545:    */ 
/* 546:    */ 
/* 547:    */ 
/* 548:    */ 
/* 549:    */ 
/* 550:    */ 
/* 551:    */ 
/* 552:    */ 
/* 553:    */ 
/* 554:    */ 
/* 555:    */ 
/* 556:    */ 
/* 557:    */ 
/* 558:    */ 
/* 559:    */ 
/* 560:    */ 
/* 561:    */ 
/* 562:    */ 
/* 563:    */ 
/* 564:    */ 
/* 565:    */ 
/* 566:    */ 
/* 567:    */ 
/* 568:    */ 
/* 569:    */ 
/* 570:    */ 
/* 571:    */ 
/* 572:    */ 
/* 573:    */ 
/* 574:    */ 
/* 575:    */ 
/* 576:    */ 
/* 577:    */ 
/* 578:    */ 
/* 579:    */ 
/* 580:    */ 
/* 581:    */ 
/* 582:    */ 
/* 583:    */ 
/* 584:    */ 
/* 585:    */ 
/* 586:    */ 
/* 587:    */ 
/* 588:    */ 
/* 589:    */ 
/* 590:    */ 
/* 591:    */ 
/* 592:    */ 
/* 593:    */ 
/* 594:    */ 
/* 595:    */ 
/* 596:    */ 
/* 597:    */ 
/* 598:    */ 
/* 599:    */ 
/* 600:    */ 
/* 601:    */ 
/* 602:    */ 
/* 603:    */ 
/* 604:    */ 
/* 605:    */ 
/* 606:    */ 
/* 607:    */ 
/* 608:    */ 
/* 609:    */ 
/* 610:    */ 
/* 611:    */ 
/* 612:    */ 
/* 613:    */ 
/* 614:    */ 
/* 615:    */ 
/* 616:    */ 
/* 617:    */ 
/* 618:    */ 
/* 619:    */ 
/* 620:    */ 
/* 621:    */ 
/* 622:    */ 
/* 623:    */ 
/* 624:    */ 
/* 625:    */ 
/* 626:    */ 
/* 627:    */ 
/* 628:    */ 
/* 629:    */ 
/* 630:    */ 
/* 631:    */ 
/* 632:    */ 
/* 633:    */ 
/* 634:    */ 
/* 635:    */ 
/* 636:    */ 
/* 637:    */ 
/* 638:    */ 
/* 639:    */ 
/* 640:    */ 
/* 641:    */ 
/* 642:    */ 
/* 643:    */ 
/* 644:    */ 
/* 645:    */ 
/* 646:    */ 
/* 647:    */ 
/* 648:    */ 
/* 649:    */ 
/* 650:    */ 
/* 651:    */ 
/* 652:    */ 
/* 653:    */ 
/* 654:    */ 
/* 655:    */ 
/* 656:    */ 
/* 657:    */ 
/* 658:    */ 
/* 659:    */ 
/* 660:    */ 
/* 661:    */ 
/* 662:    */ 
/* 663:    */ 
/* 664:    */ 
/* 665:    */ 
/* 666:    */ 
/* 667:    */ 
/* 668:    */ 
/* 669:    */ 
/* 670:    */ 
/* 671:    */ 
/* 672:    */ 
/* 673:    */ 
/* 674:    */ 
/* 675:    */ 
/* 676:    */ 
/* 677:    */ 
/* 678:    */ 
/* 679:    */ 
/* 680:    */ 
/* 681:    */ 
/* 682:    */ 
/* 683:    */ 
/* 684:    */ 
/* 685:    */ 
/* 686:    */ 
/* 687:    */ 
/* 688:    */ 
/* 689:    */ 
/* 690:    */ 
/* 691:    */ 
/* 692:    */ 
/* 693:    */ 
/* 694:    */ 
/* 695:    */ 
/* 696:    */ 
/* 697:    */ 
/* 698:    */ 
/* 699:    */ 
/* 700:    */ 
/* 701:    */ 
/* 702:    */ 
/* 703:    */ 
/* 704:    */ 
/* 705:    */ 
/* 706:    */ 
/* 707:    */ 
/* 708:    */ 
/* 709:    */ 
/* 710:    */ 
/* 711:    */ 
/* 712:    */ 
/* 713:    */ 
/* 714:    */ 
/* 715:    */ 
/* 716:    */ 
/* 717:    */ 
/* 718:    */ 
/* 719:    */ 
/* 720:    */ 
/* 721:    */ 
/* 722:    */ 
/* 723:    */ 
/* 724:    */ 
/* 725:    */ 
/* 726:    */ 
/* 727:    */ 
/* 728:    */ 
/* 729:    */ 
/* 730:    */ 
/* 731:    */ 
/* 732:    */ 
/* 733:    */ 
/* 734:    */ 
/* 735:    */ 
/* 736:    */ 
/* 737:    */ 
/* 738:    */ 
/* 739:    */ 
/* 740:    */ 
/* 741:    */ 
/* 742:    */ 
/* 743:    */ 
/* 744:    */ 
/* 745:    */ 
/* 746:    */ 
/* 747:    */ 
/* 748:    */ 
/* 749:    */ 
/* 750:    */ 
/* 751:    */ 
/* 752:    */ 
/* 753:    */ 
/* 754:    */ 
/* 755:    */ 
/* 756:    */ 
/* 757:    */ 
/* 758:    */ 
/* 759:    */ 
/* 760:    */ 
/* 761:    */ 
/* 762:    */ 
/* 763:    */ 
/* 764:    */ 
/* 765:    */ 
/* 766:    */ 
/* 767:    */ 
/* 768:    */ 
/* 769:    */ 
/* 770:    */ 
/* 771:    */ 
/* 772:    */ 
/* 773:    */ 
/* 774:    */ 
/* 775:    */ 
/* 776:    */ 
/* 777:    */ 
/* 778:    */ 
/* 779:    */ 
/* 780:    */ 
/* 781:    */ 
/* 782:    */ 
/* 783:    */ 
/* 784:    */ 
/* 785:    */ 
/* 786:    */ 
/* 787:    */ 
/* 788:    */ 
/* 789:    */ 
/* 790:    */ 
/* 791:    */ 
/* 792:    */ 
/* 793:    */ 
/* 794:    */ 
/* 795:    */ 
/* 796:    */ 
/* 797:    */ 
/* 798:    */ 
/* 799:    */ 
/* 800:    */ 
/* 801:    */ 
/* 802:    */ 
/* 803:    */ 
/* 804:    */ 
/* 805:    */ 
/* 806:    */ 
/* 807:    */ 
/* 808:    */ 
/* 809:    */ 
/* 810:    */ 
/* 811:    */ 
/* 812:    */ 
/* 813:    */ 
/* 814:    */ 
/* 815:    */ 
/* 816:    */ 
/* 817:    */ 
/* 818:    */ 
/* 819:    */ 
/* 820:    */ 
/* 821:    */ 
/* 822:    */ 
/* 823:    */ 
/* 824:    */ 
/* 825:    */ 
/* 826:    */ 
/* 827:    */ 
/* 828:    */ 
/* 829:    */ 
/* 830:    */ 
/* 831:488 */     this.mUpdateResults = new Runnable()
/* 832:    */     {
/* 833:    */       public void run()
/* 834:    */       {
/* 835:493 */         TapjoyVideoView.this.overlayText.setText("" + TapjoyVideoView.this.getRemainingVideoTime() + " seconds");
/* 836:    */       }
/* 837:    */     };
/* 838:    */   }
/* 839:    */   
/* 840:    */   public void onPrepared(MediaPlayer mp)
/* 841:    */   {
/* 842:504 */     TapjoyLog.i("VideoView", "onPrepared");
/* 843:    */   }
/* 844:    */   
/* 845:    */   public boolean onError(MediaPlayer mp, int what, int extra)
/* 846:    */   {
/* 847:511 */     videoError = true;
/* 848:512 */     TapjoyLog.i("VideoView", "onError, what: " + what + "extra: " + extra);
/* 849:    */     
/* 850:514 */     TapjoyVideo.videoNotifierError(3);
/* 851:    */     
/* 852:516 */     this.allowBackKey = true;
/* 853:518 */     if (this.timer != null) {
/* 854:519 */       this.timer.cancel();
/* 855:    */     }
/* 856:523 */     if ((what == 1) && (extra == -1004)) {
/* 857:524 */       return true;
/* 858:    */     }
/* 859:526 */     return false;
/* 860:    */   }
/* 861:    */   
/* 862:    */   public void onCompletion(MediaPlayer mp)
/* 863:    */   {
/* 864:533 */     TapjoyLog.i("VideoView", "onCompletion");
/* 865:535 */     if (this.timer != null) {
/* 866:536 */       this.timer.cancel();
/* 867:    */     }
/* 868:538 */     showVideoCompletionScreen();
/* 869:540 */     if (!videoError)
/* 870:    */     {
/* 871:542 */       TapjoyVideo.videoNotifierComplete();
/* 872:    */       
/* 873:544 */       new Thread(new Runnable()
/* 874:    */       {
/* 875:    */         public void run()
/* 876:    */         {
/* 877:549 */           if (TapjoyVideoView.this.clickRequestSuccess) {
/* 878:550 */             TapjoyConnectCore.getInstance().actionComplete(TapjoyVideoView.videoData.offerID);
/* 879:    */           }
/* 880:    */         }
/* 881:    */       }).start();
/* 882:    */     }
/* 883:556 */     videoError = false;
/* 884:557 */     this.allowBackKey = true;
/* 885:    */   }
/* 886:    */   
/* 887:    */   public boolean onKeyDown(int keyCode, KeyEvent event)
/* 888:    */   {
/* 889:564 */     if (keyCode == 4)
/* 890:    */     {
/* 891:567 */       if ((!this.allowBackKey) && (this.cancelMessage != null) && (this.cancelMessage.length() > 0))
/* 892:    */       {
/* 893:571 */         this.seekTime = this.videoView.getCurrentPosition();
/* 894:572 */         this.videoView.pause();
/* 895:    */         
/* 896:574 */         this.dialogShowing = true;
/* 897:575 */         showDialog(0);
/* 898:    */         
/* 899:577 */         TapjoyLog.i("VideoView", "PAUSE VIDEO time: " + this.seekTime);
/* 900:578 */         TapjoyLog.i("VideoView", "currentPosition: " + this.videoView.getCurrentPosition());
/* 901:579 */         TapjoyLog.i("VideoView", "duration: " + this.videoView.getDuration() + ", elapsed: " + (this.videoView.getDuration() - this.videoView.getCurrentPosition()));
/* 902:580 */         return true;
/* 903:    */       }
/* 904:586 */       if (this.videoView.isPlaying())
/* 905:    */       {
/* 906:588 */         this.videoView.stopPlayback();
/* 907:589 */         showVideoCompletionScreen();
/* 908:591 */         if (this.timer != null) {
/* 909:592 */           this.timer.cancel();
/* 910:    */         }
/* 911:594 */         return true;
/* 912:    */       }
/* 913:    */     }
/* 914:599 */     return super.onKeyDown(keyCode, event);
/* 915:    */   }
/* 916:    */   
/* 917:    */   protected Dialog onCreateDialog(int id)
/* 918:    */   {
/* 919:605 */     TapjoyLog.i("VideoView", "dialog onCreateDialog");
/* 920:608 */     if (!this.dialogShowing) {
/* 921:609 */       return this.dialog;
/* 922:    */     }
/* 923:612 */     switch (id)
/* 924:    */     {
/* 925:    */     case 0: 
/* 926:615 */       this.dialog = new AlertDialog.Builder(this).setTitle("Cancel Video?").setMessage(this.cancelMessage).setNegativeButton("End", new DialogInterface.OnClickListener()
/* 927:    */       {
/* 928:    */         public void onClick(DialogInterface dialog, int whichButton)
/* 929:    */         {
/* 930:621 */           TapjoyVideoView.this.finishWithResult(false);
/* 931:    */         }
/* 932:621 */       }).setPositiveButton("Resume", new DialogInterface.OnClickListener()
/* 933:    */       {
/* 934:    */         public void onClick(DialogInterface dialog, int whichButton)
/* 935:    */         {
/* 936:628 */           dialog.dismiss();
/* 937:    */           
/* 938:630 */           TapjoyVideoView.this.videoView.seekTo(TapjoyVideoView.this.seekTime);
/* 939:631 */           TapjoyVideoView.this.videoView.start();
/* 940:    */           
/* 941:633 */           TapjoyVideoView.this.dialogShowing = false;
/* 942:    */           
/* 943:635 */           TapjoyLog.i("VideoView", "RESUME VIDEO time: " + TapjoyVideoView.this.seekTime);
/* 944:636 */           TapjoyLog.i("VideoView", "currentPosition: " + TapjoyVideoView.this.videoView.getCurrentPosition());
/* 945:637 */           TapjoyLog.i("VideoView", "duration: " + TapjoyVideoView.this.videoView.getDuration() + ", elapsed: " + (TapjoyVideoView.this.videoView.getDuration() - TapjoyVideoView.this.videoView.getCurrentPosition()));
/* 946:    */         }
/* 947:641 */       }).create();
/* 948:642 */       this.dialog.setOnCancelListener(new DialogInterface.OnCancelListener()
/* 949:    */       {
/* 950:    */         public void onCancel(DialogInterface dialog)
/* 951:    */         {
/* 952:647 */           TapjoyLog.i("VideoView", "dialog onCancel");
/* 953:    */           
/* 954:    */ 
/* 955:650 */           dialog.dismiss();
/* 956:651 */           TapjoyVideoView.this.videoView.seekTo(TapjoyVideoView.this.seekTime);
/* 957:652 */           TapjoyVideoView.this.videoView.start();
/* 958:    */           
/* 959:654 */           TapjoyVideoView.this.dialogShowing = false;
/* 960:    */         }
/* 961:656 */       });
/* 962:657 */       this.dialog.show();
/* 963:658 */       this.dialogShowing = true;
/* 964:659 */       break;
/* 965:    */     case 1: 
/* 966:661 */       this.dialog = new AlertDialog.Builder(this).setTitle("Network Connection Lost").setMessage(this.connectivityMessage).setPositiveButton("Okay", new DialogInterface.OnClickListener()
/* 967:    */       {
/* 968:    */         public void onClick(DialogInterface dialog, int whichButton)
/* 969:    */         {
/* 970:667 */           dialog.dismiss();
/* 971:668 */           TapjoyVideoView.this.dialogShowing = false;
/* 972:669 */           TapjoyVideoView.this.finishWithResult(false);
/* 973:    */         }
/* 974:673 */       }).create();
/* 975:674 */       this.dialog.setOnCancelListener(new DialogInterface.OnCancelListener()
/* 976:    */       {
/* 977:    */         public void onCancel(DialogInterface dialog)
/* 978:    */         {
/* 979:679 */           TapjoyLog.i("VideoView", "dialog onCancel");
/* 980:680 */           dialog.dismiss();
/* 981:681 */           TapjoyVideoView.this.dialogShowing = false;
/* 982:682 */           TapjoyVideoView.this.finishWithResult(false);
/* 983:    */         }
/* 984:684 */       });
/* 985:685 */       this.dialog.show();
/* 986:686 */       this.dialogShowing = true;
/* 987:687 */       break;
/* 988:    */     default: 
/* 989:689 */       this.dialog = null;
/* 990:    */     }
/* 991:691 */     return this.dialog;
/* 992:    */   }
/* 993:    */   
/* 994:    */   private class TapjoyVideoBroadcastReceiver
/* 995:    */     extends BroadcastReceiver
/* 996:    */   {
/* 997:    */     private TapjoyVideoBroadcastReceiver() {}
/* 998:    */     
/* 999:    */     public void onReceive(Context context, Intent intent)
/* :00:    */     {
/* :01:701 */       boolean noConnectivity = intent.getBooleanExtra("noConnectivity", false);
/* :02:703 */       if (noConnectivity)
/* :03:    */       {
/* :04:704 */         TapjoyVideoView.this.videoView.pause();
/* :05:705 */         TapjoyVideoView.this.dialogShowing = true;
/* :06:706 */         TapjoyVideoView.this.showDialog(1);
/* :07:707 */         TapjoyLog.i("VideoView", "No network connectivity during video playback");
/* :08:    */       }
/* :09:    */     }
/* :10:    */   }
/* :11:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyVideoView
 * JD-Core Version:    0.7.0.1
 */