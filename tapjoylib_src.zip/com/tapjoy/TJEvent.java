/*   1:    */ package com.tapjoy;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.content.Intent;
/*   5:    */ import android.util.Log;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.Map;
/*   8:    */ import java.util.UUID;
/*   9:    */ 
/*  10:    */ public class TJEvent
/*  11:    */ {
/*  12:    */   private TJEventCallback callback;
/*  13:    */   private TJEventData eventData;
/*  14:    */   private Map<String, String> eventParams;
/*  15:    */   private Map<String, String> urlParams;
/*  16:    */   private Context context;
/*  17: 40 */   private boolean contentShown = false;
/*  18: 45 */   private boolean contentAvailable = false;
/*  19: 50 */   private boolean autoShowContent = true;
/*  20:    */   private static final String TAG = "TJEvent";
/*  21:    */   
/*  22:    */   public TJEvent(Context c, String eventName, TJEventCallback cb)
/*  23:    */   {
/*  24: 62 */     this(c, eventName, null, cb);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public TJEvent(Context c, String eventName, String value, TJEventCallback cb)
/*  28:    */   {
/*  29: 74 */     this.context = c;
/*  30: 75 */     this.callback = cb;
/*  31:    */     
/*  32: 77 */     this.eventData = new TJEventData();
/*  33: 78 */     this.eventData.name = eventName;
/*  34: 79 */     this.eventData.value = value;
/*  35: 80 */     this.eventData.guid = UUID.randomUUID().toString();
/*  36: 83 */     while (TJEventManager.get(this.eventData.guid) != null) {
/*  37: 85 */       this.eventData.guid = UUID.randomUUID().toString();
/*  38:    */     }
/*  39: 89 */     TJEventManager.put(this.eventData.guid, this);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public TJEventCallback getCallback()
/*  43:    */   {
/*  44: 98 */     return this.callback;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void enableAutoPresent(boolean autoPresent)
/*  48:    */   {
/*  49:111 */     this.autoShowContent = autoPresent;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public String getGUID()
/*  53:    */   {
/*  54:121 */     return this.eventData.guid;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public String getName()
/*  58:    */   {
/*  59:131 */     return this.eventData.name;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void send()
/*  63:    */   {
/*  64:139 */     this.contentShown = false;
/*  65:142 */     if (this.callback == null) {
/*  66:144 */       Log.e("TJEvent", "TJEventSendCallback is null");
/*  67:    */     }
/*  68:148 */     if ((TapjoyConnectCore.getInstance() == null) || (!TapjoyConnectCore.getInstance().isInitialized()))
/*  69:    */     {
/*  70:150 */       Log.e("TJEvent", "ERROR -- SDK not initialized -- requestTapjoyConnect must be called first");
/*  71:152 */       if (this.callback != null) {
/*  72:153 */         this.callback.sendEventFail(this, new TJError(0, "SDK not initialized -- requestTapjoyConnect must be called first"));
/*  73:    */       }
/*  74:154 */       return;
/*  75:    */     }
/*  76:158 */     if (this.context == null)
/*  77:    */     {
/*  78:160 */       if (this.callback != null) {
/*  79:161 */         this.callback.sendEventFail(this, new TJError(0, "Context is null -- TJEvent requires a valid Context."));
/*  80:    */       }
/*  81:163 */       return;
/*  82:    */     }
/*  83:167 */     if ((this.eventData.name == null) || (this.eventData.name.length() == 0))
/*  84:    */     {
/*  85:169 */       if (this.callback != null) {
/*  86:170 */         this.callback.sendEventFail(this, new TJError(0, "Invalid eventName -- TJEvent requires a valid eventName."));
/*  87:    */       }
/*  88:172 */       return;
/*  89:    */     }
/*  90:175 */     String path = "https://events.tapjoy.com/events?";
/*  91:176 */     this.urlParams = TapjoyConnectCore.getGenericURLParams();
/*  92:178 */     if (this.eventParams == null) {
/*  93:180 */       this.eventParams = new HashMap();
/*  94:    */     }
/*  95:183 */     TapjoyUtil.safePut(this.eventParams, "event_name", this.eventData.name, true);
/*  96:184 */     TapjoyUtil.safePut(this.eventParams, "event_value", this.eventData.value, true);
/*  97:    */     
/*  98:186 */     this.urlParams.putAll(this.eventParams);
/*  99:187 */     this.urlParams.putAll(TapjoyConnectCore.getTimeStampAndVerifierParams());
/* 100:    */     
/* 101:189 */     this.eventData.url = path;
/* 102:190 */     this.eventData.baseURL = path.substring(0, path.indexOf('/', path.indexOf("//") + ("//".length() + 1)));
/* 103:    */     
/* 104:    */ 
/* 105:193 */     new Thread()
/* 106:    */     {
/* 107:    */       public void run()
/* 108:    */       {
/* 109:198 */         TapjoyURLConnection tapjoyConnection = new TapjoyURLConnection();
/* 110:199 */         TapjoyHttpURLResponse result = tapjoyConnection.getResponseFromURL(TJEvent.this.eventData.url, TJEvent.this.urlParams);
/* 111:    */         
/* 112:201 */         TJEvent.this.eventData.httpStatusCode = result.statusCode;
/* 113:202 */         TJEvent.this.eventData.httpResponse = result.response;
/* 114:204 */         if (result != null) {
/* 115:206 */           if (TJEvent.this.callback != null) {
/* 116:208 */             switch (result.statusCode)
/* 117:    */             {
/* 118:    */             case 200: 
/* 119:212 */               TJEvent.this.contentAvailable = true;
/* 120:213 */               TJEvent.this.callback.sendEventCompleted(TJEvent.this, TJEvent.this.contentAvailable);
/* 121:216 */               if (TJEvent.this.autoShowContent) {
/* 122:217 */                 TJEvent.this.showContent();
/* 123:    */               }
/* 124:    */               break;
/* 125:    */             case 0: 
/* 126:222 */               TJEvent.this.callback.sendEventFail(TJEvent.this, new TJError(result.statusCode, result.response));
/* 127:    */               
/* 128:    */ 
/* 129:225 */               TJEvent.this.urlParams.remove("timestamp");
/* 130:226 */               TJEvent.this.urlParams.remove("verifier");
/* 131:227 */               TapjoyConnectCore.saveOfflineLog(TJEvent.this.eventData.url + TapjoyUtil.convertURLParams(TJEvent.this.urlParams, false));
/* 132:228 */               break;
/* 133:    */             default: 
/* 134:232 */               TJEvent.this.callback.sendEventCompleted(TJEvent.this, TJEvent.this.contentAvailable);
/* 135:    */             }
/* 136:    */           }
/* 137:    */         }
/* 138:    */       }
/* 139:    */     }.start();
/* 140:    */   }
/* 141:    */   
/* 142:    */   public void setParameters(Map<String, String> parameters)
/* 143:    */   {
/* 144:247 */     this.eventParams = parameters;
/* 145:    */   }
/* 146:    */   
/* 147:    */   public void showContent()
/* 148:    */   {
/* 149:257 */     if (!this.contentAvailable)
/* 150:    */     {
/* 151:259 */       Log.e("TJEvent", "cannot show content for non-200 send event");
/* 152:260 */       return;
/* 153:    */     }
/* 154:264 */     if (this.callback == null)
/* 155:    */     {
/* 156:266 */       Log.e("TJEvent", "TJEventShowCallback cb is null");
/* 157:267 */       return;
/* 158:    */     }
/* 159:271 */     if (this.contentShown)
/* 160:    */     {
/* 161:273 */       Log.e("TJEvent", "Content has already been shown for event " + this.eventData.name);
/* 162:274 */       return;
/* 163:    */     }
/* 164:278 */     Intent intent = null;
/* 165:281 */     if (this.eventData.name.equals("tj_legacy_featured_ad"))
/* 166:    */     {
/* 167:284 */       if (this.eventParams.containsKey("featured_app_legacy")) {
/* 168:286 */         intent = new Intent(this.context, TapjoyFeaturedAppWebView.class);
/* 169:    */       } else {
/* 170:291 */         intent = new Intent(this.context, TapjoyFullScreenAdWebView.class);
/* 171:    */       }
/* 172:294 */       intent.putExtra("legacy_view", true);
/* 173:    */     }
/* 174:298 */     else if (this.eventData.name.equals("tj_legacy_reengagement_rewards"))
/* 175:    */     {
/* 176:300 */       intent = new Intent(this.context, TapjoyDailyRewardAdWebView.class);
/* 177:301 */       intent.putExtra("legacy_view", true);
/* 178:    */     }
/* 179:    */     else
/* 180:    */     {
/* 181:306 */       intent = new Intent(this.context, TJAdUnitView.class);
/* 182:    */     }
/* 183:309 */     this.contentShown = true;
/* 184:    */     
/* 185:311 */     intent.putExtra("view_type", 1);
/* 186:312 */     intent.putExtra("tjevent", this.eventData);
/* 187:313 */     intent.setFlags(268435456);
/* 188:314 */     this.context.startActivity(intent);
/* 189:    */   }
/* 190:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TJEvent
 * JD-Core Version:    0.7.0.1
 */