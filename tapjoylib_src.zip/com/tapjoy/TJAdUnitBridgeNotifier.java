package com.tapjoy;

public abstract interface TJAdUnitBridgeNotifier
{
  public abstract void notification(String paramString1, String paramString2);
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TJAdUnitBridgeNotifier
 * JD-Core Version:    0.7.0.1
 */