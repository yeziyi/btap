/*  1:   */ package com.tapjoy;
/*  2:   */ 
/*  3:   */ import java.io.Serializable;
/*  4:   */ 
/*  5:   */ public class TapjoyVideoObject
/*  6:   */   implements Serializable
/*  7:   */ {
/*  8:   */   private static final long serialVersionUID = 1L;
/*  9:   */   public String offerID;
/* 10:   */   public String clickURL;
/* 11:   */   public String videoURL;
/* 12:   */   public String videoAdName;
/* 13:   */   public String currencyName;
/* 14:   */   public String currencyAmount;
/* 15:   */   public String iconURL;
/* 16:   */   public String webviewURL;
/* 17:   */   public String dataLocation;
/* 18:   */   public String[][] buttonData;
/* 19:   */   public int buttonCount;
/* 20:   */   public static final int BUTTON_MAX = 10;
/* 21:   */   
/* 22:   */   public TapjoyVideoObject()
/* 23:   */   {
/* 24:34 */     this.buttonData = new String[10][2];
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void addButton(String name, String url)
/* 28:   */   {
/* 29:39 */     this.buttonData[this.buttonCount][0] = name;
/* 30:40 */     this.buttonData[this.buttonCount][1] = url;
/* 31:41 */     this.buttonCount += 1;
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyVideoObject
 * JD-Core Version:    0.7.0.1
 */