/*  1:   */ package com.tapjoy;
/*  2:   */ 
/*  3:   */ import android.content.res.Configuration;
/*  4:   */ import android.os.AsyncTask;
/*  5:   */ import android.os.Bundle;
/*  6:   */ import com.tapjoy.mraid.view.MraidView;
/*  7:   */ 
/*  8:   */ public class TapjoyDailyRewardAdWebView
/*  9:   */   extends TJAdUnitView
/* 10:   */ {
/* 11:   */   protected void onCreate(Bundle savedInstanceState)
/* 12:   */   {
/* 13:17 */     super.onCreate(savedInstanceState);
/* 14:18 */     TapjoyConnectCore.viewWillOpen(2);
/* 15:19 */     TapjoyConnectCore.viewDidOpen(2);
/* 16:   */   }
/* 17:   */   
/* 18:   */   protected void onDestroy()
/* 19:   */   {
/* 20:25 */     super.onDestroy();
/* 21:27 */     if (isFinishing())
/* 22:   */     {
/* 23:29 */       TapjoyConnectCore.viewWillClose(2);
/* 24:30 */       TapjoyConnectCore.viewDidClose(2);
/* 25:   */     }
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void onConfigurationChanged(Configuration newConfig)
/* 29:   */   {
/* 30:39 */     super.onConfigurationChanged(newConfig);
/* 31:41 */     if (this.webView != null)
/* 32:   */     {
/* 33:45 */       RefreshTask refreshTask = new RefreshTask(null);
/* 34:46 */       refreshTask.execute(new Void[0]);
/* 35:   */     }
/* 36:   */   }
/* 37:   */   
/* 38:   */   private class RefreshTask
/* 39:   */     extends AsyncTask<Void, Void, Boolean>
/* 40:   */   {
/* 41:   */     private RefreshTask() {}
/* 42:   */     
/* 43:   */     protected Boolean doInBackground(Void... params)
/* 44:   */     {
/* 45:   */       try
/* 46:   */       {
/* 47:65 */         Thread.sleep(200L);
/* 48:   */       }
/* 49:   */       catch (InterruptedException e)
/* 50:   */       {
/* 51:69 */         e.printStackTrace();
/* 52:   */       }
/* 53:72 */       return Boolean.valueOf(true);
/* 54:   */     }
/* 55:   */     
/* 56:   */     protected void onPostExecute(Boolean result)
/* 57:   */     {
/* 58:77 */       if (TapjoyDailyRewardAdWebView.this.webView != null) {
/* 59:80 */         TapjoyDailyRewardAdWebView.this.webView.loadUrl("javascript:window.onorientationchange();");
/* 60:   */       }
/* 61:   */     }
/* 62:   */   }
/* 63:   */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyDailyRewardAdWebView
 * JD-Core Version:    0.7.0.1
 */