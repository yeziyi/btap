package com.tapjoy;

/**
 * @deprecated
 */
public abstract interface TapjoyFeaturedAppNotifier
{
  /**
   * @deprecated
   */
  public abstract void getFeaturedAppResponse(TapjoyFeaturedAppObject paramTapjoyFeaturedAppObject);
  
  /**
   * @deprecated
   */
  public abstract void getFeaturedAppResponseFailed(String paramString);
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyFeaturedAppNotifier
 * JD-Core Version:    0.7.0.1
 */