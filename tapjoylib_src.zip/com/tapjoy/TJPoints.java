/*   1:    */ package com.tapjoy;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.content.SharedPreferences;
/*   5:    */ import android.content.SharedPreferences.Editor;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.UUID;
/*   8:    */ import org.w3c.dom.Document;
/*   9:    */ 
/*  10:    */ public class TJPoints
/*  11:    */ {
/*  12:    */   private static TapjoyNotifier tapjoyNotifier;
/*  13:    */   private static TapjoySpendPointsNotifier tapjoySpendPointsNotifier;
/*  14:    */   private static TapjoyAwardPointsNotifier tapjoyAwardPointsNotifier;
/*  15:    */   private static TapjoyEarnedPointsNotifier tapjoyEarnedPointsNotifier;
/*  16: 18 */   String spendTapPoints = null;
/*  17: 19 */   int awardTapPoints = 0;
/*  18:    */   Context context;
/*  19:    */   private static final String TAG = "TapjoyPoints";
/*  20:    */   
/*  21:    */   public TJPoints(Context applicationContext)
/*  22:    */   {
/*  23: 31 */     this.context = applicationContext;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public void saveTapPointsTotal(int total)
/*  27:    */   {
/*  28: 40 */     SharedPreferences settings = this.context.getSharedPreferences("tjcPrefrences", 0);
/*  29:    */     
/*  30:    */ 
/*  31: 43 */     SharedPreferences.Editor editor = settings.edit();
/*  32: 44 */     editor.putInt("last_tap_points", total);
/*  33: 45 */     editor.commit();
/*  34:    */   }
/*  35:    */   
/*  36:    */   public int getLocalTapPointsTotal()
/*  37:    */   {
/*  38: 55 */     SharedPreferences settings = this.context.getSharedPreferences("tjcPrefrences", 0);
/*  39:    */     
/*  40: 57 */     int total = settings.getInt("last_tap_points", -9999);
/*  41: 58 */     return total;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void getTapPoints(TapjoyNotifier notifier)
/*  45:    */   {
/*  46: 68 */     tapjoyNotifier = notifier;
/*  47: 69 */     new Thread(new Runnable()
/*  48:    */     {
/*  49:    */       public void run()
/*  50:    */       {
/*  51: 73 */         boolean returnValue = false;
/*  52:    */         
/*  53:    */ 
/*  54: 76 */         TapjoyHttpURLResponse response = new TapjoyURLConnection().getResponseFromURL(TapjoyConnectCore.getHostURL() + "get_vg_store_items/user_account?", TapjoyConnectCore.getURLParams());
/*  55: 79 */         if (response.response != null) {
/*  56: 81 */           returnValue = TJPoints.this.handleGetPointsResponse(response.response);
/*  57:    */         }
/*  58: 86 */         if (!returnValue) {
/*  59: 87 */           TJPoints.tapjoyNotifier.getUpdatePointsFailed("Failed to retrieve points from server");
/*  60:    */         }
/*  61:    */       }
/*  62:    */     }).start();
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void spendTapPoints(int amount, TapjoySpendPointsNotifier notifier)
/*  66:    */   {
/*  67:100 */     if (amount < 0)
/*  68:    */     {
/*  69:102 */       TapjoyLog.e("TapjoyPoints", "spendTapPoints error: amount must be a positive number");
/*  70:103 */       return;
/*  71:    */     }
/*  72:106 */     this.spendTapPoints = ("" + amount);
/*  73:    */     
/*  74:108 */     tapjoySpendPointsNotifier = notifier;
/*  75:    */     
/*  76:110 */     new Thread(new Runnable()
/*  77:    */     {
/*  78:    */       public void run()
/*  79:    */       {
/*  80:114 */         boolean returnValue = false;
/*  81:    */         
/*  82:    */ 
/*  83:117 */         Map<String, String> urlParams = TapjoyConnectCore.getURLParams();
/*  84:118 */         TapjoyUtil.safePut(urlParams, "tap_points", TJPoints.this.spendTapPoints, true);
/*  85:119 */         TapjoyHttpURLResponse response = new TapjoyURLConnection().getResponseFromURL(TapjoyConnectCore.getHostURL() + "points/spend?", urlParams);
/*  86:122 */         if (response.response != null) {
/*  87:124 */           returnValue = TJPoints.this.handleSpendPointsResponse(response.response);
/*  88:    */         }
/*  89:128 */         if (!returnValue) {
/*  90:129 */           TJPoints.tapjoySpendPointsNotifier.getSpendPointsResponseFailed("Failed to spend points.");
/*  91:    */         }
/*  92:    */       }
/*  93:    */     }).start();
/*  94:    */   }
/*  95:    */   
/*  96:    */   public void awardTapPoints(int amount, TapjoyAwardPointsNotifier notifier)
/*  97:    */   {
/*  98:142 */     if (amount < 0)
/*  99:    */     {
/* 100:144 */       TapjoyLog.e("TapjoyPoints", "spendTapPoints error: amount must be a positive number");
/* 101:145 */       return;
/* 102:    */     }
/* 103:148 */     this.awardTapPoints = amount;
/* 104:    */     
/* 105:150 */     tapjoyAwardPointsNotifier = notifier;
/* 106:    */     
/* 107:152 */     new Thread(new Runnable()
/* 108:    */     {
/* 109:    */       public void run()
/* 110:    */       {
/* 111:156 */         boolean returnValue = false;
/* 112:    */         
/* 113:158 */         String guid = UUID.randomUUID().toString();
/* 114:159 */         long time = System.currentTimeMillis() / 1000L;
/* 115:    */         
/* 116:    */ 
/* 117:162 */         Map<String, String> urlParams = TapjoyConnectCore.getGenericURLParams();
/* 118:163 */         TapjoyUtil.safePut(urlParams, "tap_points", String.valueOf(TJPoints.this.awardTapPoints), true);
/* 119:    */         
/* 120:165 */         TapjoyUtil.safePut(urlParams, "guid", guid, true);
/* 121:166 */         TapjoyUtil.safePut(urlParams, "timestamp", String.valueOf(time), true);
/* 122:167 */         TapjoyUtil.safePut(urlParams, "verifier", TapjoyConnectCore.getAwardPointsVerifier(time, TJPoints.this.awardTapPoints, guid), true);
/* 123:    */         
/* 124:169 */         TapjoyHttpURLResponse response = new TapjoyURLConnection().getResponseFromURL(TapjoyConnectCore.getHostURL() + "points/award?", urlParams);
/* 125:172 */         if (response.response != null) {
/* 126:174 */           returnValue = TJPoints.this.handleAwardPointsResponse(response.response);
/* 127:    */         }
/* 128:178 */         if (!returnValue) {
/* 129:179 */           TJPoints.tapjoyAwardPointsNotifier.getAwardPointsResponseFailed("Failed to award points.");
/* 130:    */         }
/* 131:    */       }
/* 132:    */     }).start();
/* 133:    */   }
/* 134:    */   
/* 135:    */   public void setEarnedPointsNotifier(TapjoyEarnedPointsNotifier notifier)
/* 136:    */   {
/* 137:191 */     tapjoyEarnedPointsNotifier = notifier;
/* 138:    */   }
/* 139:    */   
/* 140:    */   private synchronized boolean handleGetPointsResponse(String response)
/* 141:    */   {
/* 142:203 */     Document document = TapjoyUtil.buildDocument(response);
/* 143:204 */     if (document != null)
/* 144:    */     {
/* 145:206 */       String nodeValue = TapjoyUtil.getNodeTrimValue(document.getElementsByTagName("Success"));
/* 146:209 */       if ((nodeValue != null) && (nodeValue.equals("true")))
/* 147:    */       {
/* 148:213 */         String points = TapjoyUtil.getNodeTrimValue(document.getElementsByTagName("TapPoints"));
/* 149:214 */         String name = TapjoyUtil.getNodeTrimValue(document.getElementsByTagName("CurrencyName"));
/* 150:217 */         if ((points != null) && (name != null)) {
/* 151:    */           try
/* 152:    */           {
/* 153:222 */             int pointTotal = Integer.parseInt(points);
/* 154:223 */             int lastLocalPointTotal = getLocalTapPointsTotal();
/* 155:230 */             if (tapjoyEarnedPointsNotifier != null) {
/* 156:233 */               if (lastLocalPointTotal != -9999) {
/* 157:236 */                 if (pointTotal > lastLocalPointTotal)
/* 158:    */                 {
/* 159:238 */                   TapjoyLog.i("TapjoyPoints", "earned: " + (pointTotal - lastLocalPointTotal));
/* 160:239 */                   tapjoyEarnedPointsNotifier.earnedTapPoints(pointTotal - lastLocalPointTotal);
/* 161:    */                 }
/* 162:    */               }
/* 163:    */             }
/* 164:245 */             saveTapPointsTotal(Integer.parseInt(points));
/* 165:    */             
/* 166:    */ 
/* 167:248 */             tapjoyNotifier.getUpdatePoints(name, Integer.parseInt(points));
/* 168:    */             
/* 169:250 */             return true;
/* 170:    */           }
/* 171:    */           catch (Exception e)
/* 172:    */           {
/* 173:254 */             TapjoyLog.e("TapjoyPoints", "Error parsing XML and calling notifier: " + e.toString());
/* 174:    */           }
/* 175:    */         } else {
/* 176:259 */           TapjoyLog.e("TapjoyPoints", "Invalid XML: Missing tags.");
/* 177:    */         }
/* 178:    */       }
/* 179:    */       else
/* 180:    */       {
/* 181:264 */         TapjoyLog.e("TapjoyPoints", "Invalid XML: Missing <Success> tag.");
/* 182:    */       }
/* 183:    */     }
/* 184:268 */     return false;
/* 185:    */   }
/* 186:    */   
/* 187:    */   private boolean handleSpendPointsResponse(String response)
/* 188:    */   {
/* 189:279 */     String message = "";
/* 190:    */     
/* 191:    */ 
/* 192:282 */     Document document = TapjoyUtil.buildDocument(response);
/* 193:284 */     if (document != null)
/* 194:    */     {
/* 195:286 */       String nodeValue = TapjoyUtil.getNodeTrimValue(document.getElementsByTagName("Success"));
/* 196:289 */       if ((nodeValue != null) && (nodeValue.equals("true")))
/* 197:    */       {
/* 198:293 */         String pointsTotal = TapjoyUtil.getNodeTrimValue(document.getElementsByTagName("TapPoints"));
/* 199:294 */         String currencyName = TapjoyUtil.getNodeTrimValue(document.getElementsByTagName("CurrencyName"));
/* 200:297 */         if ((pointsTotal != null) && (currencyName != null))
/* 201:    */         {
/* 202:303 */           saveTapPointsTotal(Integer.parseInt(pointsTotal));
/* 203:    */           
/* 204:    */ 
/* 205:306 */           tapjoySpendPointsNotifier.getSpendPointsResponse(currencyName, Integer.parseInt(pointsTotal));
/* 206:307 */           return true;
/* 207:    */         }
/* 208:311 */         TapjoyLog.e("TapjoyPoints", "Invalid XML: Missing tags.");
/* 209:    */       }
/* 210:    */       else
/* 211:    */       {
/* 212:316 */         if ((nodeValue != null) && (nodeValue.endsWith("false")))
/* 213:    */         {
/* 214:318 */           message = TapjoyUtil.getNodeTrimValue(document.getElementsByTagName("Message"));
/* 215:319 */           TapjoyLog.i("TapjoyPoints", message);
/* 216:    */           
/* 217:321 */           tapjoySpendPointsNotifier.getSpendPointsResponseFailed(message);
/* 218:322 */           return true;
/* 219:    */         }
/* 220:326 */         TapjoyLog.e("TapjoyPoints", "Invalid XML: Missing <Success> tag.");
/* 221:    */       }
/* 222:    */     }
/* 223:330 */     return false;
/* 224:    */   }
/* 225:    */   
/* 226:    */   private boolean handleAwardPointsResponse(String response)
/* 227:    */   {
/* 228:341 */     String message = "";
/* 229:    */     
/* 230:    */ 
/* 231:344 */     Document document = TapjoyUtil.buildDocument(response);
/* 232:346 */     if (document != null)
/* 233:    */     {
/* 234:348 */       String nodeValue = TapjoyUtil.getNodeTrimValue(document.getElementsByTagName("Success"));
/* 235:351 */       if ((nodeValue != null) && (nodeValue.equals("true")))
/* 236:    */       {
/* 237:355 */         String pointsTotal = TapjoyUtil.getNodeTrimValue(document.getElementsByTagName("TapPoints"));
/* 238:356 */         String currencyName = TapjoyUtil.getNodeTrimValue(document.getElementsByTagName("CurrencyName"));
/* 239:359 */         if ((pointsTotal != null) && (currencyName != null))
/* 240:    */         {
/* 241:365 */           saveTapPointsTotal(Integer.parseInt(pointsTotal));
/* 242:    */           
/* 243:    */ 
/* 244:368 */           tapjoyAwardPointsNotifier.getAwardPointsResponse(currencyName, Integer.parseInt(pointsTotal));
/* 245:369 */           return true;
/* 246:    */         }
/* 247:373 */         TapjoyLog.e("TapjoyPoints", "Invalid XML: Missing tags.");
/* 248:    */       }
/* 249:    */       else
/* 250:    */       {
/* 251:378 */         if ((nodeValue != null) && (nodeValue.endsWith("false")))
/* 252:    */         {
/* 253:380 */           message = TapjoyUtil.getNodeTrimValue(document.getElementsByTagName("Message"));
/* 254:381 */           TapjoyLog.i("TapjoyPoints", message);
/* 255:    */           
/* 256:383 */           tapjoyAwardPointsNotifier.getAwardPointsResponseFailed(message);
/* 257:384 */           return true;
/* 258:    */         }
/* 259:388 */         TapjoyLog.e("TapjoyPoints", "Invalid XML: Missing <Success> tag.");
/* 260:    */       }
/* 261:    */     }
/* 262:392 */     return false;
/* 263:    */   }
/* 264:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TJPoints
 * JD-Core Version:    0.7.0.1
 */