package com.tapjoy;

public class TapjoyDisplayAdSize
{
  public static final String TJC_DISPLAY_AD_SIZE_320X50 = "320x50";
  public static final String TJC_DISPLAY_AD_SIZE_640X100 = "640x100";
  public static final String TJC_DISPLAY_AD_SIZE_768X90 = "768x90";
  /**
   * @deprecated
   */
  public static final String TJC_AD_BANNERSIZE_320X50 = "320x50";
  /**
   * @deprecated
   */
  public static final String TJC_AD_BANNERSIZE_640X100 = "640x100";
  /**
   * @deprecated
   */
  public static final String TJC_AD_BANNERSIZE_768X90 = "768x90";
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyDisplayAdSize
 * JD-Core Version:    0.7.0.1
 */