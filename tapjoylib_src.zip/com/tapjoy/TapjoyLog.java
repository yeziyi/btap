/*   1:    */ package com.tapjoy;
/*   2:    */ 
/*   3:    */ import android.util.Log;
/*   4:    */ import java.util.ArrayList;
/*   5:    */ 
/*   6:    */ public class TapjoyLog
/*   7:    */ {
/*   8: 16 */   private static boolean showLog = false;
/*   9: 17 */   private static boolean saveLog = false;
/*  10:    */   private static final int MAX_STRING_SIZE = 4096;
/*  11:    */   private static ArrayList<String> logHistory;
/*  12:    */   private static final String TAG = "TapjoyLog";
/*  13:    */   
/*  14:    */   public static void enableLogging(boolean enable)
/*  15:    */   {
/*  16: 29 */     Log.i("TapjoyLog", "enableLogging: " + enable);
/*  17: 30 */     showLog = enable;
/*  18:    */   }
/*  19:    */   
/*  20:    */   public static boolean isLoggingEnabled()
/*  21:    */   {
/*  22: 38 */     return showLog;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static void saveLogHistory(boolean save)
/*  26:    */   {
/*  27: 47 */     saveLog = save;
/*  28: 49 */     if (saveLog) {
/*  29: 51 */       logHistory = new ArrayList(1024);
/*  30:    */     } else {
/*  31: 55 */       logHistory = null;
/*  32:    */     }
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static void clearLogHistory()
/*  36:    */   {
/*  37: 64 */     if (logHistory != null) {
/*  38: 65 */       logHistory.clear();
/*  39:    */     }
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static ArrayList<String> getLogHistory()
/*  43:    */   {
/*  44: 74 */     return logHistory;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public static void i(String tag, String msg)
/*  48:    */   {
/*  49: 84 */     if (showLog) {
/*  50: 87 */       if (msg.length() > 4096) {
/*  51: 89 */         for (int i = 0; i <= msg.length() / 4096; i++)
/*  52:    */         {
/*  53: 91 */           int start = i * 4096;
/*  54: 92 */           int end = (i + 1) * 4096;
/*  55: 93 */           end = end > msg.length() ? msg.length() : end;
/*  56: 94 */           Log.i(tag, msg.substring(start, end));
/*  57:    */         }
/*  58:    */       } else {
/*  59: 99 */         Log.i(tag, msg);
/*  60:    */       }
/*  61:    */     }
/*  62:103 */     if (saveLog) {
/*  63:104 */       logHistory.add(msg);
/*  64:    */     }
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static void e(String tag, String msg)
/*  68:    */   {
/*  69:114 */     if (showLog) {
/*  70:115 */       Log.e(tag, msg);
/*  71:    */     }
/*  72:117 */     if (saveLog) {
/*  73:118 */       logHistory.add(msg);
/*  74:    */     }
/*  75:    */   }
/*  76:    */   
/*  77:    */   public static void w(String tag, String msg)
/*  78:    */   {
/*  79:128 */     if (showLog) {
/*  80:129 */       Log.w(tag, msg);
/*  81:    */     }
/*  82:131 */     if (saveLog) {
/*  83:132 */       logHistory.add(msg);
/*  84:    */     }
/*  85:    */   }
/*  86:    */   
/*  87:    */   public static void d(String tag, String msg)
/*  88:    */   {
/*  89:142 */     if (showLog) {
/*  90:143 */       Log.d(tag, msg);
/*  91:    */     }
/*  92:145 */     if (saveLog) {
/*  93:146 */       logHistory.add(msg);
/*  94:    */     }
/*  95:    */   }
/*  96:    */   
/*  97:    */   public static void v(String tag, String msg)
/*  98:    */   {
/*  99:156 */     if (showLog) {
/* 100:157 */       Log.v(tag, msg);
/* 101:    */     }
/* 102:159 */     if (saveLog) {
/* 103:160 */       logHistory.add(msg);
/* 104:    */     }
/* 105:    */   }
/* 106:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyLog
 * JD-Core Version:    0.7.0.1
 */