package com.tapjoy;

/**
 * @deprecated
 */
public class TapjoyFeaturedAppWebView
  extends TapjoyFullScreenAdWebView
{}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyFeaturedAppWebView
 * JD-Core Version:    0.7.0.1
 */