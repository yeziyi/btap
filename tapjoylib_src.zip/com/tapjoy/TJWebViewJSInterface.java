/*   1:    */ package com.tapjoy;
/*   2:    */ 
/*   3:    */ import android.os.AsyncTask;
/*   4:    */ import android.webkit.JavascriptInterface;
/*   5:    */ import android.webkit.WebView;
/*   6:    */ import java.util.ArrayList;
/*   7:    */ import java.util.Map;
/*   8:    */ import org.json.JSONArray;
/*   9:    */ import org.json.JSONObject;
/*  10:    */ 
/*  11:    */ public class TJWebViewJSInterface
/*  12:    */ {
/*  13:    */   WebView webView;
/*  14:    */   TJWebViewJSInterfaceNotifier notifier;
/*  15:    */   private static final String TAG = "TJWebViewJSInterface";
/*  16:    */   
/*  17:    */   public TJWebViewJSInterface(WebView w, TJWebViewJSInterfaceNotifier n)
/*  18:    */   {
/*  19: 26 */     this.webView = w;
/*  20: 27 */     this.notifier = n;
/*  21:    */   }
/*  22:    */   
/*  23:    */   @JavascriptInterface
/*  24:    */   public void dispatchMethod(String params)
/*  25:    */   {
/*  26: 49 */     TapjoyLog.i("TJWebViewJSInterface", "dispatchMethod params: " + params);
/*  27:    */     try
/*  28:    */     {
/*  29: 56 */       JSONObject json = new JSONObject(params);
/*  30: 57 */       JSONObject data = json.getJSONObject("data");
/*  31: 58 */       String method = data.getString("method");
/*  32:    */       
/*  33: 60 */       TapjoyLog.i("TJWebViewJSInterface", "method: " + method);
/*  34: 62 */       if (this.notifier != null) {
/*  35: 63 */         this.notifier.dispatchMethod(method, json);
/*  36:    */       }
/*  37:    */     }
/*  38:    */     catch (Exception e)
/*  39:    */     {
/*  40: 67 */       e.printStackTrace();
/*  41:    */     }
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void callback(ArrayList<?> result, String methodName, String callbackID)
/*  45:    */   {
/*  46:    */     try
/*  47:    */     {
/*  48: 91 */       JSONArray arguments = new JSONArray(result);
/*  49: 92 */       callbackToJavaScript(arguments, methodName, callbackID);
/*  50:    */     }
/*  51:    */     catch (Exception e)
/*  52:    */     {
/*  53: 96 */       e.printStackTrace();
/*  54:    */     }
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void callback(Map<?, ?> result, String methodName, String callbackID)
/*  58:    */   {
/*  59:    */     try
/*  60:    */     {
/*  61:120 */       JSONArray arguments = new JSONArray();
/*  62:121 */       JSONObject resultData = new JSONObject(result);
/*  63:122 */       arguments.put(resultData);
/*  64:123 */       callbackToJavaScript(arguments, methodName, callbackID);
/*  65:    */     }
/*  66:    */     catch (Exception e)
/*  67:    */     {
/*  68:127 */       TapjoyLog.e("TJWebViewJSInterface", "Exception in callback to JS: " + e.toString());
/*  69:128 */       e.printStackTrace();
/*  70:    */     }
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void callbackToJavaScript(Object arguments, String methodName, String callbackID)
/*  74:    */   {
/*  75:    */     try
/*  76:    */     {
/*  77:153 */       JSONObject data = new JSONObject();
/*  78:154 */       data.put("arguments", arguments);
/*  79:156 */       if ((methodName != null) && (methodName.length() > 0)) {
/*  80:157 */         data.put("method", methodName);
/*  81:    */       }
/*  82:159 */       JSONObject message = new JSONObject();
/*  83:162 */       if ((callbackID != null) && (callbackID.length() > 0)) {
/*  84:163 */         message.put("callbackId", callbackID);
/*  85:    */       }
/*  86:165 */       message.put("data", data);
/*  87:    */       
/*  88:167 */       String js = "javascript:AndroidWebViewJavascriptBridge._handleMessageFromAndroid('" + message + "');";
/*  89:    */       
/*  90:    */ 
/*  91:170 */       new LoadJSTask(this.webView).execute(new String[] { js });
/*  92:    */       
/*  93:172 */       TapjoyLog.i("TJWebViewJSInterface", "sendToJS: " + js);
/*  94:    */     }
/*  95:    */     catch (Exception e)
/*  96:    */     {
/*  97:176 */       TapjoyLog.e("TJWebViewJSInterface", "Exception in callback to JS: " + e.toString());
/*  98:177 */       e.printStackTrace();
/*  99:    */     }
/* 100:    */   }
/* 101:    */   
/* 102:    */   private class LoadJSTask
/* 103:    */     extends AsyncTask<String, Void, String>
/* 104:    */   {
/* 105:    */     WebView webView;
/* 106:    */     
/* 107:    */     public LoadJSTask(WebView w)
/* 108:    */     {
/* 109:190 */       this.webView = w;
/* 110:    */     }
/* 111:    */     
/* 112:    */     protected String doInBackground(String... params)
/* 113:    */     {
/* 114:195 */       return params[0];
/* 115:    */     }
/* 116:    */     
/* 117:    */     protected void onPostExecute(String result)
/* 118:    */     {
/* 119:201 */       if (this.webView != null) {
/* 120:202 */         this.webView.loadUrl(result);
/* 121:    */       }
/* 122:    */     }
/* 123:    */   }
/* 124:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TJWebViewJSInterface
 * JD-Core Version:    0.7.0.1
 */