package com.tapjoy;

public abstract interface TapjoyFullScreenAdNotifier
{
  public abstract void getFullScreenAdResponse();
  
  public abstract void getFullScreenAdResponseFailed(int paramInt);
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyFullScreenAdNotifier
 * JD-Core Version:    0.7.0.1
 */