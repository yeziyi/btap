/*   1:    */ package com.tapjoy;
/*   2:    */ 
/*   3:    */ import android.annotation.SuppressLint;
/*   4:    */ import android.annotation.TargetApi;
/*   5:    */ import android.app.Activity;
/*   6:    */ import android.app.AlertDialog;
/*   7:    */ import android.app.AlertDialog.Builder;
/*   8:    */ import android.content.DialogInterface;
/*   9:    */ import android.content.DialogInterface.OnClickListener;
/*  10:    */ import android.content.Intent;
/*  11:    */ import android.content.res.AssetManager;
/*  12:    */ import android.content.res.Configuration;
/*  13:    */ import android.graphics.Bitmap;
/*  14:    */ import android.graphics.BitmapFactory;
/*  15:    */ import android.graphics.BitmapFactory.Options;
/*  16:    */ import android.graphics.drawable.ColorDrawable;
/*  17:    */ import android.graphics.drawable.Drawable;
/*  18:    */ import android.net.ConnectivityManager;
/*  19:    */ import android.net.NetworkInfo;
/*  20:    */ import android.os.Build.VERSION;
/*  21:    */ import android.os.Bundle;
/*  22:    */ import android.util.Log;
/*  23:    */ import android.view.KeyEvent;
/*  24:    */ import android.view.View;
/*  25:    */ import android.view.View.OnClickListener;
/*  26:    */ import android.view.ViewGroup;
/*  27:    */ import android.view.ViewGroup.LayoutParams;
/*  28:    */ import android.view.Window;
/*  29:    */ import android.webkit.ConsoleMessage;
/*  30:    */ import android.webkit.WebSettings;
/*  31:    */ import android.webkit.WebView;
/*  32:    */ import android.widget.ImageButton;
/*  33:    */ import android.widget.ProgressBar;
/*  34:    */ import android.widget.RelativeLayout;
/*  35:    */ import android.widget.RelativeLayout.LayoutParams;
/*  36:    */ import com.tapjoy.mraid.listener.MraidViewListener;
/*  37:    */ import com.tapjoy.mraid.view.MraidView;
/*  38:    */ import java.io.InputStream;
/*  39:    */ import java.lang.reflect.Method;
/*  40:    */ import java.net.URL;
/*  41:    */ import java.util.HashMap;
/*  42:    */ import java.util.Map;
/*  43:    */ import java.util.Timer;
/*  44:    */ import java.util.TimerTask;
/*  45:    */ import java.util.jar.JarEntry;
/*  46:    */ import java.util.jar.JarFile;
/*  47:    */ 
/*  48:    */ @SuppressLint({"SetJavaScriptEnabled"})
/*  49:    */ public class TJAdUnitView
/*  50:    */   extends Activity
/*  51:    */ {
/*  52:    */   protected RelativeLayout layout;
/*  53:    */   protected MraidView webView;
/*  54:    */   protected String offersURL;
/*  55:    */   protected String url;
/*  56:    */   protected boolean pauseCalled;
/*  57:    */   protected boolean skipOfferWall;
/*  58:    */   private int viewType;
/*  59:    */   private TJEventData eventData;
/*  60:    */   private TJEvent event;
/*  61:    */   protected TJAdUnitJSBridge bridge;
/*  62:    */   private String callbackID;
/*  63:    */   private boolean isLegacyView;
/*  64:    */   private ProgressBar progressBar;
/*  65:    */   protected int historyIndex;
/*  66:    */   protected boolean redirectedActivity;
/*  67:    */   private static final String TAG = "TJAdUnitView";
/*  68:    */   private static final int CLOSE_BUTTON_OFFSET = 10;
/*  69:    */   private String connectivityErrorMessage;
/*  70:    */   
/*  71:    */   public TJAdUnitView()
/*  72:    */   {
/*  73: 51 */     this.layout = null;
/*  74: 52 */     this.webView = null;
/*  75: 53 */     this.offersURL = null;
/*  76: 54 */     this.url = null;
/*  77: 55 */     this.pauseCalled = false;
/*  78: 56 */     this.skipOfferWall = false;
/*  79:    */     
/*  80: 58 */     this.viewType = 0;
/*  81:    */     
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85: 63 */     this.isLegacyView = false;
/*  86:    */     
/*  87:    */ 
/*  88:    */ 
/*  89: 67 */     this.historyIndex = 0;
/*  90:    */     
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96: 74 */     this.connectivityErrorMessage = "A connection error occurred loading this content.";
/*  97:    */   }
/*  98:    */   
/*  99:    */   protected void onCreate(Bundle savedInstanceState)
/* 100:    */   {
/* 101: 79 */     if (Build.VERSION.SDK_INT < 11)
/* 102:    */     {
/* 103: 80 */       setTheme(16973839);
/* 104:    */     }
/* 105:    */     else
/* 106:    */     {
/* 107: 83 */       requestWindowFeature(1);
/* 108: 84 */       getWindow().setFlags(1024, 1024);
/* 109:    */     }
/* 110: 87 */     TapjoyLog.i("TJAdUnitView", "TJAdUnitView onCreate: " + savedInstanceState);
/* 111: 88 */     super.onCreate(savedInstanceState);
/* 112:    */     
/* 113: 90 */     initUI();
/* 114:    */   }
/* 115:    */   
/* 116:    */   protected void initUI()
/* 117:    */   {
/* 118: 96 */     TapjoyLog.i("TJAdUnitView", "initUI");
/* 119: 97 */     boolean loadURL = false;
/* 120: 98 */     String html = null;
/* 121: 99 */     String baseURL = null;
/* 122:    */     
/* 123:101 */     Bundle extras = getIntent().getExtras();
/* 124:104 */     if (extras != null)
/* 125:    */     {
/* 126:107 */       if (extras.getString("DISPLAY_AD_URL") != null)
/* 127:    */       {
/* 128:109 */         this.skipOfferWall = true;
/* 129:110 */         this.offersURL = extras.getString("DISPLAY_AD_URL");
/* 130:    */       }
/* 131:114 */       else if (extras.getSerializable("URL_PARAMS") != null)
/* 132:    */       {
/* 133:116 */         this.skipOfferWall = false;
/* 134:117 */         Map<String, String> urlParams = null;
/* 135:118 */         urlParams = (HashMap)extras.getSerializable("URL_PARAMS");
/* 136:    */         
/* 137:120 */         TapjoyLog.i("TJAdUnitView", "urlParams: " + urlParams);
/* 138:    */         
/* 139:    */ 
/* 140:123 */         this.offersURL = (TapjoyConnectCore.getHostURL() + "get_offers/webpage?" + TapjoyUtil.convertURLParams(urlParams, false));
/* 141:    */       }
/* 142:126 */       this.eventData = ((TJEventData)extras.getSerializable("tjevent"));
/* 143:128 */       if (this.eventData != null) {
/* 144:129 */         this.event = TJEventManager.get(this.eventData.guid);
/* 145:    */       }
/* 146:131 */       this.viewType = extras.getInt("view_type");
/* 147:    */       
/* 148:133 */       html = extras.getString("html");
/* 149:134 */       baseURL = extras.getString("base_url");
/* 150:135 */       this.url = extras.getString("url");
/* 151:136 */       this.callbackID = extras.getString("callback_id");
/* 152:137 */       this.isLegacyView = extras.getBoolean("legacy_view");
/* 153:141 */       if (this.webView == null)
/* 154:    */       {
/* 155:143 */         this.webView = new MraidView(this);
/* 156:144 */         this.webView.getSettings().setJavaScriptEnabled(true);
/* 157:    */         
/* 158:146 */         this.webView.setListener(new TJAdUnitViewListener(null));
/* 159:149 */         if (this.viewType == 1)
/* 160:    */         {
/* 161:151 */           if (this.event != null) {
/* 162:152 */             this.webView.loadDataWithBaseURL(this.eventData.baseURL, this.eventData.httpResponse, "text/html", "utf-8", null);
/* 163:    */           }
/* 164:156 */           this.webView.setVisibility(4);
/* 165:    */           
/* 166:    */ 
/* 167:159 */           this.event.getCallback().contentDidShow(this.event);
/* 168:    */         }
/* 169:    */         else
/* 170:    */         {
/* 171:165 */           if ((html != null) && (html.length() > 0))
/* 172:    */           {
/* 173:167 */             TapjoyLog.i("TJAdUnitView", "HTML data");
/* 174:169 */             if (this.isLegacyView) {
/* 175:170 */               this.webView.loadDataWithBaseURL(baseURL, html, "text/html", "utf-8", null);
/* 176:    */             } else {
/* 177:172 */               this.webView.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
/* 178:    */             }
/* 179:    */           }
/* 180:176 */           else if (this.url != null)
/* 181:    */           {
/* 182:178 */             TapjoyLog.i("TJAdUnitView", "Load URL: " + this.url);
/* 183:179 */             this.webView.loadUrl(this.url);
/* 184:    */           }
/* 185:183 */           else if (this.offersURL != null)
/* 186:    */           {
/* 187:185 */             TapjoyLog.i("TJAdUnitView", "Load Offer Wall URL");
/* 188:186 */             this.webView.loadUrl(this.offersURL);
/* 189:    */           }
/* 190:189 */           loadURL = true;
/* 191:    */         }
/* 192:193 */         this.bridge = new TJAdUnitJSBridge(this, this.webView, this.eventData);
/* 193:196 */         if (Build.VERSION.SDK_INT >= 11) {
/* 194:197 */           getWindow().setFlags(16777216, 16777216);
/* 195:    */         }
/* 196:200 */         getWindow().setBackgroundDrawable(new ColorDrawable(1610612736));
/* 197:    */         
/* 198:    */ 
/* 199:203 */         ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(-1, -1);
/* 200:204 */         this.layout = new RelativeLayout(this);
/* 201:205 */         this.layout.setLayoutParams(params);
/* 202:208 */         if (this.viewType == 1)
/* 203:    */         {
/* 204:210 */           this.layout.setBackgroundColor(0);
/* 205:211 */           this.layout.getBackground().setAlpha(0);
/* 206:    */         }
/* 207:    */         else
/* 208:    */         {
/* 209:216 */           this.layout.setBackgroundColor(-1);
/* 210:217 */           this.layout.getBackground().setAlpha(255);
/* 211:    */         }
/* 212:220 */         this.webView.setLayoutParams(params);
/* 213:223 */         if (this.webView.getParent() != null) {
/* 214:224 */           ((ViewGroup)this.webView.getParent()).removeView(this.webView);
/* 215:    */         }
/* 216:227 */         this.layout.addView(this.webView, -1, -1);
/* 217:228 */         setContentView(this.layout);
/* 218:232 */         if ((this.isLegacyView) && (loadURL))
/* 219:    */         {
/* 220:235 */           this.progressBar = new ProgressBar(this, null, 16842874);
/* 221:236 */           this.progressBar.setVisibility(0);
/* 222:    */           
/* 223:    */ 
/* 224:239 */           RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
/* 225:240 */           layoutParams.addRule(13);
/* 226:241 */           this.progressBar.setLayoutParams(layoutParams);
/* 227:242 */           this.layout.addView(this.progressBar);
/* 228:    */         }
/* 229:246 */         if (!this.webView.isMraid())
/* 230:    */         {
/* 231:248 */           ImageButton closeButton = new ImageButton(this);
/* 232:    */           
/* 233:250 */           closeButton.setImageBitmap(getCloseBitmap());
/* 234:251 */           closeButton.setBackgroundColor(16777215);
/* 235:    */           
/* 236:253 */           closeButton.setOnClickListener(new View.OnClickListener()
/* 237:    */           {
/* 238:    */             public void onClick(View v)
/* 239:    */             {
/* 240:257 */               TJAdUnitView.this.handleClose();
/* 241:    */             }
/* 242:260 */           });
/* 243:261 */           RelativeLayout.LayoutParams closeButtonLayoutParams = new RelativeLayout.LayoutParams(-2, -2);
/* 244:262 */           closeButtonLayoutParams.addRule(10);
/* 245:263 */           closeButtonLayoutParams.addRule(11);
/* 246:264 */           int offset = (int)(-10.0F * TapjoyConnectCore.getDeviceScreenDensityScale());
/* 247:265 */           closeButtonLayoutParams.setMargins(0, offset, offset, 0);
/* 248:    */           
/* 249:267 */           this.layout.addView(closeButton, closeButtonLayoutParams);
/* 250:    */         }
/* 251:    */       }
/* 252:    */     }
/* 253:    */   }
/* 254:    */   
/* 255:    */   private Bitmap getCloseBitmap()
/* 256:    */   {
/* 257:274 */     Bitmap closeBitmap = null;
/* 258:    */     
/* 259:    */ 
/* 260:277 */     BitmapFactory.Options options = new BitmapFactory.Options();
/* 261:278 */     options.inJustDecodeBounds = true;
/* 262:    */     
/* 263:    */ 
/* 264:281 */     byte[] bytes = (byte[])TapjoyUtil.getResource("tj_close_button.png");
/* 265:282 */     if (bytes != null)
/* 266:    */     {
/* 267:283 */       BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
/* 268:284 */       closeBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
/* 269:    */     }
/* 270:288 */     if (closeBitmap == null) {
/* 271:    */       try
/* 272:    */       {
/* 273:291 */         String source = "com/tapjoy/res/tj_close_button.png";
/* 274:292 */         InputStream in = null;
/* 275:293 */         URL url = TJAdUnitView.class.getClassLoader().getResource(source);
/* 276:295 */         if (url == null)
/* 277:    */         {
/* 278:297 */           AssetManager am = getAssets();
/* 279:298 */           in = am.open(source);
/* 280:    */           
/* 281:300 */           BitmapFactory.decodeStream(in, null, options);
/* 282:    */         }
/* 283:    */         else
/* 284:    */         {
/* 285:304 */           String file = url.getFile();
/* 286:305 */           if (file.startsWith("jar:")) {
/* 287:306 */             file = file.substring(4);
/* 288:    */           }
/* 289:308 */           if (file.startsWith("file:")) {
/* 290:309 */             file = file.substring(5);
/* 291:    */           }
/* 292:311 */           int pos = file.indexOf("!");
/* 293:312 */           if (pos > 0) {
/* 294:313 */             file = file.substring(0, pos);
/* 295:    */           }
/* 296:314 */           JarFile jf = new JarFile(file);
/* 297:315 */           JarEntry entry = jf.getJarEntry(source);
/* 298:316 */           in = jf.getInputStream(entry);
/* 299:    */           
/* 300:318 */           BitmapFactory.decodeStream(in, null, options);
/* 301:319 */           in = jf.getInputStream(entry);
/* 302:    */         }
/* 303:322 */         closeBitmap = BitmapFactory.decodeStream(in);
/* 304:323 */         in.close();
/* 305:    */       }
/* 306:    */       catch (Exception e)
/* 307:    */       {
/* 308:325 */         e.printStackTrace();
/* 309:326 */         return null;
/* 310:    */       }
/* 311:    */     }
/* 312:330 */     float scale = TapjoyConnectCore.getDeviceScreenDensityScale();
/* 313:331 */     Bitmap scaledBitmap = Bitmap.createScaledBitmap(closeBitmap, (int)(options.outWidth * scale), (int)(options.outHeight * scale), true);
/* 314:332 */     closeBitmap = scaledBitmap;
/* 315:    */     
/* 316:334 */     return closeBitmap;
/* 317:    */   }
/* 318:    */   
/* 319:    */   public void onConfigurationChanged(Configuration newConfig)
/* 320:    */   {
/* 321:340 */     TapjoyLog.i("TJAdUnitView", "onConfigurationChanged");
/* 322:    */     
/* 323:    */ 
/* 324:    */ 
/* 325:    */ 
/* 326:    */ 
/* 327:346 */     super.onConfigurationChanged(newConfig);
/* 328:    */     
/* 329:    */ 
/* 330:349 */     initUI();
/* 331:    */   }
/* 332:    */   
/* 333:    */   protected void onSaveInstanceState(Bundle outState)
/* 334:    */   {
/* 335:355 */     super.onSaveInstanceState(outState);
/* 336:    */     
/* 337:    */ 
/* 338:358 */     this.webView.saveState(outState);
/* 339:    */   }
/* 340:    */   
/* 341:    */   protected void onRestoreInstanceState(Bundle savedInstanceState)
/* 342:    */   {
/* 343:364 */     super.onRestoreInstanceState(savedInstanceState);
/* 344:    */     
/* 345:    */ 
/* 346:367 */     this.webView.restoreState(savedInstanceState);
/* 347:    */   }
/* 348:    */   
/* 349:    */   public void handleWebViewOnReceivedError(WebView view, int errorCode, String description, String failingUrl)
/* 350:    */   {
/* 351:376 */     TapjoyLog.i("TJAdUnitView", "handleWebViewError");
/* 352:    */     
/* 353:    */ 
/* 354:379 */     AlertDialog dialog = new AlertDialog.Builder(this).setMessage(this.connectivityErrorMessage).setPositiveButton("OK", new DialogInterface.OnClickListener()
/* 355:    */     {
/* 356:    */       public void onClick(DialogInterface dialog, int which)
/* 357:    */       {
/* 358:384 */         dialog.cancel();
/* 359:    */       }
/* 360:386 */     }).create();
/* 361:387 */     dialog.show();
/* 362:    */   }
/* 363:    */   
/* 364:    */   public void handleWebViewOnPageFinished(WebView view, String url)
/* 365:    */   {
/* 366:396 */     TapjoyLog.i("TJAdUnitView", "handleWebViewOnPageFinished");
/* 367:    */   }
/* 368:    */   
/* 369:    */   private class TJAdUnitViewListener
/* 370:    */     implements MraidViewListener
/* 371:    */   {
/* 372:    */     private TJAdUnitViewListener() {}
/* 373:    */     
/* 374:    */     public boolean onResizeClose()
/* 375:    */     {
/* 376:402 */       return false;
/* 377:    */     }
/* 378:    */     
/* 379:    */     public boolean onResize()
/* 380:    */     {
/* 381:405 */       return false;
/* 382:    */     }
/* 383:    */     
/* 384:    */     public boolean onReady()
/* 385:    */     {
/* 386:408 */       return false;
/* 387:    */     }
/* 388:    */     
/* 389:    */     public boolean onExpandClose()
/* 390:    */     {
/* 391:411 */       return false;
/* 392:    */     }
/* 393:    */     
/* 394:    */     public boolean onExpand()
/* 395:    */     {
/* 396:414 */       return false;
/* 397:    */     }
/* 398:    */     
/* 399:    */     public boolean onEventFired()
/* 400:    */     {
/* 401:417 */       return false;
/* 402:    */     }
/* 403:    */     
/* 404:    */     public boolean onClose()
/* 405:    */     {
/* 406:423 */       TJAdUnitView.this.finish();
/* 407:424 */       return false;
/* 408:    */     }
/* 409:    */     
/* 410:    */     public void onReceivedError(WebView view, int errorCode, String description, String failingUrl)
/* 411:    */     {
/* 412:429 */       TJAdUnitView.this.handleWebViewOnReceivedError(view, errorCode, description, failingUrl);
/* 413:    */     }
/* 414:    */     
/* 415:    */     @TargetApi(8)
/* 416:    */     public boolean onConsoleMessage(ConsoleMessage consoleMessage)
/* 417:    */     {
/* 418:439 */       if (TJAdUnitView.this.bridge.shouldClose)
/* 419:    */       {
/* 420:441 */         String[] errors = { "Uncaught", "uncaught", "Error", "error", "not defined" };
/* 421:    */         
/* 422:443 */         TapjoyLog.i("TJAdUnitView", "shouldClose...");
/* 423:446 */         for (String error : errors) {
/* 424:448 */           if (consoleMessage.message().contains(error)) {
/* 425:450 */             TJAdUnitView.this.handleClose();
/* 426:    */           }
/* 427:    */         }
/* 428:    */       }
/* 429:455 */       return true;
/* 430:    */     }
/* 431:    */     
/* 432:    */     public void onPageStarted(WebView view, String url, Bitmap favicon)
/* 433:    */     {
/* 434:461 */       TapjoyLog.i("TJAdUnitView", "onPageStarted: " + url);
/* 435:463 */       if (TJAdUnitView.this.isLegacyView)
/* 436:    */       {
/* 437:465 */         TJAdUnitView.this.progressBar.setVisibility(0);
/* 438:466 */         TJAdUnitView.this.progressBar.bringToFront();
/* 439:    */       }
/* 440:469 */       if (TJAdUnitView.this.bridge != null)
/* 441:    */       {
/* 442:472 */         TJAdUnitView.this.bridge.allowRedirect = true;
/* 443:    */         
/* 444:    */ 
/* 445:475 */         TJAdUnitView.this.bridge.customClose = false;
/* 446:476 */         TJAdUnitView.this.bridge.shouldClose = false;
/* 447:    */       }
/* 448:    */     }
/* 449:    */     
/* 450:    */     public void onPageFinished(WebView view, String url)
/* 451:    */     {
/* 452:483 */       TJAdUnitView.this.handleWebViewOnPageFinished(view, url);
/* 453:486 */       if (TJAdUnitView.this.isLegacyView) {
/* 454:487 */         TJAdUnitView.this.progressBar.setVisibility(8);
/* 455:    */       }
/* 456:489 */       TJAdUnitView.this.bridge.display();
/* 457:492 */       if ((TJAdUnitView.this.webView != null) && (TJAdUnitView.this.webView.isMraid())) {
/* 458:493 */         TJAdUnitView.this.bridge.allowRedirect = false;
/* 459:    */       }
/* 460:    */     }
/* 461:    */     
/* 462:    */     @TargetApi(9)
/* 463:    */     public boolean shouldOverrideUrlLoading(WebView view, String url)
/* 464:    */     {
/* 465:501 */       if (!TJAdUnitView.this.isNetworkAvailable())
/* 466:    */       {
/* 467:502 */         TJAdUnitView.this.handleWebViewOnReceivedError(view, 0, "Connection not properly established", url);
/* 468:503 */         return true;
/* 469:    */       }
/* 470:505 */       TJAdUnitView.this.redirectedActivity = false;
/* 471:    */       
/* 472:507 */       TapjoyLog.i("TJAdUnitView", "interceptURL: " + url);
/* 473:510 */       if ((TJAdUnitView.this.webView != null) && (TJAdUnitView.this.webView.isMraid()) && (url.contains("mraid"))) {
/* 474:512 */         return false;
/* 475:    */       }
/* 476:516 */       if ((TJAdUnitView.this.viewType == 4) && (url.contains("offer_wall")))
/* 477:    */       {
/* 478:518 */         TJAdUnitView.this.finishWithResult("offer_wall");
/* 479:519 */         return true;
/* 480:    */       }
/* 481:523 */       if ((TJAdUnitView.this.viewType == 4) && (url.contains("tjvideo")))
/* 482:    */       {
/* 483:525 */         TJAdUnitView.this.finishWithResult("tjvideo");
/* 484:526 */         return true;
/* 485:    */       }
/* 486:532 */       if (url.startsWith("tjvideo://"))
/* 487:    */       {
/* 488:534 */         TJAdUnitView.this.handleTJVideoURL(url);
/* 489:535 */         return true;
/* 490:    */       }
/* 491:540 */       if (url.contains("showOffers"))
/* 492:    */       {
/* 493:542 */         TapjoyLog.i("TJAdUnitView", "showOffers");
/* 494:543 */         new TJCOffers(TJAdUnitView.this).showOffers(null);
/* 495:544 */         return true;
/* 496:    */       }
/* 497:549 */       if (url.contains("dismiss"))
/* 498:    */       {
/* 499:551 */         TapjoyLog.i("TJAdUnitView", "dismiss");
/* 500:552 */         TJAdUnitView.this.finish();
/* 501:553 */         return true;
/* 502:    */       }
/* 503:558 */       if (url.startsWith("http://ok"))
/* 504:    */       {
/* 505:560 */         TapjoyLog.i("TJAdUnitView", "http://ok");
/* 506:561 */         TJAdUnitView.this.finish();
/* 507:562 */         return true;
/* 508:    */       }
/* 509:568 */       if ((url.contains("ws.tapjoyads.com")) || (url.contains("tjyoutubevideo=true")) || (url.contains(TapjoyConnectCore.getRedirectDomain())) || (url.contains(TapjoyUtil.getRedirectDomain("https://events.tapjoy.com/events?"))))
/* 510:    */       {
/* 511:570 */         TapjoyLog.i("TJAdUnitView", "Open redirecting URL:" + url);
/* 512:571 */         ((MraidView)view).loadUrlStandard(url);
/* 513:572 */         return true;
/* 514:    */       }
/* 515:576 */       if (TJAdUnitView.this.bridge.allowRedirect)
/* 516:    */       {
/* 517:578 */         TJAdUnitView.this.redirectedActivity = true;
/* 518:579 */         return false;
/* 519:    */       }
/* 520:584 */       view.loadUrl(url);
/* 521:585 */       return true;
/* 522:    */     }
/* 523:    */   }
/* 524:    */   
/* 525:    */   private void handleTJVideoURL(String url)
/* 526:    */   {
/* 527:596 */     int index = 0;
/* 528:    */     
/* 529:    */ 
/* 530:    */ 
/* 531:    */ 
/* 532:    */ 
/* 533:    */ 
/* 534:    */ 
/* 535:    */ 
/* 536:605 */     index = url.indexOf("://") + "://".length();
/* 537:    */     
/* 538:607 */     String source = url.substring(index);
/* 539:    */     
/* 540:609 */     Map<String, String> params = TapjoyUtil.convertURLParams(source, true);
/* 541:    */     
/* 542:611 */     String videoID = (String)params.get("video_id");
/* 543:612 */     String amount = (String)params.get("amount");
/* 544:613 */     String currencyName = (String)params.get("currency_name");
/* 545:614 */     String clickURL = (String)params.get("click_url");
/* 546:615 */     String videoCompleteURL = (String)params.get("video_complete_url");
/* 547:616 */     String videoURL = (String)params.get("video_url");
/* 548:    */     
/* 549:618 */     TapjoyLog.i("TJAdUnitView", "video_id: " + videoID);
/* 550:619 */     TapjoyLog.i("TJAdUnitView", "amount: " + amount);
/* 551:620 */     TapjoyLog.i("TJAdUnitView", "currency_name: " + currencyName);
/* 552:621 */     TapjoyLog.i("TJAdUnitView", "click_url: " + clickURL);
/* 553:622 */     TapjoyLog.i("TJAdUnitView", "video_complete_url: " + videoCompleteURL);
/* 554:623 */     TapjoyLog.i("TJAdUnitView", "video_url: " + videoURL);
/* 555:625 */     if (TapjoyVideo.getInstance().startVideo(videoID, currencyName, amount, clickURL, videoCompleteURL, videoURL))
/* 556:    */     {
/* 557:627 */       TapjoyLog.i("TJAdUnitView", "Video started successfully");
/* 558:    */     }
/* 559:    */     else
/* 560:    */     {
/* 561:632 */       TapjoyLog.e("TJAdUnitView", "Unable to play video: " + videoID);
/* 562:633 */       AlertDialog dialog = new AlertDialog.Builder(this).setTitle("").setMessage("Unable to play video.").setPositiveButton("OK", new DialogInterface.OnClickListener()
/* 563:    */       {
/* 564:    */         public void onClick(DialogInterface dialog, int whichButton)
/* 565:    */         {
/* 566:637 */           dialog.dismiss();
/* 567:    */         }
/* 568:    */       }).create();
/* 569:    */       try
/* 570:    */       {
/* 571:643 */         dialog.show();
/* 572:    */       }
/* 573:    */       catch (Exception e)
/* 574:    */       {
/* 575:647 */         TapjoyLog.e("TJAdUnitView", "e: " + e.toString());
/* 576:    */       }
/* 577:    */     }
/* 578:    */   }
/* 579:    */   
/* 580:    */   protected void onDestroy()
/* 581:    */   {
/* 582:655 */     super.onDestroy();
/* 583:    */     
/* 584:657 */     TapjoyLog.i("TJAdUnitView", "onDestroy isFinishing: " + isFinishing());
/* 585:660 */     if (isFinishing())
/* 586:    */     {
/* 587:662 */       if (this.viewType == 1)
/* 588:    */       {
/* 589:665 */         this.bridge.destroy();
/* 590:668 */         if (this.event != null) {
/* 591:669 */           this.event.getCallback().contentDidDisappear(this.event);
/* 592:    */         }
/* 593:670 */         TJEventManager.remove(this.eventData.guid);
/* 594:    */       }
/* 595:673 */       if (this.webView != null)
/* 596:    */       {
/* 597:    */         try
/* 598:    */         {
/* 599:678 */           WebView.class.getMethod("onPause", new Class[0]).invoke(this.webView, new Object[0]);
/* 600:    */         }
/* 601:    */         catch (Exception e) {}
/* 602:    */         try
/* 603:    */         {
/* 604:686 */           this.webView = null;
/* 605:    */         }
/* 606:    */         catch (Exception e) {}
/* 607:    */       }
/* 608:    */     }
/* 609:    */   }
/* 610:    */   
/* 611:    */   protected void onPause()
/* 612:    */   {
/* 613:696 */     super.onPause();
/* 614:697 */     this.pauseCalled = true;
/* 615:    */     try
/* 616:    */     {
/* 617:702 */       WebView.class.getMethod("onPause", new Class[0]).invoke(this.webView, new Object[0]);
/* 618:    */     }
/* 619:    */     catch (Exception e) {}
/* 620:    */   }
/* 621:    */   
/* 622:    */   protected void onResume()
/* 623:    */   {
/* 624:710 */     super.onResume();
/* 625:    */     try
/* 626:    */     {
/* 627:715 */       WebView.class.getMethod("onResume", new Class[0]).invoke(this.webView, new Object[0]);
/* 628:    */     }
/* 629:    */     catch (Exception e) {}
/* 630:719 */     if (this.viewType == 1) {
/* 631:722 */       if (this.bridge.didLaunchOtherActivity)
/* 632:    */       {
/* 633:724 */         TapjoyLog.i("TJAdUnitView", "onResume bridge.didLaunchOtherActivity callbackID: " + this.bridge.otherActivityCallbackID);
/* 634:    */         
/* 635:726 */         this.bridge.invokeJSCallback(this.bridge.otherActivityCallbackID, new Object[] { Boolean.TRUE });
/* 636:727 */         this.bridge.didLaunchOtherActivity = false;
/* 637:    */       }
/* 638:    */     }
/* 639:    */   }
/* 640:    */   
/* 641:    */   public void finish()
/* 642:    */   {
/* 643:737 */     if ((this.viewType != 1) && (this.viewType != 4))
/* 644:    */     {
/* 645:739 */       Intent intent = new Intent();
/* 646:740 */       intent.putExtra("result", Boolean.TRUE);
/* 647:741 */       intent.putExtra("callback_id", this.callbackID);
/* 648:742 */       setResult(-1, intent);
/* 649:    */     }
/* 650:745 */     super.finish();
/* 651:    */   }
/* 652:    */   
/* 653:    */   private void finishWithResult(String result)
/* 654:    */   {
/* 655:750 */     Intent returnIntent = new Intent();
/* 656:751 */     returnIntent.putExtra("result", result);
/* 657:752 */     setResult(-1, returnIntent);
/* 658:753 */     finish();
/* 659:    */   }
/* 660:    */   
/* 661:    */   protected void onActivityResult(int requestCode, int resultCode, Intent data)
/* 662:    */   {
/* 663:759 */     super.onActivityResult(requestCode, resultCode, data);
/* 664:    */     
/* 665:761 */     Log.i("TJAdUnitView", "onActivityResult requestCode:" + requestCode + ", resultCode: " + resultCode);
/* 666:    */     
/* 667:763 */     Bundle extras = null;
/* 668:765 */     if (data != null) {
/* 669:766 */       extras = data.getExtras();
/* 670:    */     }
/* 671:768 */     if ((extras != null) && (extras.getString("callback_id") != null))
/* 672:    */     {
/* 673:770 */       TapjoyLog.i("TJAdUnitView", "onActivityResult extras: " + extras.keySet());
/* 674:    */       
/* 675:772 */       this.bridge.invokeJSCallback(extras.getString("callback_id"), new Object[] { Boolean.valueOf(extras.getBoolean("result")), extras.getString("result_string1"), extras.getString("result_string2") });
/* 676:    */     }
/* 677:    */   }
/* 678:    */   
/* 679:    */   public boolean onKeyDown(int keyCode, KeyEvent event)
/* 680:    */   {
/* 681:779 */     if (keyCode == 4)
/* 682:    */     {
/* 683:781 */       handleClose();
/* 684:782 */       return true;
/* 685:    */     }
/* 686:785 */     return super.onKeyDown(keyCode, event);
/* 687:    */   }
/* 688:    */   
/* 689:    */   public void handleClose()
/* 690:    */   {
/* 691:793 */     if (this.webView.videoPlaying())
/* 692:    */     {
/* 693:794 */       this.webView.videoViewCleanup();
/* 694:795 */       return;
/* 695:    */     }
/* 696:799 */     if (this.bridge.customClose)
/* 697:    */     {
/* 698:801 */       TapjoyLog.i("TJAdUnitView", "customClose");
/* 699:805 */       if (this.bridge.shouldClose)
/* 700:    */       {
/* 701:807 */         finishActivity();
/* 702:    */       }
/* 703:    */       else
/* 704:    */       {
/* 705:811 */         TapjoyLog.i("TJAdUnitView", "closeRequested...");
/* 706:    */         
/* 707:    */ 
/* 708:814 */         this.bridge.closeRequested();
/* 709:    */         
/* 710:    */ 
/* 711:817 */         TimerTask timerTask = new TimerTask()
/* 712:    */         {
/* 713:    */           public void run()
/* 714:    */           {
/* 715:822 */             if (TJAdUnitView.this.bridge.shouldClose)
/* 716:    */             {
/* 717:824 */               TapjoyLog.i("TJAdUnitView", "customClose timeout");
/* 718:825 */               TJAdUnitView.this.finishActivity();
/* 719:    */             }
/* 720:    */           }
/* 721:829 */         };
/* 722:830 */         Timer timer = new Timer();
/* 723:831 */         timer.schedule(timerTask, 1000L);
/* 724:    */       }
/* 725:    */     }
/* 726:    */     else
/* 727:    */     {
/* 728:837 */       finishActivity();
/* 729:    */     }
/* 730:    */   }
/* 731:    */   
/* 732:    */   private void finishActivity()
/* 733:    */   {
/* 734:846 */     if (this.viewType == 4) {
/* 735:849 */       finishWithResult("offer_wall");
/* 736:853 */     } else if (this != null) {
/* 737:854 */       finish();
/* 738:    */     }
/* 739:    */   }
/* 740:    */   
/* 741:    */   protected boolean isNetworkAvailable()
/* 742:    */   {
/* 743:862 */     ConnectivityManager conMgr = (ConnectivityManager)getSystemService("connectivity");
/* 744:863 */     return (conMgr.getActiveNetworkInfo() != null) && (conMgr.getActiveNetworkInfo().isAvailable()) && (conMgr.getActiveNetworkInfo().isConnected());
/* 745:    */   }
/* 746:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TJAdUnitView
 * JD-Core Version:    0.7.0.1
 */