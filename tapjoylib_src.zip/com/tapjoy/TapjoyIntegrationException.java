/* 1:  */ package com.tapjoy;
/* 2:  */ 
/* 3:  */ public class TapjoyIntegrationException
/* 4:  */   extends TapjoyException
/* 5:  */ {
/* 6:  */   public TapjoyIntegrationException(String message)
/* 7:  */   {
/* 8:6 */     super(message);
/* 9:  */   }
/* ::  */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyIntegrationException
 * JD-Core Version:    0.7.0.1
 */