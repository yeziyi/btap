/*  1:   */ package com.tapjoy;
/*  2:   */ 
/*  3:   */ public class TapjoyConnectFlag
/*  4:   */ {
/*  5:   */   public static final String HOST_URL = "TJC_SERVICE_URL";
/*  6:   */   /**
/*  7:   */    * @deprecated
/*  8:   */    */
/*  9:   */   public static final String SHA_2_UDID = "sha_2_udid";
/* 10:   */   public static final String STORE_NAME = "store_name";
/* 11:   */   public static final String DISABLE_VIDEOS = "disable_videos";
/* 12:   */   public static final String VIDEO_CACHE_COUNT = "video_cache_count";
/* 13:   */   public static final String ENABLE_LOGGING = "enable_logging";
/* 14:   */   public static final String USER_ID = "user_id";
/* 15:   */   public static final String DEBUG_DEVICE_ID = "debug_device_id";
/* 16:   */   public static final String DEBUG_HOST_URL = "debug_host_url";
/* 17:   */   public static final String SKIP_INTEGRATIONS_CHECK = "skip_integrations";
/* 18:   */   public static final String STORE_GFAN = "gfan";
/* 19:   */   public static final String STORE_SKT = "skt";
/* 20:84 */   public static final String[] FLAG_ARRAY = { "debug_device_id", "debug_host_url", "sha_2_udid", "store_name", "disable_videos", "video_cache_count", "enable_logging", "user_id" };
/* 21:99 */   public static final String[] STORE_ARRAY = { "gfan", "skt" };
/* 22:   */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyConnectFlag
 * JD-Core Version:    0.7.0.1
 */