/* 1:  */ package com.tapjoy;
/* 2:  */ 
/* 3:  */ public class TapjoyException
/* 4:  */   extends Exception
/* 5:  */ {
/* 6:  */   public TapjoyException(String message)
/* 7:  */   {
/* 8:6 */     super(message);
/* 9:  */   }
/* ::  */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyException
 * JD-Core Version:    0.7.0.1
 */