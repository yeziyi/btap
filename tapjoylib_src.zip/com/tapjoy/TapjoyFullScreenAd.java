/*   1:    */ package com.tapjoy;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.content.Intent;
/*   5:    */ import java.util.Map;
/*   6:    */ 
/*   7:    */ public class TapjoyFullScreenAd
/*   8:    */ {
/*   9:    */   private static TapjoyFeaturedAppNotifier featuredAppNotifier;
/*  10:    */   private static TapjoyFullScreenAdNotifier fullScreenAdNotifier;
/*  11:    */   private Context context;
/*  12:    */   private Map<String, String> legacyFullScreenAdParams;
/*  13: 27 */   private static String baseURL = null;
/*  14: 28 */   private static String htmlResponseData = null;
/*  15:    */   private static final String TAG = "Full Screen Ad";
/*  16:    */   
/*  17:    */   public TapjoyFullScreenAd(Context ctx)
/*  18:    */   {
/*  19: 37 */     this.context = ctx;
/*  20:    */   }
/*  21:    */   
/*  22:    */   /**
/*  23:    */    * @deprecated
/*  24:    */    */
/*  25:    */   public void getFullScreenAd(TapjoyFullScreenAdNotifier notifier)
/*  26:    */   {
/*  27: 47 */     TapjoyLog.i("Full Screen Ad", "getFullScreenAd");
/*  28: 48 */     getFullScreenAd(null, notifier);
/*  29:    */   }
/*  30:    */   
/*  31:    */   /**
/*  32:    */    * @deprecated
/*  33:    */    */
/*  34:    */   public void getFullScreenAd(String currencyID, TapjoyFullScreenAdNotifier notifier)
/*  35:    */   {
/*  36: 59 */     fullScreenAdNotifier = notifier;
/*  37: 60 */     getFullScreenAdLegacy(currencyID);
/*  38:    */   }
/*  39:    */   
/*  40:    */   /**
/*  41:    */    * @deprecated
/*  42:    */    */
/*  43:    */   public void getFeaturedApp(TapjoyFeaturedAppNotifier notifier)
/*  44:    */   {
/*  45: 70 */     TapjoyLog.i("Full Screen Ad", "getFeaturedApp");
/*  46: 71 */     getFeaturedApp(null, notifier);
/*  47:    */   }
/*  48:    */   
/*  49:    */   /**
/*  50:    */    * @deprecated
/*  51:    */    */
/*  52:    */   public void getFeaturedApp(String currencyID, TapjoyFeaturedAppNotifier notifier)
/*  53:    */   {
/*  54: 82 */     featuredAppNotifier = notifier;
/*  55: 83 */     getFullScreenAdLegacy(currencyID);
/*  56:    */   }
/*  57:    */   
/*  58:    */   /**
/*  59:    */    * @deprecated
/*  60:    */    */
/*  61:    */   public void showFullScreenAd()
/*  62:    */   {
/*  63: 94 */     if ((htmlResponseData != null) && (htmlResponseData.length() > 0))
/*  64:    */     {
/*  65: 96 */       Intent intent = new Intent(this.context, TapjoyFullScreenAdWebView.class);
/*  66: 97 */       intent.setFlags(268435456);
/*  67: 98 */       intent.putExtra("html", htmlResponseData);
/*  68: 99 */       intent.putExtra("base_url", baseURL);
/*  69:100 */       intent.putExtra("legacy_view", true);
/*  70:101 */       this.context.startActivity(intent);
/*  71:    */     }
/*  72:    */   }
/*  73:    */   
/*  74:    */   /**
/*  75:    */    * @deprecated
/*  76:    */    */
/*  77:    */   public void showFeaturedAppFullScreenAd()
/*  78:    */   {
/*  79:113 */     if ((htmlResponseData != null) && (htmlResponseData.length() > 0))
/*  80:    */     {
/*  81:115 */       Intent intent = new Intent(this.context, TapjoyFeaturedAppWebView.class);
/*  82:116 */       intent.setFlags(268435456);
/*  83:117 */       intent.putExtra("html", htmlResponseData);
/*  84:118 */       intent.putExtra("base_url", baseURL);
/*  85:119 */       intent.putExtra("legacy_view", true);
/*  86:120 */       this.context.startActivity(intent);
/*  87:    */     }
/*  88:    */   }
/*  89:    */   
/*  90:    */   /**
/*  91:    */    * @deprecated
/*  92:    */    */
/*  93:    */   public void setDisplayCount(int count) {}
/*  94:    */   
/*  95:    */   public void getFullScreenAdLegacy(String currencyID)
/*  96:    */   {
/*  97:137 */     TapjoyLog.i("Full Screen Ad", "Getting Full Screen Ad");
/*  98:    */     
/*  99:139 */     this.legacyFullScreenAdParams = TapjoyConnectCore.getURLParams();
/* 100:140 */     TapjoyUtil.safePut(this.legacyFullScreenAdParams, "currency_id", currencyID, true);
/* 101:141 */     this.legacyFullScreenAdParams.putAll(TapjoyConnectCore.getVideoParams());
/* 102:    */     
/* 103:143 */     new Thread(new Runnable()
/* 104:    */     {
/* 105:    */       public void run()
/* 106:    */       {
/* 107:147 */         TapjoyHttpURLResponse httpResponse = new TapjoyURLConnection().getResponseFromURL(TapjoyConnectCore.getHostURL() + "get_offers/featured.html?", TapjoyFullScreenAd.this.legacyFullScreenAdParams);
/* 108:148 */         TapjoyFullScreenAd.access$102(TapjoyConnectCore.getHostURL());
/* 109:150 */         if (httpResponse != null)
/* 110:    */         {
/* 111:152 */           switch (httpResponse.statusCode)
/* 112:    */           {
/* 113:    */           case 200: 
/* 114:155 */             TapjoyFullScreenAd.access$202(httpResponse.response);
/* 115:157 */             if (TapjoyFullScreenAd.featuredAppNotifier != null) {
/* 116:158 */               TapjoyFullScreenAd.featuredAppNotifier.getFeaturedAppResponse(null);
/* 117:    */             }
/* 118:160 */             if (TapjoyFullScreenAd.fullScreenAdNotifier == null) {
/* 119:    */               break;
/* 120:    */             }
/* 121:161 */             TapjoyFullScreenAd.fullScreenAdNotifier.getFullScreenAdResponse(); break;
/* 122:    */           default: 
/* 123:165 */             if (TapjoyFullScreenAd.featuredAppNotifier != null) {
/* 124:166 */               TapjoyFullScreenAd.featuredAppNotifier.getFeaturedAppResponseFailed("Error retrieving full screen ad data from the server.");
/* 125:    */             }
/* 126:168 */             if (TapjoyFullScreenAd.fullScreenAdNotifier == null) {
/* 127:    */               break;
/* 128:    */             }
/* 129:169 */             TapjoyFullScreenAd.fullScreenAdNotifier.getFullScreenAdResponseFailed(1); break;
/* 130:    */           }
/* 131:    */         }
/* 132:    */         else
/* 133:    */         {
/* 134:175 */           if (TapjoyFullScreenAd.featuredAppNotifier != null) {
/* 135:176 */             TapjoyFullScreenAd.featuredAppNotifier.getFeaturedAppResponseFailed("Error retrieving full screen ad data from the server.");
/* 136:    */           }
/* 137:178 */           if (TapjoyFullScreenAd.fullScreenAdNotifier != null) {
/* 138:179 */             TapjoyFullScreenAd.fullScreenAdNotifier.getFullScreenAdResponseFailed(2);
/* 139:    */           }
/* 140:    */         }
/* 141:    */       }
/* 142:    */     }).start();
/* 143:    */   }
/* 144:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyFullScreenAd
 * JD-Core Version:    0.7.0.1
 */