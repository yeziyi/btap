package com.tapjoy;

import android.view.View;

public abstract interface TapjoyDisplayAdNotifier
{
  public abstract void getDisplayAdResponse(View paramView);
  
  public abstract void getDisplayAdResponseFailed(String paramString);
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyDisplayAdNotifier
 * JD-Core Version:    0.7.0.1
 */