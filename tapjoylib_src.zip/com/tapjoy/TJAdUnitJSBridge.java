/*    1:     */ package com.tapjoy;
/*    2:     */ 
/*    3:     */ import android.annotation.SuppressLint;
/*    4:     */ import android.annotation.TargetApi;
/*    5:     */ import android.app.Activity;
/*    6:     */ import android.app.AlertDialog;
/*    7:     */ import android.app.AlertDialog.Builder;
/*    8:     */ import android.app.ProgressDialog;
/*    9:     */ import android.content.Context;
/*   10:     */ import android.content.DialogInterface;
/*   11:     */ import android.content.DialogInterface.OnClickListener;
/*   12:     */ import android.content.Intent;
/*   13:     */ import android.content.pm.ActivityInfo;
/*   14:     */ import android.content.pm.ApplicationInfo;
/*   15:     */ import android.content.pm.PackageManager;
/*   16:     */ import android.content.pm.ResolveInfo;
/*   17:     */ import android.graphics.drawable.Drawable;
/*   18:     */ import android.location.Criteria;
/*   19:     */ import android.location.Location;
/*   20:     */ import android.location.LocationListener;
/*   21:     */ import android.location.LocationManager;
/*   22:     */ import android.net.Uri;
/*   23:     */ import android.os.AsyncTask;
/*   24:     */ import android.os.Build.VERSION;
/*   25:     */ import android.os.Bundle;
/*   26:     */ import android.view.Display;
/*   27:     */ import android.view.View;
/*   28:     */ import android.view.ViewGroup;
/*   29:     */ import android.view.ViewGroup.LayoutParams;
/*   30:     */ import android.view.WindowManager;
/*   31:     */ import android.webkit.WebSettings;
/*   32:     */ import android.webkit.WebView;
/*   33:     */ import android.widget.RelativeLayout;
/*   34:     */ import com.tapjoy.mraid.view.MraidView;
/*   35:     */ import com.tapjoy.mraid.view.MraidView.PLACEMENT_TYPE;
/*   36:     */ import java.io.File;
/*   37:     */ import java.io.InputStream;
/*   38:     */ import java.io.OutputStream;
/*   39:     */ import java.lang.reflect.Method;
/*   40:     */ import java.net.URL;
/*   41:     */ import java.util.ArrayList;
/*   42:     */ import java.util.Arrays;
/*   43:     */ import java.util.HashMap;
/*   44:     */ import java.util.List;
/*   45:     */ import java.util.Locale;
/*   46:     */ import java.util.Map;
/*   47:     */ import org.json.JSONArray;
/*   48:     */ import org.json.JSONObject;
/*   49:     */ 
/*   50:     */ @SuppressLint({"SetJavaScriptEnabled"})
/*   51:     */ public class TJAdUnitJSBridge
/*   52:     */ {
/*   53:     */   private TJWebViewJSInterface jsBridge;
/*   54:     */   private TJAdUnitJSBridge self;
/*   55:     */   private Context context;
/*   56:     */   private WebView webView;
/*   57:     */   private ProgressDialog progressDialog;
/*   58:     */   private TJEventData eventData;
/*   59:     */   private LocationManager locationManager;
/*   60:     */   private LocationListener locationListener;
/*   61:  62 */   private View bannerView = null;
/*   62:  64 */   public boolean didLaunchOtherActivity = false;
/*   63:  65 */   public boolean allowRedirect = true;
/*   64:  66 */   public String otherActivityCallbackID = null;
/*   65:  67 */   public boolean customClose = false;
/*   66:  68 */   public boolean shouldClose = false;
/*   67:     */   private static final String TAG = "TJAdUnitJSBridge";
/*   68:     */   
/*   69:     */   public TJAdUnitJSBridge(Context c, WebView w, TJEventData e)
/*   70:     */   {
/*   71:  81 */     TapjoyLog.i("TJAdUnitJSBridge", "creating AdUnit/JS Bridge");
/*   72:     */     
/*   73:  83 */     this.context = c;
/*   74:  84 */     this.eventData = e;
/*   75:  85 */     this.self = this;
/*   76:     */     
/*   77:     */ 
/*   78:  88 */     this.webView = w;
/*   79:  90 */     if (this.webView == null)
/*   80:     */     {
/*   81:  92 */       TapjoyLog.e("TJAdUnitJSBridge", "Error: webView is NULL");
/*   82:  93 */       return;
/*   83:     */     }
/*   84:  97 */     this.jsBridge = new TJWebViewJSInterface(this.webView, new TJWebViewJSInterfaceNotifier()
/*   85:     */     {
/*   86:     */       public void dispatchMethod(String methodName, JSONObject json)
/*   87:     */       {
/*   88: 104 */         String callbackID = null;
/*   89: 105 */         JSONObject data = null;
/*   90:     */         try
/*   91:     */         {
/*   92:     */           try
/*   93:     */           {
/*   94: 110 */             callbackID = json.getString("callbackId");
/*   95:     */           }
/*   96:     */           catch (Exception e)
/*   97:     */           {
/*   98: 114 */             TapjoyLog.w("TJAdUnitJSBridge", e.toString());
/*   99:     */           }
/*  100: 117 */           data = json.getJSONObject("data");
/*  101: 118 */           Method m = TJAdUnitJSBridge.class.getMethod(methodName, new Class[] { JSONObject.class, String.class });
/*  102: 119 */           m.invoke(TJAdUnitJSBridge.this.self, new Object[] { data, callbackID });
/*  103:     */         }
/*  104:     */         catch (Exception e)
/*  105:     */         {
/*  106: 123 */           e.printStackTrace();
/*  107: 124 */           TJAdUnitJSBridge.this.invokeJSCallback(callbackID, new Object[] { Boolean.FALSE });
/*  108:     */         }
/*  109:     */       }
/*  110: 128 */     });
/*  111: 129 */     this.webView.addJavascriptInterface(this.jsBridge, "AndroidJavascriptInterface");
/*  112:     */   }
/*  113:     */   
/*  114:     */   public void alert(JSONObject json, final String callbackID)
/*  115:     */   {
/*  116: 139 */     TapjoyLog.i("TJAdUnitJSBridge", "alert_method: " + json);
/*  117: 140 */     String title = "";
/*  118: 141 */     String message = "";
/*  119: 142 */     JSONArray buttons = null;
/*  120:     */     try
/*  121:     */     {
/*  122: 146 */       title = json.getString("title");
/*  123: 147 */       message = json.getString("message");
/*  124: 148 */       buttons = json.getJSONArray("buttons");
/*  125:     */     }
/*  126:     */     catch (Exception e)
/*  127:     */     {
/*  128: 152 */       invokeJSCallback(callbackID, new Object[] { Boolean.FALSE });
/*  129: 153 */       e.printStackTrace();
/*  130:     */     }
/*  131: 156 */     AlertDialog dialog = new AlertDialog.Builder(this.context).setTitle(title).setMessage(message).create();
/*  132: 158 */     if ((buttons == null) || (buttons.length() == 0))
/*  133:     */     {
/*  134: 160 */       invokeJSCallback(callbackID, new Object[] { Boolean.FALSE });
/*  135:     */     }
/*  136:     */     else
/*  137:     */     {
/*  138: 165 */       ArrayList<String> b = new ArrayList();
/*  139: 167 */       for (int i = 0; i < buttons.length(); i++)
/*  140:     */       {
/*  141:     */         int buttonType;
/*  142: 171 */         switch (i)
/*  143:     */         {
/*  144:     */         case 0: 
/*  145: 174 */           buttonType = -2;
/*  146: 175 */           break;
/*  147:     */         case 1: 
/*  148: 177 */           buttonType = -3;
/*  149: 178 */           break;
/*  150:     */         case 2: 
/*  151:     */         default: 
/*  152: 181 */           buttonType = -1;
/*  153:     */         }
/*  154:     */         try
/*  155:     */         {
/*  156: 187 */           b.add(buttons.getString(i));
/*  157:     */         }
/*  158:     */         catch (Exception e)
/*  159:     */         {
/*  160: 191 */           e.printStackTrace();
/*  161:     */         }
/*  162: 195 */         dialog.setButton(buttonType, (CharSequence)b.get(i), new DialogInterface.OnClickListener()
/*  163:     */         {
/*  164:     */           public void onClick(DialogInterface dialog, int which)
/*  165:     */           {
/*  166: 200 */             int index = 0;
/*  167: 202 */             switch (which)
/*  168:     */             {
/*  169:     */             case -2: 
/*  170: 205 */               index = 0;
/*  171: 206 */               break;
/*  172:     */             case -3: 
/*  173: 208 */               index = 1;
/*  174: 209 */               break;
/*  175:     */             case -1: 
/*  176: 211 */               index = 2;
/*  177:     */             }
/*  178:     */             try
/*  179:     */             {
/*  180: 217 */               TJAdUnitJSBridge.this.invokeJSCallback(callbackID, new Object[] { Integer.valueOf(index) });
/*  181:     */             }
/*  182:     */             catch (Exception e)
/*  183:     */             {
/*  184: 221 */               e.printStackTrace();
/*  185:     */             }
/*  186:     */           }
/*  187:     */         });
/*  188:     */       }
/*  189: 227 */       dialog.show();
/*  190:     */     }
/*  191:     */   }
/*  192:     */   
/*  193:     */   public void checkAppInstalled(JSONObject json, String callbackID)
/*  194:     */   {
/*  195: 238 */     String packageName = "";
/*  196:     */     try
/*  197:     */     {
/*  198: 242 */       packageName = json.getString("bundle");
/*  199:     */     }
/*  200:     */     catch (Exception e)
/*  201:     */     {
/*  202: 246 */       e.printStackTrace();
/*  203:     */     }
/*  204: 250 */     if ((packageName != null) && (packageName.length() > 0))
/*  205:     */     {
/*  206: 253 */       List<ApplicationInfo> applications = this.context.getPackageManager().getInstalledApplications(0);
/*  207: 254 */       for (ApplicationInfo appInfo : applications) {
/*  208: 257 */         if (appInfo.packageName.equals(packageName))
/*  209:     */         {
/*  210: 259 */           invokeJSCallback(callbackID, new Object[] { Boolean.TRUE });
/*  211: 260 */           return;
/*  212:     */         }
/*  213:     */       }
/*  214:     */     }
/*  215: 266 */     invokeJSCallback(callbackID, new Object[] { Boolean.FALSE });
/*  216:     */   }
/*  217:     */   
/*  218:     */   public void closeRequested()
/*  219:     */   {
/*  220: 274 */     this.shouldClose = true;
/*  221: 275 */     invokeJSAdunitMethod("closeRequested", new Object[0]);
/*  222:     */   }
/*  223:     */   
/*  224:     */   public void destroy()
/*  225:     */   {
/*  226: 283 */     if ((this.locationListener != null) && (this.locationManager != null))
/*  227:     */     {
/*  228: 285 */       this.locationManager.removeUpdates(this.locationListener);
/*  229: 286 */       this.locationManager = null;
/*  230: 287 */       this.locationListener = null;
/*  231:     */     }
/*  232:     */   }
/*  233:     */   
/*  234:     */   public void dismiss(JSONObject json, String callbackID)
/*  235:     */   {
/*  236: 298 */     if ((this.context instanceof TJAdUnitView))
/*  237:     */     {
/*  238: 300 */       invokeJSCallback(callbackID, new Object[] { Boolean.TRUE });
/*  239: 301 */       ((Activity)this.context).finish();
/*  240:     */     }
/*  241:     */   }
/*  242:     */   
/*  243:     */   public void display()
/*  244:     */   {
/*  245: 310 */     invokeJSAdunitMethod("display", new Object[0]);
/*  246:     */   }
/*  247:     */   
/*  248:     */   public void displayOffers(JSONObject json, String callbackID)
/*  249:     */   {
/*  250: 320 */     String currencyID = null;
/*  251:     */     try
/*  252:     */     {
/*  253: 324 */       currencyID = json.getString("currencyId");
/*  254:     */     }
/*  255:     */     catch (Exception e)
/*  256:     */     {
/*  257: 328 */       TapjoyLog.w("TJAdUnitJSBridge", "no currencyID for showOfferWall");
/*  258:     */     }
/*  259: 331 */     new TJCOffers(this.context).showOffersWithCurrencyID(currencyID, false, this.eventData, callbackID, null);
/*  260:     */   }
/*  261:     */   
/*  262:     */   public void displayRichMedia(final JSONObject json, String callbackID)
/*  263:     */   {
/*  264: 340 */     boolean inline = false;
/*  265: 341 */     String html = null;
/*  266:     */     try
/*  267:     */     {
/*  268: 345 */       inline = json.getBoolean("inline");
/*  269:     */     }
/*  270:     */     catch (Exception e) {}
/*  271:     */     try
/*  272:     */     {
/*  273: 351 */       html = json.getString("html");
/*  274:     */     }
/*  275:     */     catch (Exception e)
/*  276:     */     {
/*  277: 355 */       e.printStackTrace();
/*  278:     */     }
/*  279: 359 */     if (html == null)
/*  280:     */     {
/*  281: 361 */       invokeJSCallback(callbackID, new Object[] { Boolean.FALSE });
/*  282:     */     }
/*  283: 366 */     else if (inline)
/*  284:     */     {
/*  285: 369 */       ((Activity)this.context).runOnUiThread(new Runnable()
/*  286:     */       {
/*  287:     */         public void run()
/*  288:     */         {
/*  289: 374 */           String html = null;
/*  290:     */           try
/*  291:     */           {
/*  292: 378 */             html = json.getString("html");
/*  293:     */           }
/*  294:     */           catch (Exception e)
/*  295:     */           {
/*  296: 382 */             e.printStackTrace();
/*  297:     */           }
/*  298: 386 */           if (TJAdUnitJSBridge.this.bannerView != null) {
/*  299: 388 */             if (TJAdUnitJSBridge.this.bannerView.getParent() != null) {
/*  300: 390 */               ((ViewGroup)TJAdUnitJSBridge.this.bannerView.getParent()).removeView(TJAdUnitJSBridge.this.bannerView);
/*  301:     */             }
/*  302:     */           }
/*  303: 394 */           MraidView banner = new MraidView(TJAdUnitJSBridge.this.context);
/*  304: 395 */           WebSettings webSettings = TJAdUnitJSBridge.this.webView.getSettings();
/*  305: 396 */           webSettings.setJavaScriptEnabled(true);
/*  306: 397 */           banner.setPlacementType(MraidView.PLACEMENT_TYPE.INLINE);
/*  307:     */           
/*  308:     */ 
/*  309: 400 */           ViewGroup.LayoutParams layout = new ViewGroup.LayoutParams(640, 100);
/*  310: 401 */           banner.setLayoutParams(layout);
/*  311:     */           
/*  312:     */ 
/*  313: 404 */           banner.setInitialScale(100);
/*  314:     */           
/*  315:     */ 
/*  316: 407 */           banner.setBackgroundColor(0);
/*  317: 408 */           banner.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
/*  318:     */           
/*  319: 410 */           WindowManager windowManager = (WindowManager)((Activity)TJAdUnitJSBridge.this.context).getSystemService("window");
/*  320:     */           
/*  321: 412 */           int screenWidth = windowManager.getDefaultDisplay().getWidth();
/*  322: 413 */           TJAdUnitJSBridge.this.bannerView = TapjoyUtil.scaleDisplayAd(banner, screenWidth);
/*  323:     */           
/*  324: 415 */           ((Activity)TJAdUnitJSBridge.this.context).addContentView(TJAdUnitJSBridge.this.bannerView, new ViewGroup.LayoutParams(screenWidth, (int)(100.0D * (screenWidth / 640.0D))));
/*  325:     */         }
/*  326:     */       });
/*  327:     */     }
/*  328:     */     else
/*  329:     */     {
/*  330: 422 */       Intent intent = new Intent(this.context, TJAdUnitView.class);
/*  331: 423 */       intent.putExtra("tjevent", this.eventData);
/*  332: 424 */       intent.putExtra("view_type", 3);
/*  333: 425 */       intent.putExtra("html", html);
/*  334: 426 */       intent.putExtra("base_url", TapjoyConnectCore.getHostURL());
/*  335: 427 */       intent.putExtra("callback_id", callbackID);
/*  336: 428 */       ((Activity)this.context).startActivityForResult(intent, 0);
/*  337:     */     }
/*  338:     */   }
/*  339:     */   
/*  340:     */   public void displayStoreURL(JSONObject json, String callbackID)
/*  341:     */   {
/*  342: 442 */     displayURL(json, callbackID);
/*  343:     */   }
/*  344:     */   
/*  345:     */   public void displayURL(JSONObject json, String callbackID)
/*  346:     */   {
/*  347:     */     try
/*  348:     */     {
/*  349: 449 */       String url = json.getString("url");
/*  350:     */       
/*  351:     */ 
/*  352: 452 */       this.didLaunchOtherActivity = true;
/*  353: 453 */       this.otherActivityCallbackID = callbackID;
/*  354: 454 */       Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
/*  355: 455 */       ((Activity)this.context).startActivity(intent);
/*  356:     */     }
/*  357:     */     catch (Exception e)
/*  358:     */     {
/*  359: 459 */       invokeJSCallback(callbackID, new Object[] { Boolean.TRUE });
/*  360: 460 */       e.printStackTrace();
/*  361:     */     }
/*  362:     */   }
/*  363:     */   
/*  364:     */   public void displayVideo(JSONObject json, String callbackID)
/*  365:     */   {
/*  366: 470 */     String url = "";
/*  367: 471 */     String cancelMessage = "";
/*  368:     */     try
/*  369:     */     {
/*  370: 475 */       cancelMessage = json.getString("cancelMessage");
/*  371:     */     }
/*  372:     */     catch (Exception e)
/*  373:     */     {
/*  374: 479 */       TapjoyLog.w("TJAdUnitJSBridge", "no cancelMessage");
/*  375:     */     }
/*  376:     */     try
/*  377:     */     {
/*  378: 484 */       url = json.getString("url");
/*  379:     */       
/*  380:     */ 
/*  381: 487 */       Intent videoIntent = new Intent(this.context, TapjoyVideoView.class);
/*  382: 488 */       videoIntent.putExtra("VIDEO_URL", url);
/*  383: 489 */       videoIntent.putExtra("VIDEO_CANCEL_MESSAGE", cancelMessage);
/*  384: 490 */       videoIntent.putExtra("VIDEO_SHOULD_DISMISS", true);
/*  385: 491 */       videoIntent.putExtra("callback_id", callbackID);
/*  386: 492 */       ((Activity)this.context).startActivityForResult(videoIntent, 0);
/*  387:     */     }
/*  388:     */     catch (Exception e)
/*  389:     */     {
/*  390: 496 */       invokeJSCallback(callbackID, new Object[] { Boolean.FALSE });
/*  391: 497 */       e.printStackTrace();
/*  392:     */     }
/*  393:     */   }
/*  394:     */   
/*  395:     */   @SuppressLint({"WorldReadableFiles"})
/*  396:     */   private File downloadFileFromURL(String url)
/*  397:     */   {
/*  398: 509 */     File file = null;
/*  399:     */     
/*  400:     */ 
/*  401: 512 */     String ext = url.substring(url.lastIndexOf('.'));
/*  402:     */     
/*  403: 514 */     InputStream input = null;
/*  404:     */     try
/*  405:     */     {
/*  406: 520 */       URL fileURL = new URL(url);
/*  407: 521 */       input = fileURL.openStream();
/*  408:     */       
/*  409:     */ 
/*  410: 524 */       OutputStream output = this.context.openFileOutput("share_temp" + ext, 1);
/*  411:     */       
/*  412: 526 */       byte[] buffer = new byte[4096];
/*  413: 527 */       int bytesRead = 0;
/*  414: 528 */       while ((bytesRead = input.read(buffer, 0, buffer.length)) >= 0) {
/*  415: 530 */         output.write(buffer, 0, bytesRead);
/*  416:     */       }
/*  417:     */       try
/*  418:     */       {
/*  419: 535 */         output.close();
/*  420: 536 */         input.close();
/*  421:     */       }
/*  422:     */       catch (Exception e) {}
/*  423:     */     }
/*  424:     */     catch (Exception e)
/*  425:     */     {
/*  426: 542 */       e.printStackTrace();
/*  427:     */     }
/*  428: 545 */     file = new File(this.context.getFilesDir(), "share_temp" + ext);
/*  429: 546 */     return file;
/*  430:     */   }
/*  431:     */   
/*  432:     */   public void getLocation(JSONObject json, String callbackID)
/*  433:     */   {
/*  434: 557 */     float accuracy = 100.0F;
/*  435: 558 */     boolean enable = false;
/*  436:     */     try
/*  437:     */     {
/*  438: 563 */       accuracy = Float.valueOf(json.getString("gpsAccuracy")).floatValue();
/*  439:     */     }
/*  440:     */     catch (Exception e) {}
/*  441:     */     try
/*  442:     */     {
/*  443: 570 */       enable = Boolean.valueOf(json.getString("enabled")).booleanValue();
/*  444:     */     }
/*  445:     */     catch (Exception e)
/*  446:     */     {
/*  447: 574 */       e.printStackTrace();
/*  448:     */     }
/*  449: 577 */     this.locationManager = ((LocationManager)this.context.getSystemService("location"));
/*  450: 578 */     Criteria criteria = new Criteria();
/*  451: 579 */     String bestProvider = this.locationManager.getBestProvider(criteria, false);
/*  452: 581 */     if (this.locationListener == null) {
/*  453: 583 */       this.locationListener = new LocationListener()
/*  454:     */       {
/*  455:     */         public void onLocationChanged(Location location)
/*  456:     */         {
/*  457: 588 */           if ((TJAdUnitJSBridge.this.context == null) || (TJAdUnitJSBridge.this.webView == null))
/*  458:     */           {
/*  459: 590 */             if ((TJAdUnitJSBridge.this.locationManager != null) && (TJAdUnitJSBridge.this.locationListener != null))
/*  460:     */             {
/*  461: 592 */               TapjoyLog.i("TJAdUnitJSBridge", "stopping updates");
/*  462: 593 */               TJAdUnitJSBridge.this.locationManager.removeUpdates(TJAdUnitJSBridge.this.locationListener);
/*  463:     */             }
/*  464:     */           }
/*  465: 598 */           else if (location != null)
/*  466:     */           {
/*  467: 600 */             HashMap<String, Object> result = new HashMap();
/*  468: 601 */             result.put("lat", Double.valueOf(location.getLatitude()));
/*  469: 602 */             result.put("long", Double.valueOf(location.getLongitude()));
/*  470: 603 */             result.put("altitude", Double.valueOf(location.getAltitude()));
/*  471: 604 */             result.put("timestamp", Long.valueOf(location.getTime()));
/*  472: 605 */             result.put("speed", Float.valueOf(location.getSpeed()));
/*  473: 606 */             result.put("course", Float.valueOf(location.getBearing()));
/*  474: 607 */             TJAdUnitJSBridge.this.invokeJSAdunitMethod("locationUpdated", result);
/*  475:     */           }
/*  476:     */         }
/*  477:     */         
/*  478:     */         public void onProviderEnabled(String p) {}
/*  479:     */         
/*  480:     */         public void onProviderDisabled(String p) {}
/*  481:     */         
/*  482:     */         public void onStatusChanged(String p, int status, Bundle extras) {}
/*  483:     */       };
/*  484:     */     }
/*  485: 620 */     if (enable)
/*  486:     */     {
/*  487: 622 */       if (bestProvider != null)
/*  488:     */       {
/*  489: 624 */         this.locationManager.requestLocationUpdates(bestProvider, 0L, accuracy, this.locationListener);
/*  490: 625 */         invokeJSCallback(callbackID, new Object[] { Boolean.TRUE });
/*  491:     */       }
/*  492:     */       else
/*  493:     */       {
/*  494: 627 */         invokeJSCallback(callbackID, new Object[] { Boolean.FALSE });
/*  495:     */       }
/*  496:     */     }
/*  497:     */     else
/*  498:     */     {
/*  499: 633 */       if ((this.locationManager != null) && (this.locationListener != null)) {
/*  500: 634 */         this.locationManager.removeUpdates(this.locationListener);
/*  501:     */       }
/*  502: 635 */       invokeJSCallback(callbackID, new Object[] { Boolean.TRUE });
/*  503:     */     }
/*  504:     */   }
/*  505:     */   
/*  506:     */   public void log(JSONObject json, String callbackID)
/*  507:     */   {
/*  508:     */     try
/*  509:     */     {
/*  510: 648 */       TapjoyLog.i("TJAdUnitJSBridge", json.getString("message"));
/*  511: 649 */       invokeJSCallback(callbackID, new Object[] { Boolean.TRUE });
/*  512:     */     }
/*  513:     */     catch (Exception e)
/*  514:     */     {
/*  515: 653 */       invokeJSCallback(callbackID, new Object[] { Boolean.FALSE });
/*  516: 654 */       e.printStackTrace();
/*  517:     */     }
/*  518:     */   }
/*  519:     */   
/*  520:     */   public void openApp(JSONObject json, String callbackID)
/*  521:     */   {
/*  522:     */     try
/*  523:     */     {
/*  524: 667 */       String packageName = json.getString("bundle");
/*  525: 668 */       Intent intent = this.context.getPackageManager().getLaunchIntentForPackage(packageName);
/*  526: 669 */       this.context.startActivity(intent);
/*  527: 670 */       invokeJSCallback(callbackID, new Object[] { Boolean.TRUE });
/*  528:     */     }
/*  529:     */     catch (Exception e)
/*  530:     */     {
/*  531: 674 */       invokeJSCallback(callbackID, new Object[] { Boolean.FALSE });
/*  532: 675 */       e.printStackTrace();
/*  533:     */     }
/*  534:     */   }
/*  535:     */   
/*  536:     */   public void nativeEval(final JSONObject json, final String callbackID)
/*  537:     */   {
/*  538: 687 */     ((Activity)this.context).runOnUiThread(new Runnable()
/*  539:     */     {
/*  540:     */       public void run()
/*  541:     */       {
/*  542:     */         try
/*  543:     */         {
/*  544: 692 */           TJAdUnitJSBridge.this.webView.loadUrl("javascript:" + json.getString("command"));
/*  545: 693 */           TJAdUnitJSBridge.this.invokeJSCallback(callbackID, new Object[] { Boolean.TRUE });
/*  546:     */         }
/*  547:     */         catch (Exception e)
/*  548:     */         {
/*  549: 697 */           TJAdUnitJSBridge.this.invokeJSCallback(callbackID, new Object[] { Boolean.FALSE });
/*  550:     */         }
/*  551:     */       }
/*  552:     */     });
/*  553:     */   }
/*  554:     */   
/*  555:     */   public void present(JSONObject json, String callbackID)
/*  556:     */   {
/*  557:     */     try
/*  558:     */     {
/*  559: 713 */       Boolean visible = Boolean.valueOf(false);
/*  560: 714 */       Boolean transparent = Boolean.valueOf(false);
/*  561:     */       
/*  562: 716 */       visible = Boolean.valueOf(json.getString("visible"));
/*  563:     */       try
/*  564:     */       {
/*  565: 720 */         transparent = Boolean.valueOf(json.getString("transparent"));
/*  566:     */       }
/*  567:     */       catch (Exception e) {}
/*  568:     */       try
/*  569:     */       {
/*  570: 726 */         this.customClose = Boolean.valueOf(json.getString("customClose")).booleanValue();
/*  571:     */       }
/*  572:     */       catch (Exception e) {}
/*  573: 731 */       new ShowWebView(this.webView).execute(new Boolean[] { visible, transparent });
/*  574:     */       
/*  575: 733 */       invokeJSCallback(callbackID, new Object[] { Boolean.TRUE });
/*  576:     */     }
/*  577:     */     catch (Exception e)
/*  578:     */     {
/*  579: 737 */       invokeJSCallback(callbackID, new Object[] { Boolean.FALSE });
/*  580: 738 */       e.printStackTrace();
/*  581:     */     }
/*  582:     */   }
/*  583:     */   
/*  584:     */   public void invokeJSAdunitMethod(String methodName, Object... args)
/*  585:     */   {
/*  586: 749 */     ArrayList<Object> arguments = new ArrayList(Arrays.asList(args));
/*  587: 750 */     this.jsBridge.callback(arguments, methodName, null);
/*  588:     */   }
/*  589:     */   
/*  590:     */   public void invokeJSAdunitMethod(String methodName, Map<String, Object> arguments)
/*  591:     */   {
/*  592: 760 */     this.jsBridge.callback(arguments, methodName, null);
/*  593:     */   }
/*  594:     */   
/*  595:     */   public void invokeJSCallback(String callbackID, Object... argArray)
/*  596:     */   {
/*  597: 771 */     ArrayList<Object> arguments = new ArrayList(Arrays.asList(argArray));
/*  598: 772 */     this.jsBridge.callback(arguments, "", callbackID);
/*  599:     */   }
/*  600:     */   
/*  601:     */   public void invokeJSCallback(String callbackID, Map<String, Object> arguments)
/*  602:     */   {
/*  603: 783 */     this.jsBridge.callback(arguments, "", callbackID);
/*  604:     */   }
/*  605:     */   
/*  606:     */   public void sendActionCallback(JSONObject json, final String callbackID)
/*  607:     */   {
/*  608: 791 */     TJEventRequest request = new TJEventRequest();
/*  609: 792 */     String type = null;
/*  610:     */     try
/*  611:     */     {
/*  612: 796 */       type = json.getString("type");
/*  613:     */     }
/*  614:     */     catch (Exception e)
/*  615:     */     {
/*  616: 800 */       e.printStackTrace();
/*  617:     */     }
/*  618:     */     try
/*  619:     */     {
/*  620: 805 */       request.quantity = Integer.valueOf(json.getString("quantity")).intValue();
/*  621:     */     }
/*  622:     */     catch (Exception e)
/*  623:     */     {
/*  624: 809 */       e.printStackTrace();
/*  625:     */     }
/*  626:     */     try
/*  627:     */     {
/*  628: 814 */       request.identifier = json.getString("identifier");
/*  629:     */     }
/*  630:     */     catch (Exception e)
/*  631:     */     {
/*  632: 818 */       e.printStackTrace();
/*  633:     */     }
/*  634: 822 */     if ((type == null) || (request.identifier == null))
/*  635:     */     {
/*  636: 824 */       TapjoyLog.i("TJAdUnitJSBridge", "sendActionCallback: null type or identifier");
/*  637: 825 */       invokeJSCallback(callbackID, new Object[] { Boolean.FALSE });
/*  638: 826 */       return;
/*  639:     */     }
/*  640: 829 */     if (type.equals("currency")) {
/*  641: 831 */       request.type = 3;
/*  642: 834 */     } else if (type.equals("inAppPurchase")) {
/*  643: 836 */       request.type = 1;
/*  644: 839 */     } else if (type.equals("navigation")) {
/*  645: 841 */       request.type = 4;
/*  646: 844 */     } else if (type.equals("virtualGood")) {
/*  647: 846 */       request.type = 2;
/*  648:     */     }
/*  649: 850 */     if (request.type == 0)
/*  650:     */     {
/*  651: 852 */       TapjoyLog.i("TJAdUnitJSBridge", "unknown type: " + type);
/*  652: 853 */       invokeJSCallback(callbackID, new Object[] { Boolean.FALSE });
/*  653: 854 */       return;
/*  654:     */     }
/*  655: 858 */     request.callback = new TJEventRequestCallback()
/*  656:     */     {
/*  657:     */       public void completed()
/*  658:     */       {
/*  659: 863 */         TJAdUnitJSBridge.this.invokeJSCallback(callbackID, new Object[] { Boolean.TRUE });
/*  660:     */       }
/*  661:     */       
/*  662:     */       public void cancelled()
/*  663:     */       {
/*  664: 869 */         TJAdUnitJSBridge.this.invokeJSCallback(callbackID, new Object[] { Boolean.FALSE });
/*  665:     */       }
/*  666: 872 */     };
/*  667: 873 */     TJEvent event = TJEventManager.get(this.eventData.guid);
/*  668: 874 */     if (event != null) {
/*  669: 875 */       event.getCallback().didRequestAction(event, request);
/*  670:     */     }
/*  671:     */   }
/*  672:     */   
/*  673:     */   public void setAllowRedirect(JSONObject json, String callbackID)
/*  674:     */   {
/*  675: 885 */     boolean enabled = true;
/*  676:     */     try
/*  677:     */     {
/*  678: 889 */       enabled = json.getBoolean("enabled");
/*  679:     */     }
/*  680:     */     catch (Exception e) {}
/*  681: 893 */     this.allowRedirect = enabled;
/*  682:     */     
/*  683: 895 */     invokeJSCallback(callbackID, new Object[] { Boolean.TRUE });
/*  684:     */   }
/*  685:     */   
/*  686:     */   public void setContext(Context c)
/*  687:     */   {
/*  688: 904 */     this.context = c;
/*  689:     */   }
/*  690:     */   
/*  691:     */   public void setSpinnerVisible(JSONObject json, String callbackID)
/*  692:     */   {
/*  693: 914 */     boolean visible = false;
/*  694: 915 */     String title = "Loading...";
/*  695: 916 */     String message = "";
/*  696:     */     try
/*  697:     */     {
/*  698: 920 */       visible = json.getBoolean("visible");
/*  699:     */       try
/*  700:     */       {
/*  701: 923 */         title = json.getString("title");
/*  702: 924 */         message = json.getString("message");
/*  703:     */       }
/*  704:     */       catch (Exception e) {}
/*  705: 927 */       if (visible) {
/*  706: 929 */         this.progressDialog = ProgressDialog.show(this.context, title, message);
/*  707: 933 */       } else if (this.progressDialog != null) {
/*  708: 934 */         this.progressDialog.dismiss();
/*  709:     */       }
/*  710: 937 */       invokeJSCallback(callbackID, new Object[] { Boolean.TRUE });
/*  711:     */     }
/*  712:     */     catch (Exception e)
/*  713:     */     {
/*  714: 941 */       invokeJSCallback(callbackID, new Object[] { Boolean.FALSE });
/*  715: 942 */       e.printStackTrace();
/*  716:     */     }
/*  717:     */   }
/*  718:     */   
/*  719:     */   public void share(JSONObject json, String callbackID)
/*  720:     */   {
/*  721:     */     try
/*  722:     */     {
/*  723: 958 */       String network = json.getString("network");
/*  724: 959 */       String message = json.getString("message");
/*  725: 960 */       String imageURL = null;
/*  726: 961 */       String linkURL = null;
/*  727: 962 */       String localImageURL = null;
/*  728: 963 */       boolean found = false;
/*  729: 964 */       Intent share = new Intent("android.intent.action.SEND");
/*  730:     */       try
/*  731:     */       {
/*  732: 968 */         imageURL = json.getString("imageURL");
/*  733:     */       }
/*  734:     */       catch (Exception e)
/*  735:     */       {
/*  736: 972 */         TapjoyLog.i("TJAdUnitJSBridge", "no imageURL");
/*  737:     */       }
/*  738:     */       try
/*  739:     */       {
/*  740: 977 */         linkURL = json.getString("linkURL");
/*  741:     */       }
/*  742:     */       catch (Exception e)
/*  743:     */       {
/*  744: 981 */         TapjoyLog.i("TJAdUnitJSBridge", "no linkURL");
/*  745:     */       }
/*  746: 986 */       if (imageURL != null)
/*  747:     */       {
/*  748: 988 */         File localFile = downloadFileFromURL(imageURL);
/*  749: 990 */         if (localFile != null) {
/*  750: 991 */           localImageURL = "file://" + localFile.getAbsolutePath();
/*  751:     */         }
/*  752:     */       }
/*  753: 995 */       if (linkURL != null) {
/*  754: 997 */         message = message + "\n" + linkURL;
/*  755:     */       }
/*  756:1000 */       share.putExtra("android.intent.extra.TEXT", message);
/*  757:1003 */       if (network.equals("facebook"))
/*  758:     */       {
/*  759:1006 */         if ((imageURL != null) && (localImageURL != null))
/*  760:     */         {
/*  761:1008 */           share.setType("image/*");
/*  762:1009 */           share.putExtra("android.intent.extra.STREAM", Uri.parse(localImageURL));
/*  763:     */         }
/*  764:     */         else
/*  765:     */         {
/*  766:1013 */           share.setType("text/plain");
/*  767:     */         }
/*  768:     */       }
/*  769:1018 */       else if (network.equals("twitter"))
/*  770:     */       {
/*  771:1020 */         share.setType("*/*");
/*  772:1022 */         if ((imageURL != null) && (localImageURL != null)) {
/*  773:1024 */           share.putExtra("android.intent.extra.STREAM", Uri.parse(localImageURL));
/*  774:     */         }
/*  775:     */       }
/*  776:1029 */       List<ResolveInfo> resInfo = this.context.getPackageManager().queryIntentActivities(share, 0);
/*  777:1031 */       for (ResolveInfo info : resInfo) {
/*  778:1033 */         if ((info.activityInfo.packageName.toLowerCase(Locale.ENGLISH).contains(network)) || (info.activityInfo.name.toLowerCase(Locale.ENGLISH).contains(network)))
/*  779:     */         {
/*  780:1036 */           share.setPackage(info.activityInfo.packageName);
/*  781:1037 */           found = true;
/*  782:1038 */           break;
/*  783:     */         }
/*  784:     */       }
/*  785:1042 */       if (!found)
/*  786:     */       {
/*  787:1044 */         invokeJSCallback(callbackID, new Object[] { Boolean.FALSE });
/*  788:1045 */         return;
/*  789:     */       }
/*  790:1049 */       this.didLaunchOtherActivity = true;
/*  791:1050 */       this.otherActivityCallbackID = callbackID;
/*  792:1051 */       Intent i = Intent.createChooser(share, "Select");
/*  793:1052 */       ((Activity)this.context).startActivity(i);
/*  794:     */     }
/*  795:     */     catch (Exception e)
/*  796:     */     {
/*  797:1056 */       invokeJSCallback(callbackID, new Object[] { Boolean.FALSE });
/*  798:1057 */       e.printStackTrace();
/*  799:     */     }
/*  800:     */   }
/*  801:     */   
/*  802:     */   public void shouldClose(JSONObject json, String callbackID)
/*  803:     */   {
/*  804:     */     try
/*  805:     */     {
/*  806:1069 */       Boolean close = Boolean.valueOf(false);
/*  807:1070 */       close = Boolean.valueOf(json.getString("close"));
/*  808:1073 */       if ((close.booleanValue()) && ((this.context instanceof TJAdUnitView))) {
/*  809:1075 */         ((Activity)this.context).finish();
/*  810:     */       }
/*  811:1078 */       invokeJSCallback(callbackID, new Object[] { Boolean.TRUE });
/*  812:     */     }
/*  813:     */     catch (Exception e)
/*  814:     */     {
/*  815:1082 */       invokeJSCallback(callbackID, new Object[] { Boolean.FALSE });
/*  816:     */       
/*  817:     */ 
/*  818:1085 */       ((Activity)this.context).finish();
/*  819:1086 */       e.printStackTrace();
/*  820:     */     }
/*  821:1089 */     this.shouldClose = false;
/*  822:     */   }
/*  823:     */   
/*  824:     */   @TargetApi(11)
/*  825:     */   private class ShowWebView
/*  826:     */     extends AsyncTask<Boolean, Void, Boolean[]>
/*  827:     */   {
/*  828:     */     WebView webView;
/*  829:     */     
/*  830:     */     public ShowWebView(WebView w)
/*  831:     */     {
/*  832:1099 */       this.webView = w;
/*  833:     */     }
/*  834:     */     
/*  835:     */     protected Boolean[] doInBackground(Boolean... params)
/*  836:     */     {
/*  837:1104 */       return params;
/*  838:     */     }
/*  839:     */     
/*  840:     */     protected void onPostExecute(Boolean[] params)
/*  841:     */     {
/*  842:1109 */       final boolean visible = params[0].booleanValue();
/*  843:1110 */       final boolean transparent = params[1].booleanValue();
/*  844:     */       
/*  845:1112 */       ((Activity)TJAdUnitJSBridge.this.context).runOnUiThread(new Runnable()
/*  846:     */       {
/*  847:     */         public void run()
/*  848:     */         {
/*  849:1117 */           if (visible)
/*  850:     */           {
/*  851:1119 */             TJAdUnitJSBridge.ShowWebView.this.webView.setVisibility(0);
/*  852:1122 */             if (transparent)
/*  853:     */             {
/*  854:1124 */               if ((TJAdUnitJSBridge.ShowWebView.this.webView.getParent() instanceof RelativeLayout))
/*  855:     */               {
/*  856:1127 */                 ((RelativeLayout)TJAdUnitJSBridge.ShowWebView.this.webView.getParent()).getBackground().setAlpha(0);
/*  857:1128 */                 ((RelativeLayout)TJAdUnitJSBridge.ShowWebView.this.webView.getParent()).setBackgroundColor(0);
/*  858:     */               }
/*  859:1132 */               if (Build.VERSION.SDK_INT >= 11) {
/*  860:1133 */                 TJAdUnitJSBridge.ShowWebView.this.webView.setLayerType(1, null);
/*  861:     */               }
/*  862:     */             }
/*  863:     */             else
/*  864:     */             {
/*  865:1138 */               if ((TJAdUnitJSBridge.ShowWebView.this.webView.getParent() instanceof RelativeLayout))
/*  866:     */               {
/*  867:1143 */                 ((RelativeLayout)TJAdUnitJSBridge.ShowWebView.this.webView.getParent()).getBackground().setAlpha(255);
/*  868:1144 */                 ((RelativeLayout)TJAdUnitJSBridge.ShowWebView.this.webView.getParent()).setBackgroundColor(-1);
/*  869:     */               }
/*  870:1148 */               if (Build.VERSION.SDK_INT >= 11) {
/*  871:1149 */                 TJAdUnitJSBridge.ShowWebView.this.webView.setLayerType(0, null);
/*  872:     */               }
/*  873:     */             }
/*  874:     */           }
/*  875:     */           else
/*  876:     */           {
/*  877:1156 */             TJAdUnitJSBridge.ShowWebView.this.webView.setVisibility(4);
/*  878:1158 */             if ((TJAdUnitJSBridge.ShowWebView.this.webView.getParent() instanceof RelativeLayout))
/*  879:     */             {
/*  880:1160 */               ((RelativeLayout)TJAdUnitJSBridge.ShowWebView.this.webView.getParent()).getBackground().setAlpha(0);
/*  881:1161 */               ((RelativeLayout)TJAdUnitJSBridge.ShowWebView.this.webView.getParent()).setBackgroundColor(0);
/*  882:     */             }
/*  883:     */           }
/*  884:     */         }
/*  885:     */       });
/*  886:     */     }
/*  887:     */   }
/*  888:     */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TJAdUnitJSBridge
 * JD-Core Version:    0.7.0.1
 */