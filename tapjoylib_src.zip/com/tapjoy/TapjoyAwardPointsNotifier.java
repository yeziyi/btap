package com.tapjoy;

public abstract interface TapjoyAwardPointsNotifier
{
  public abstract void getAwardPointsResponse(String paramString, int paramInt);
  
  public abstract void getAwardPointsResponseFailed(String paramString);
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyAwardPointsNotifier
 * JD-Core Version:    0.7.0.1
 */