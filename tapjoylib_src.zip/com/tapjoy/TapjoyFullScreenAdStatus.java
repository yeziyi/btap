package com.tapjoy;

public class TapjoyFullScreenAdStatus
{
  public static final int STATUS_NO_ADS_AVAILABLE = 1;
  public static final int STATUS_NETWORK_ERROR = 2;
  public static final int STATUS_SERVER_ERROR = 3;
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyFullScreenAdStatus
 * JD-Core Version:    0.7.0.1
 */