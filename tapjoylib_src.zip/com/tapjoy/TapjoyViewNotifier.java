package com.tapjoy;

public abstract interface TapjoyViewNotifier
{
  public abstract void viewWillClose(int paramInt);
  
  public abstract void viewDidClose(int paramInt);
  
  public abstract void viewWillOpen(int paramInt);
  
  public abstract void viewDidOpen(int paramInt);
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyViewNotifier
 * JD-Core Version:    0.7.0.1
 */