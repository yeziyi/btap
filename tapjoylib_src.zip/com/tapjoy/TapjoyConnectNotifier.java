package com.tapjoy;

public abstract interface TapjoyConnectNotifier
{
  public abstract void connectSuccess();
  
  public abstract void connectFail();
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyConnectNotifier
 * JD-Core Version:    0.7.0.1
 */