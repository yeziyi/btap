/*  1:   */ package com.tapjoy;
/*  2:   */ 
/*  3:   */ import android.content.Context;
/*  4:   */ import android.content.Intent;
/*  5:   */ import java.util.Map;
/*  6:   */ 
/*  7:   */ public class TapjoyDailyRewardAd
/*  8:   */ {
/*  9:   */   private static TapjoyDailyRewardAdNotifier dailyRewardNotifier;
/* 10:   */   private Context context;
/* 11:   */   private Map<String, String> legacyDailyRewardAdParams;
/* 12:21 */   private static String htmlResponseData = null;
/* 13:   */   private static final String TAG = "Daily Reward";
/* 14:   */   
/* 15:   */   public TapjoyDailyRewardAd(Context ctx)
/* 16:   */   {
/* 17:31 */     this.context = ctx;
/* 18:   */   }
/* 19:   */   
/* 20:   */   /**
/* 21:   */    * @deprecated
/* 22:   */    */
/* 23:   */   public void getDailyRewardAd(TapjoyDailyRewardAdNotifier notifier)
/* 24:   */   {
/* 25:42 */     TapjoyLog.i("Daily Reward", "Getting Daily Reward Ad");
/* 26:43 */     getDailyRewardAdWithCurrencyID(null, notifier);
/* 27:   */   }
/* 28:   */   
/* 29:   */   /**
/* 30:   */    * @deprecated
/* 31:   */    */
/* 32:   */   public void getDailyRewardAdWithCurrencyID(String currencyID, TapjoyDailyRewardAdNotifier notifier)
/* 33:   */   {
/* 34:55 */     dailyRewardNotifier = notifier;
/* 35:   */     
/* 36:57 */     getDailyRewardAdLegacy(currencyID);
/* 37:   */   }
/* 38:   */   
/* 39:   */   /**
/* 40:   */    * @deprecated
/* 41:   */    */
/* 42:   */   public void showDailyRewardAd()
/* 43:   */   {
/* 44:68 */     TapjoyLog.i("Daily Reward", "Displaying Daily Reward ad...");
/* 45:70 */     if ((htmlResponseData != null) && (htmlResponseData.length() > 0))
/* 46:   */     {
/* 47:72 */       Intent intent = new Intent(this.context, TapjoyDailyRewardAdWebView.class);
/* 48:73 */       intent.setFlags(268435456);
/* 49:74 */       intent.putExtra("html", htmlResponseData);
/* 50:75 */       intent.putExtra("base_url", TapjoyConnectCore.getHostURL());
/* 51:76 */       intent.putExtra("legacy_view", true);
/* 52:77 */       this.context.startActivity(intent);
/* 53:   */     }
/* 54:   */   }
/* 55:   */   
/* 56:   */   public void getDailyRewardAdLegacy(String currencyID)
/* 57:   */   {
/* 58:88 */     this.legacyDailyRewardAdParams = TapjoyConnectCore.getURLParams();
/* 59:89 */     TapjoyUtil.safePut(this.legacyDailyRewardAdParams, "currency_id", currencyID, true);
/* 60:   */     
/* 61:91 */     new Thread(new Runnable()
/* 62:   */     {
/* 63:   */       public void run()
/* 64:   */       {
/* 65:95 */         TapjoyHttpURLResponse httpResponse = new TapjoyURLConnection().getResponseFromURL(TapjoyConnectCore.getHostURL() + "reengagement_rewards?", TapjoyDailyRewardAd.this.legacyDailyRewardAdParams);
/* 66:97 */         if (httpResponse != null) {
/* 67:99 */           switch (httpResponse.statusCode)
/* 68:   */           {
/* 69:   */           case 200: 
/* 70::4 */             TapjoyDailyRewardAd.access$102(httpResponse.response);
/* 71::5 */             TapjoyDailyRewardAd.dailyRewardNotifier.getDailyRewardAdResponse();
/* 72::6 */             break;
/* 73:   */           case 204: 
/* 74:;0 */             TapjoyDailyRewardAd.dailyRewardNotifier.getDailyRewardAdResponseFailed(1);
/* 75:   */           }
/* 76:   */         } else {
/* 77:;6 */           TapjoyDailyRewardAd.dailyRewardNotifier.getDailyRewardAdResponseFailed(2);
/* 78:   */         }
/* 79:   */       }
/* 80:   */     }).start();
/* 81:   */   }
/* 82:   */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyDailyRewardAd
 * JD-Core Version:    0.7.0.1
 */