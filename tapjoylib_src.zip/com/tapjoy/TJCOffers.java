/*   1:    */ package com.tapjoy;
/*   2:    */ 
/*   3:    */ import android.app.Activity;
/*   4:    */ import android.content.Context;
/*   5:    */ import android.content.Intent;
/*   6:    */ import java.util.HashMap;
/*   7:    */ 
/*   8:    */ public class TJCOffers
/*   9:    */ {
/*  10:    */   Context context;
/*  11:    */   private static TapjoyOffersNotifier tapjoyOffersNotifier;
/*  12:    */   private static final String TAG = "TapjoyOffers";
/*  13:    */   
/*  14:    */   public TJCOffers(Context ctx)
/*  15:    */   {
/*  16: 30 */     this.context = ctx;
/*  17:    */   }
/*  18:    */   
/*  19:    */   public void showOffers(TapjoyOffersNotifier notifier)
/*  20:    */   {
/*  21: 38 */     showOffersWithCurrencyID(null, false, notifier);
/*  22:    */   }
/*  23:    */   
/*  24:    */   public void showOffersWithCurrencyID(String currencyID, boolean enableCurrencySelector, TapjoyOffersNotifier notifier)
/*  25:    */   {
/*  26: 50 */     showOffersWithCurrencyID(currencyID, enableCurrencySelector, null, null, notifier);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void showOffersWithCurrencyID(String currencyID, boolean enableCurrencySelector, TJEventData eventData, String callbackID, TapjoyOffersNotifier notifier)
/*  30:    */   {
/*  31: 63 */     tapjoyOffersNotifier = notifier;
/*  32:    */     
/*  33: 65 */     String multipleCurrencySelector = enableCurrencySelector ? "1" : "0";
/*  34:    */     
/*  35:    */ 
/*  36: 68 */     HashMap<String, String> offersURLParams = new HashMap(TapjoyConnectCore.getURLParams());
/*  37:    */     
/*  38: 70 */     TapjoyUtil.safePut(offersURLParams, "currency_id", currencyID, true);
/*  39: 71 */     TapjoyUtil.safePut(offersURLParams, "currency_selector", multipleCurrencySelector, true);
/*  40:    */     
/*  41:    */ 
/*  42: 74 */     offersURLParams.putAll(TapjoyConnectCore.getVideoParams());
/*  43:    */     
/*  44: 76 */     Intent intent = new Intent(this.context, TJCOffersWebView.class);
/*  45: 78 */     if (eventData != null) {
/*  46: 80 */       TapjoyLog.i("TapjoyOffers", "showOffers for eventName: " + eventData.name);
/*  47:    */     }
/*  48: 83 */     if ((callbackID != null) && (callbackID.length() > 0)) {
/*  49: 84 */       intent.putExtra("callback_id", callbackID);
/*  50:    */     }
/*  51: 86 */     intent.putExtra("view_type", 2);
/*  52: 87 */     intent.putExtra("tjevent", eventData);
/*  53: 88 */     intent.putExtra("legacy_view", true);
/*  54: 89 */     intent.putExtra("URL_PARAMS", offersURLParams);
/*  55: 92 */     if ((this.context instanceof Activity))
/*  56:    */     {
/*  57: 94 */       ((Activity)this.context).startActivityForResult(intent, 0);
/*  58:    */     }
/*  59:    */     else
/*  60:    */     {
/*  61: 98 */       intent.setFlags(268435456);
/*  62: 99 */       this.context.startActivity(intent);
/*  63:    */     }
/*  64:    */   }
/*  65:    */   
/*  66:    */   public static void getOffersNotifierResponse()
/*  67:    */   {
/*  68:108 */     if (tapjoyOffersNotifier != null) {
/*  69:109 */       tapjoyOffersNotifier.getOffersResponse();
/*  70:    */     }
/*  71:    */   }
/*  72:    */   
/*  73:    */   public static void getOffersNotifierResponseFailed(String error)
/*  74:    */   {
/*  75:118 */     if (tapjoyOffersNotifier != null) {
/*  76:119 */       tapjoyOffersNotifier.getOffersResponseFailed(error);
/*  77:    */     }
/*  78:    */   }
/*  79:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TJCOffers
 * JD-Core Version:    0.7.0.1
 */