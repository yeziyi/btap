package com.tapjoy;

public abstract interface TapjoyOffersNotifier
{
  public abstract void getOffersResponse();
  
  public abstract void getOffersResponseFailed(String paramString);
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyOffersNotifier
 * JD-Core Version:    0.7.0.1
 */