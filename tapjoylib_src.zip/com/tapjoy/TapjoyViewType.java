package com.tapjoy;

public class TapjoyViewType
{
  public static final int OFFER_WALL_AD = 0;
  public static final int FULLSCREEN_AD = 1;
  public static final int DAILY_REWARD_AD = 2;
  public static final int VIDEO_AD = 3;
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyViewType
 * JD-Core Version:    0.7.0.1
 */