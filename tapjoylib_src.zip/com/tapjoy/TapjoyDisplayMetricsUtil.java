/*  1:   */ package com.tapjoy;
/*  2:   */ 
/*  3:   */ import android.content.Context;
/*  4:   */ import android.content.res.Configuration;
/*  5:   */ import android.content.res.Resources;
/*  6:   */ import android.util.DisplayMetrics;
/*  7:   */ import android.view.Display;
/*  8:   */ import android.view.WindowManager;
/*  9:   */ 
/* 10:   */ public class TapjoyDisplayMetricsUtil
/* 11:   */ {
/* 12:   */   private Context context;
/* 13:   */   private Configuration configuration;
/* 14:   */   private DisplayMetrics metrics;
/* 15:   */   
/* 16:   */   public TapjoyDisplayMetricsUtil(Context theContext)
/* 17:   */   {
/* 18:31 */     this.context = theContext;
/* 19:   */     
/* 20:33 */     this.metrics = new DisplayMetrics();
/* 21:34 */     WindowManager windowManager = (WindowManager)this.context.getSystemService("window");
/* 22:35 */     windowManager.getDefaultDisplay().getMetrics(this.metrics);
/* 23:   */     
/* 24:37 */     this.configuration = this.context.getResources().getConfiguration();
/* 25:   */   }
/* 26:   */   
/* 27:   */   public int getScreenDensityDPI()
/* 28:   */   {
/* 29:47 */     return this.metrics.densityDpi;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public float getScreenDensityScale()
/* 33:   */   {
/* 34:57 */     return this.metrics.density;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public int getScreenLayoutSize()
/* 38:   */   {
/* 39:66 */     return this.configuration.screenLayout & 0xF;
/* 40:   */   }
/* 41:   */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyDisplayMetricsUtil
 * JD-Core Version:    0.7.0.1
 */