package com.tapjoy;

public abstract interface TJEventCallback
{
  public abstract void sendEventCompleted(TJEvent paramTJEvent, boolean paramBoolean);
  
  public abstract void sendEventFail(TJEvent paramTJEvent, TJError paramTJError);
  
  public abstract void contentDidShow(TJEvent paramTJEvent);
  
  public abstract void contentDidDisappear(TJEvent paramTJEvent);
  
  public abstract void didRequestAction(TJEvent paramTJEvent, TJEventRequest paramTJEventRequest);
}


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TJEventCallback
 * JD-Core Version:    0.7.0.1
 */