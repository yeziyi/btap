/*   1:    */ package com.tapjoy;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.content.Intent;
/*   5:    */ import android.graphics.Bitmap;
/*   6:    */ import android.graphics.BitmapFactory;
/*   7:    */ import android.os.Environment;
/*   8:    */ import android.util.Log;
/*   9:    */ import java.io.BufferedInputStream;
/*  10:    */ import java.io.ByteArrayInputStream;
/*  11:    */ import java.io.File;
/*  12:    */ import java.io.FileOutputStream;
/*  13:    */ import java.io.InputStream;
/*  14:    */ import java.io.OutputStream;
/*  15:    */ import java.net.SocketTimeoutException;
/*  16:    */ import java.net.URL;
/*  17:    */ import java.net.URLConnection;
/*  18:    */ import java.util.Enumeration;
/*  19:    */ import java.util.Hashtable;
/*  20:    */ import java.util.Iterator;
/*  21:    */ import java.util.Map.Entry;
/*  22:    */ import java.util.Set;
/*  23:    */ import java.util.Vector;
/*  24:    */ import javax.xml.parsers.DocumentBuilder;
/*  25:    */ import javax.xml.parsers.DocumentBuilderFactory;
/*  26:    */ import org.w3c.dom.Document;
/*  27:    */ import org.w3c.dom.Element;
/*  28:    */ import org.w3c.dom.NamedNodeMap;
/*  29:    */ import org.w3c.dom.Node;
/*  30:    */ import org.w3c.dom.NodeList;
/*  31:    */ 
/*  32:    */ public class TapjoyVideo
/*  33:    */ {
/*  34: 38 */   private static TapjoyVideo tapjoyVideo = null;
/*  35:    */   private static TapjoyVideoNotifier tapjoyVideoNotifier;
/*  36:    */   Context context;
/*  37: 42 */   private String videoCacheDir = null;
/*  38: 43 */   private String imageCacheDir = null;
/*  39: 45 */   private int videoCacheLimit = 5;
/*  40:    */   private Vector<String> videoQueue;
/*  41:    */   private Hashtable<String, TapjoyVideoObject> uncachedVideos;
/*  42:    */   private Hashtable<String, TapjoyVideoObject> cachedVideos;
/*  43: 51 */   private boolean cacheAuto = false;
/*  44: 52 */   private boolean initialized = false;
/*  45: 53 */   private boolean cacheWifi = false;
/*  46: 54 */   private boolean cache3g = false;
/*  47:    */   private TapjoyVideoObject videoToPlay;
/*  48:    */   private static final String watermarkURL = "https://s3.amazonaws.com/tapjoy/videos/assets/watermark.png";
/*  49:    */   private static Bitmap watermarkImage;
/*  50:    */   private static final String TAG = "TapjoyVideo";
/*  51:    */   
/*  52:    */   public TapjoyVideo(Context applicationContext)
/*  53:    */   {
/*  54: 69 */     this.context = applicationContext;
/*  55: 70 */     tapjoyVideo = this;
/*  56: 73 */     if (Environment.getExternalStorageDirectory() != null)
/*  57:    */     {
/*  58: 75 */       this.videoCacheDir = (Environment.getExternalStorageDirectory().toString() + "/tjcache/data/");
/*  59: 76 */       this.imageCacheDir = (Environment.getExternalStorageDirectory().toString() + "/tjcache/tmp/");
/*  60:    */       
/*  61:    */ 
/*  62: 79 */       TapjoyUtil.deleteFileOrDirectory(new File(Environment.getExternalStorageDirectory().toString() + "/tapjoy/"));
/*  63:    */       
/*  64:    */ 
/*  65: 82 */       TapjoyUtil.deleteFileOrDirectory(new File(this.imageCacheDir));
/*  66:    */     }
/*  67: 85 */     this.videoQueue = new Vector();
/*  68: 86 */     this.uncachedVideos = new Hashtable();
/*  69: 87 */     this.cachedVideos = new Hashtable();
/*  70: 90 */     if ((TapjoyConnectCore.getConnectFlagValue("video_cache_count") != null) && (TapjoyConnectCore.getConnectFlagValue("video_cache_count").length() > 0)) {
/*  71:    */       try
/*  72:    */       {
/*  73: 94 */         TapjoyLog.i("TapjoyVideo", "Setting video cache count to: " + TapjoyConnectCore.getConnectFlagValue("video_cache_count"));
/*  74: 95 */         int count = Integer.parseInt(TapjoyConnectCore.getConnectFlagValue("video_cache_count"));
/*  75: 96 */         setVideoCacheCount(count);
/*  76:    */       }
/*  77:    */       catch (Exception e)
/*  78:    */       {
/*  79:100 */         TapjoyLog.e("TapjoyVideo", "Error, invalid value for video_cache_count: " + TapjoyConnectCore.getConnectFlagValue("video_cache_count"));
/*  80:    */       }
/*  81:    */     }
/*  82:104 */     init();
/*  83:    */   }
/*  84:    */   
/*  85:    */   public static TapjoyVideo getInstance()
/*  86:    */   {
/*  87:114 */     return tapjoyVideo;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public void setVideoCacheCount(int count)
/*  91:    */   {
/*  92:124 */     this.videoCacheLimit = count;
/*  93:    */   }
/*  94:    */   
/*  95:    */   /**
/*  96:    */    * @deprecated
/*  97:    */    */
/*  98:    */   public void enableVideoCache(boolean enable) {}
/*  99:    */   
/* 100:    */   /**
/* 101:    */    * @deprecated
/* 102:    */    */
/* 103:    */   public void initVideoAd(TapjoyVideoNotifier notifier)
/* 104:    */   {
/* 105:146 */     initVideoAd(notifier, false);
/* 106:    */   }
/* 107:    */   
/* 108:    */   /**
/* 109:    */    * @deprecated
/* 110:    */    */
/* 111:    */   public void initVideoAd(TapjoyVideoNotifier notifier, boolean skipCaching)
/* 112:    */   {
/* 113:157 */     tapjoyVideoNotifier = notifier;
/* 114:159 */     if (notifier == null)
/* 115:    */     {
/* 116:161 */       Log.e("TapjoyVideo", "Error during initVideoAd -- TapjoyVideoNotifier is null");
/* 117:162 */       return;
/* 118:    */     }
/* 119:169 */     cacheVideos();
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void init()
/* 123:    */   {
/* 124:178 */     TapjoyLog.i("TapjoyVideo", "initVideoAd");
/* 125:181 */     if ((TapjoyConnectCore.getConnectFlagValue("disable_videos") != null) && (TapjoyConnectCore.getConnectFlagValue("disable_videos").equals("true")))
/* 126:    */     {
/* 127:183 */       TapjoyLog.i("TapjoyVideo", "disable_videos: " + TapjoyConnectCore.getConnectFlagValue("disable_videos") + ". Aborting video initializing... ");
/* 128:184 */       TapjoyConnectCore.setVideoEnabled(false);
/* 129:185 */       return;
/* 130:    */     }
/* 131:189 */     setVideoIDs();
/* 132:    */     
/* 133:    */ 
/* 134:192 */     new Thread(new Runnable()
/* 135:    */     {
/* 136:    */       public void run()
/* 137:    */       {
/* 138:196 */         boolean returnValue = false;
/* 139:    */         
/* 140:    */ 
/* 141:199 */         TapjoyHttpURLResponse response = new TapjoyURLConnection().getResponseFromURL(TapjoyConnectCore.getHostURL() + "videos?", TapjoyConnectCore.getURLParams());
/* 142:202 */         if ((response.response != null) && (response.response.length() > 0)) {
/* 143:204 */           returnValue = TapjoyVideo.this.handleGetVideosResponse(response.response);
/* 144:    */         }
/* 145:208 */         if (returnValue)
/* 146:    */         {
/* 147:211 */           TapjoyVideo.this.validateCachedVideos();
/* 148:214 */           if (("https://s3.amazonaws.com/tapjoy/videos/assets/watermark.png" != null) && ("https://s3.amazonaws.com/tapjoy/videos/assets/watermark.png".length() > 0)) {
/* 149:    */             try
/* 150:    */             {
/* 151:219 */               URL fileURL = new URL("https://s3.amazonaws.com/tapjoy/videos/assets/watermark.png");
/* 152:    */               
/* 153:221 */               URLConnection connection = fileURL.openConnection();
/* 154:222 */               connection.setConnectTimeout(15000);
/* 155:223 */               connection.setReadTimeout(25000);
/* 156:224 */               connection.connect();
/* 157:    */               
/* 158:226 */               TapjoyVideo.access$202(BitmapFactory.decodeStream(fileURL.openConnection().getInputStream()));
/* 159:    */               
/* 160:228 */               connection.getInputStream().close();
/* 161:    */             }
/* 162:    */             catch (Exception e)
/* 163:    */             {
/* 164:232 */               TapjoyLog.e("TapjoyVideo", "e: " + e.toString());
/* 165:    */             }
/* 166:    */           }
/* 167:237 */           TapjoyVideo.this.setVideoIDs();
/* 168:    */           
/* 169:    */ 
/* 170:240 */           TapjoyVideo.this.initialized = true;
/* 171:245 */           if (TapjoyVideo.this.cacheAuto)
/* 172:    */           {
/* 173:247 */             TapjoyLog.i("TapjoyVideo", "trying to cache because of cache_auto flag...");
/* 174:248 */             TapjoyVideo.this.cacheVideos();
/* 175:    */           }
/* 176:251 */           TapjoyLog.i("TapjoyVideo", "------------------------------");
/* 177:252 */           TapjoyLog.i("TapjoyVideo", "------------------------------");
/* 178:253 */           TapjoyLog.i("TapjoyVideo", "INIT DONE!");
/* 179:254 */           TapjoyLog.i("TapjoyVideo", "------------------------------");
/* 180:    */         }
/* 181:    */         else
/* 182:    */         {
/* 183:259 */           TapjoyVideo.videoNotifierError(2);
/* 184:    */         }
/* 185:    */       }
/* 186:263 */     }).start();
/* 187:264 */     TapjoyConnectCore.setVideoEnabled(true);
/* 188:    */   }
/* 189:    */   
/* 190:    */   private boolean handleGetVideosResponse(String response)
/* 191:    */   {
/* 192:275 */     DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 193:    */     
/* 194:    */ 
/* 195:278 */     TapjoyLog.i("TapjoyVideo", "========================================");
/* 196:    */     try
/* 197:    */     {
/* 198:283 */       InputStream is = new ByteArrayInputStream(response.getBytes("UTF-8"));
/* 199:    */       
/* 200:285 */       DocumentBuilder documentBuilder = factory.newDocumentBuilder();
/* 201:286 */       Document document = documentBuilder.parse(is);
/* 202:    */       
/* 203:    */ 
/* 204:289 */       document.getDocumentElement().normalize();
/* 205:    */       
/* 206:291 */       NodeList nodelistParent = document.getElementsByTagName("TapjoyVideos");
/* 207:292 */       NodeList nodelist = nodelistParent.item(0).getChildNodes();
/* 208:    */       
/* 209:    */ 
/* 210:    */ 
/* 211:296 */       NamedNodeMap nodeMap = nodelistParent.item(0).getAttributes();
/* 212:299 */       if ((nodeMap.getNamedItem("cache_auto") != null) && 
/* 213:300 */         (nodeMap.getNamedItem("cache_auto").getNodeValue() != null)) {
/* 214:301 */         this.cacheAuto = Boolean.valueOf(nodeMap.getNamedItem("cache_auto").getNodeValue()).booleanValue();
/* 215:    */       }
/* 216:304 */       if ((nodeMap.getNamedItem("cache_wifi") != null) && 
/* 217:305 */         (nodeMap.getNamedItem("cache_wifi").getNodeValue() != null)) {
/* 218:306 */         this.cacheWifi = Boolean.valueOf(nodeMap.getNamedItem("cache_wifi").getNodeValue()).booleanValue();
/* 219:    */       }
/* 220:309 */       if ((nodeMap.getNamedItem("cache_mobile") != null) && 
/* 221:310 */         (nodeMap.getNamedItem("cache_mobile").getNodeValue() != null)) {
/* 222:311 */         this.cache3g = Boolean.valueOf(nodeMap.getNamedItem("cache_mobile").getNodeValue()).booleanValue();
/* 223:    */       }
/* 224:313 */       TapjoyLog.i("TapjoyVideo", "cacheAuto: " + this.cacheAuto);
/* 225:314 */       TapjoyLog.i("TapjoyVideo", "cacheWifi: " + this.cacheWifi);
/* 226:315 */       TapjoyLog.i("TapjoyVideo", "cache3g: " + this.cache3g);
/* 227:    */       
/* 228:317 */       TapjoyLog.i("TapjoyVideo", "nodelistParent length: " + nodelistParent.getLength());
/* 229:318 */       TapjoyLog.i("TapjoyVideo", "nodelist length: " + nodelist.getLength());
/* 230:320 */       for (int i = 0; i < nodelist.getLength(); i++)
/* 231:    */       {
/* 232:322 */         Node node = nodelist.item(i);
/* 233:    */         
/* 234:    */ 
/* 235:325 */         TapjoyVideoObject videoObject = new TapjoyVideoObject();
/* 236:327 */         if ((node != null) && (node.getNodeType() == 1))
/* 237:    */         {
/* 238:329 */           Element element = (Element)node;
/* 239:    */           
/* 240:    */ 
/* 241:332 */           String value = TapjoyUtil.getNodeTrimValue(element.getElementsByTagName("ClickURL"));
/* 242:333 */           if ((value != null) && (!value.equals(""))) {
/* 243:334 */             videoObject.clickURL = value;
/* 244:    */           }
/* 245:336 */           value = TapjoyUtil.getNodeTrimValue(element.getElementsByTagName("OfferID"));
/* 246:337 */           if ((value != null) && (!value.equals(""))) {
/* 247:338 */             videoObject.offerID = value;
/* 248:    */           }
/* 249:340 */           value = TapjoyUtil.getNodeTrimValue(element.getElementsByTagName("Name"));
/* 250:341 */           if ((value != null) && (!value.equals(""))) {
/* 251:342 */             videoObject.videoAdName = value;
/* 252:    */           }
/* 253:344 */           value = TapjoyUtil.getNodeTrimValue(element.getElementsByTagName("Amount"));
/* 254:345 */           if ((value != null) && (!value.equals(""))) {
/* 255:346 */             videoObject.currencyAmount = value;
/* 256:    */           }
/* 257:348 */           value = TapjoyUtil.getNodeTrimValue(element.getElementsByTagName("CurrencyName"));
/* 258:349 */           if ((value != null) && (!value.equals(""))) {
/* 259:350 */             videoObject.currencyName = value;
/* 260:    */           }
/* 261:352 */           value = TapjoyUtil.getNodeTrimValue(element.getElementsByTagName("VideoURL"));
/* 262:353 */           if ((value != null) && (!value.equals(""))) {
/* 263:354 */             videoObject.videoURL = value;
/* 264:    */           }
/* 265:356 */           value = TapjoyUtil.getNodeTrimValue(element.getElementsByTagName("IconURL"));
/* 266:357 */           if ((value != null) && (!value.equals(""))) {
/* 267:358 */             videoObject.iconURL = value;
/* 268:    */           }
/* 269:360 */           TapjoyLog.i("TapjoyVideo", "-----");
/* 270:    */           
/* 271:362 */           TapjoyLog.i("TapjoyVideo", "videoObject.offerID: " + videoObject.offerID);
/* 272:363 */           TapjoyLog.i("TapjoyVideo", "videoObject.videoAdName: " + videoObject.videoAdName);
/* 273:    */           
/* 274:    */ 
/* 275:366 */           TapjoyLog.i("TapjoyVideo", "videoObject.videoURL: " + videoObject.videoURL);
/* 276:    */           
/* 277:    */ 
/* 278:369 */           NodeList buttonData = element.getElementsByTagName("Buttons");
/* 279:370 */           NodeList itemNodeList = buttonData.item(0).getChildNodes();
/* 280:375 */           for (int j = 0; j < itemNodeList.getLength(); j++)
/* 281:    */           {
/* 282:378 */             NodeList child = itemNodeList.item(j).getChildNodes();
/* 283:381 */             if (child.getLength() != 0)
/* 284:    */             {
/* 285:389 */               String name = "";
/* 286:390 */               String url = "";
/* 287:392 */               for (int k = 0; k < child.getLength(); k++) {
/* 288:394 */                 if ((Element)child.item(k) != null)
/* 289:    */                 {
/* 290:396 */                   String tagName = ((Element)child.item(k)).getTagName();
/* 291:399 */                   if ((tagName.equals("Name")) && (child.item(k).getFirstChild() != null)) {
/* 292:401 */                     name = child.item(k).getFirstChild().getNodeValue();
/* 293:405 */                   } else if ((tagName.equals("URL")) && (child.item(k).getFirstChild() != null)) {
/* 294:407 */                     url = child.item(k).getFirstChild().getNodeValue();
/* 295:    */                   }
/* 296:    */                 }
/* 297:    */               }
/* 298:412 */               TapjoyLog.i("TapjoyVideo", "name: " + name + ", url: " + url);
/* 299:    */               
/* 300:414 */               videoObject.addButton(name, url);
/* 301:    */             }
/* 302:    */           }
/* 303:418 */           this.videoQueue.addElement(videoObject.offerID);
/* 304:419 */           this.uncachedVideos.put(videoObject.offerID, videoObject);
/* 305:    */         }
/* 306:    */       }
/* 307:    */     }
/* 308:    */     catch (Exception e)
/* 309:    */     {
/* 310:425 */       TapjoyLog.e("TapjoyVideo", "Error parsing XML: " + e.toString());
/* 311:426 */       return false;
/* 312:    */     }
/* 313:429 */     TapjoyLog.i("TapjoyVideo", "========================================");
/* 314:    */     
/* 315:431 */     return true;
/* 316:    */   }
/* 317:    */   
/* 318:    */   public TapjoyVideoObject getCurrentVideoData()
/* 319:    */   {
/* 320:441 */     return this.videoToPlay;
/* 321:    */   }
/* 322:    */   
/* 323:    */   public boolean startVideo(String videoID, String currencyName, String currencyAmount, String clickURL, String webviewURL, String videoURL)
/* 324:    */   {
/* 325:451 */     boolean cachedVideo = true;
/* 326:452 */     TapjoyLog.i("TapjoyVideo", "Starting video activity with video: " + videoID);
/* 327:455 */     if ((videoID == null) || (clickURL == null) || (webviewURL == null) || (videoID.length() == 0) || (clickURL.length() == 0) || (webviewURL.length() == 0))
/* 328:    */     {
/* 329:457 */       TapjoyLog.i("TapjoyVideo", "aborting video playback... invalid or missing parameter");
/* 330:458 */       return false;
/* 331:    */     }
/* 332:461 */     this.videoToPlay = ((TapjoyVideoObject)this.cachedVideos.get(videoID));
/* 333:464 */     if (this.videoToPlay == null)
/* 334:    */     {
/* 335:466 */       TapjoyLog.i("TapjoyVideo", "video not cached... checking uncached videos");
/* 336:    */       
/* 337:468 */       this.videoToPlay = ((TapjoyVideoObject)this.uncachedVideos.get(videoID));
/* 338:471 */       if (this.videoToPlay == null) {
/* 339:474 */         if ((videoURL != null) && (videoURL.length() > 0))
/* 340:    */         {
/* 341:477 */           TapjoyVideoObject newVideo = new TapjoyVideoObject();
/* 342:478 */           newVideo.offerID = videoID;
/* 343:479 */           newVideo.currencyName = currencyName;
/* 344:480 */           newVideo.currencyAmount = currencyAmount;
/* 345:481 */           newVideo.clickURL = clickURL;
/* 346:482 */           newVideo.webviewURL = webviewURL;
/* 347:483 */           newVideo.videoURL = videoURL;
/* 348:484 */           this.uncachedVideos.put(videoID, newVideo);
/* 349:    */           
/* 350:486 */           this.videoToPlay = ((TapjoyVideoObject)this.uncachedVideos.get(videoID));
/* 351:    */         }
/* 352:    */         else
/* 353:    */         {
/* 354:490 */           TapjoyLog.e("TapjoyVideo", "no video data and no video url - aborting playback...");
/* 355:491 */           return false;
/* 356:    */         }
/* 357:    */       }
/* 358:496 */       cachedVideo = false;
/* 359:    */     }
/* 360:499 */     this.videoToPlay.currencyName = currencyName;
/* 361:500 */     this.videoToPlay.currencyAmount = currencyAmount;
/* 362:501 */     this.videoToPlay.clickURL = clickURL;
/* 363:502 */     this.videoToPlay.webviewURL = webviewURL;
/* 364:503 */     this.videoToPlay.videoURL = videoURL;
/* 365:    */     
/* 366:505 */     TapjoyLog.i("TapjoyVideo", "videoToPlay: " + this.videoToPlay.offerID);
/* 367:506 */     TapjoyLog.i("TapjoyVideo", "amount: " + this.videoToPlay.currencyAmount);
/* 368:507 */     TapjoyLog.i("TapjoyVideo", "currency: " + this.videoToPlay.currencyName);
/* 369:508 */     TapjoyLog.i("TapjoyVideo", "clickURL: " + this.videoToPlay.clickURL);
/* 370:509 */     TapjoyLog.i("TapjoyVideo", "location: " + this.videoToPlay.dataLocation);
/* 371:510 */     TapjoyLog.i("TapjoyVideo", "webviewURL: " + this.videoToPlay.webviewURL);
/* 372:511 */     TapjoyLog.i("TapjoyVideo", "videoURL: " + this.videoToPlay.videoURL);
/* 373:514 */     if ((cachedVideo) && (this.videoToPlay.dataLocation != null))
/* 374:    */     {
/* 375:516 */       File video = new File(this.videoToPlay.dataLocation);
/* 376:519 */       if ((video == null) || (!video.exists()))
/* 377:    */       {
/* 378:521 */         TapjoyLog.e("TapjoyVideo", "video file does not exist.");
/* 379:522 */         return false;
/* 380:    */       }
/* 381:    */     }
/* 382:526 */     Intent videoIntent = new Intent(this.context, TapjoyVideoView.class);
/* 383:527 */     videoIntent.setFlags(268435456);
/* 384:    */     
/* 385:    */ 
/* 386:530 */     videoIntent.putExtra("VIDEO_DATA", this.videoToPlay);
/* 387:531 */     this.context.startActivity(videoIntent);
/* 388:    */     
/* 389:533 */     return true;
/* 390:    */   }
/* 391:    */   
/* 392:    */   public void cacheVideos()
/* 393:    */   {
/* 394:542 */     new Thread(new Runnable()
/* 395:    */     {
/* 396:    */       public void run()
/* 397:    */       {
/* 398:547 */         TapjoyLog.i("TapjoyVideo", "--- cacheAllVideos called ---");
/* 399:    */         
/* 400:549 */         long SLEEP_TIME = 500L;
/* 401:550 */         long TIMEOUT = 10000L;
/* 402:551 */         int elapsed = 0;
/* 403:554 */         while (!TapjoyVideo.this.initialized) {
/* 404:    */           try
/* 405:    */           {
/* 406:558 */             Thread.sleep(500L);
/* 407:559 */             elapsed = (int)(elapsed + 500L);
/* 408:562 */             if (elapsed > 10000L)
/* 409:    */             {
/* 410:564 */               TapjoyLog.e("TapjoyVideo", "Error during cacheVideos.  Timeout while waiting for initVideos to finish.");
/* 411:565 */               return;
/* 412:    */             }
/* 413:    */           }
/* 414:    */           catch (Exception e)
/* 415:    */           {
/* 416:570 */             TapjoyLog.e("TapjoyVideo", "Exception in cacheAllVideos: " + e.toString());
/* 417:    */           }
/* 418:    */         }
/* 419:574 */         TapjoyLog.i("TapjoyVideo", "cacheVideos connection_type: " + TapjoyConnectCore.getConnectionType());
/* 420:575 */         TapjoyLog.i("TapjoyVideo", "cache3g: " + TapjoyVideo.this.cache3g);
/* 421:576 */         TapjoyLog.i("TapjoyVideo", "cacheWifi: " + TapjoyVideo.this.cacheWifi);
/* 422:579 */         if (((TapjoyVideo.this.cache3g) && (TapjoyConnectCore.getConnectionType().equals("mobile"))) || ((TapjoyVideo.this.cacheWifi) && (TapjoyConnectCore.getConnectionType().equals("wifi"))))
/* 423:    */         {
/* 424:582 */           String state = Environment.getExternalStorageState();
/* 425:585 */           if (!"mounted".equals(state))
/* 426:    */           {
/* 427:587 */             TapjoyLog.i("TapjoyVideo", "Media storage unavailable.  Aborting caching videos.");
/* 428:    */             
/* 429:    */ 
/* 430:590 */             TapjoyVideo.videoNotifierError(1);
/* 431:591 */             return;
/* 432:    */           }
/* 433:595 */           while ((TapjoyVideo.this.cachedVideos.size() < TapjoyVideo.this.videoCacheLimit) && (TapjoyVideo.this.videoQueue.size() > 0))
/* 434:    */           {
/* 435:597 */             String url = ((TapjoyVideoObject)TapjoyVideo.this.uncachedVideos.get(TapjoyVideo.this.videoQueue.elementAt(0))).videoURL;
/* 436:598 */             TapjoyVideo.this.cacheVideoFromURL(url);
/* 437:    */           }
/* 438:    */         }
/* 439:    */         else
/* 440:    */         {
/* 441:603 */           TapjoyLog.i("TapjoyVideo", " * Skipping caching videos because of video flags and connection_type...");
/* 442:    */         }
/* 443:606 */         TapjoyVideo.this.printCachedVideos();
/* 444:    */       }
/* 445:    */     }).start();
/* 446:    */   }
/* 447:    */   
/* 448:    */   private void printCachedVideos()
/* 449:    */   {
/* 450:614 */     TapjoyLog.i("TapjoyVideo", "cachedVideos size: " + this.cachedVideos.size());
/* 451:    */     
/* 452:    */ 
/* 453:617 */     Set<Map.Entry<String, TapjoyVideoObject>> entries = this.cachedVideos.entrySet();
/* 454:618 */     Iterator<Map.Entry<String, TapjoyVideoObject>> iterator = entries.iterator();
/* 455:620 */     while (iterator.hasNext())
/* 456:    */     {
/* 457:622 */       Map.Entry<String, TapjoyVideoObject> item = (Map.Entry)iterator.next();
/* 458:623 */       TapjoyLog.i("TapjoyVideo", "key: " + (String)item.getKey() + ", name: " + ((TapjoyVideoObject)item.getValue()).videoAdName);
/* 459:    */     }
/* 460:    */   }
/* 461:    */   
/* 462:    */   private void cacheVideoFromURL(String url)
/* 463:    */   {
/* 464:634 */     TapjoyLog.i("TapjoyVideo", "download and cache video from: " + url);
/* 465:    */     
/* 466:636 */     long time = System.currentTimeMillis();
/* 467:    */     
/* 468:638 */     boolean networkTimeout = false;
/* 469:639 */     boolean downloadError = false;
/* 470:    */     
/* 471:641 */     BufferedInputStream inputStream = null;
/* 472:642 */     OutputStream out = null;
/* 473:    */     
/* 474:644 */     String fileName = null;
/* 475:645 */     String path = null;
/* 476:646 */     File savedFile = null;
/* 477:    */     try
/* 478:    */     {
/* 479:650 */       URL fileURL = new URL(url);
/* 480:651 */       URLConnection connection = fileURL.openConnection();
/* 481:652 */       connection.setConnectTimeout(15000);
/* 482:653 */       connection.setReadTimeout(30000);
/* 483:654 */       connection.connect();
/* 484:    */       
/* 485:656 */       inputStream = new BufferedInputStream(connection.getInputStream());
/* 486:    */       
/* 487:    */ 
/* 488:    */ 
/* 489:660 */       File fileDir = new File(this.videoCacheDir);
/* 490:    */       
/* 491:662 */       path = url.substring(0, url.lastIndexOf("/") + 1);
/* 492:663 */       fileName = url.substring(url.lastIndexOf("/") + 1);
/* 493:    */       
/* 494:    */ 
/* 495:666 */       fileName = fileName.substring(0, fileName.indexOf('.'));
/* 496:    */       
/* 497:668 */       TapjoyLog.i("TapjoyVideo", "fileDir: " + fileDir);
/* 498:669 */       TapjoyLog.i("TapjoyVideo", "path: " + path);
/* 499:670 */       TapjoyLog.i("TapjoyVideo", "file name: " + fileName);
/* 500:674 */       if (fileDir.mkdirs()) {
/* 501:675 */         TapjoyLog.i("TapjoyVideo", "created directory at: " + fileDir.getPath());
/* 502:    */       }
/* 503:677 */       savedFile = new File(this.videoCacheDir, fileName);
/* 504:678 */       out = new FileOutputStream(savedFile);
/* 505:    */       
/* 506:680 */       TapjoyLog.i("TapjoyVideo", "downloading video file to: " + savedFile.toString());
/* 507:    */       
/* 508:682 */       byte[] buf = new byte[1024];
/* 509:    */       int len;
/* 510:685 */       while ((len = inputStream.read(buf)) != -1) {
/* 511:687 */         out.write(buf, 0, len);
/* 512:    */       }
/* 513:690 */       out.close();
/* 514:691 */       inputStream.close();
/* 515:    */       
/* 516:693 */       TapjoyLog.i("TapjoyVideo", "FILE SIZE: " + savedFile.length());
/* 517:696 */       if (savedFile.length() == 0L) {
/* 518:697 */         networkTimeout = true;
/* 519:    */       }
/* 520:    */     }
/* 521:    */     catch (SocketTimeoutException e)
/* 522:    */     {
/* 523:701 */       TapjoyLog.e("TapjoyVideo", "Network timeout: " + e.toString());
/* 524:702 */       networkTimeout = true;
/* 525:703 */       downloadError = true;
/* 526:    */     }
/* 527:    */     catch (Exception e)
/* 528:    */     {
/* 529:707 */       TapjoyLog.e("TapjoyVideo", "Error caching video file: " + e.toString());
/* 530:708 */       downloadError = true;
/* 531:    */     }
/* 532:711 */     if (networkTimeout == true)
/* 533:    */     {
/* 534:713 */       TapjoyLog.i("TapjoyVideo", "Network timeout");
/* 535:    */       try
/* 536:    */       {
/* 537:718 */         inputStream.close();
/* 538:719 */         out.close();
/* 539:    */       }
/* 540:    */       catch (Exception e) {}
/* 541:    */     }
/* 542:728 */     if ((!networkTimeout) && (!downloadError)) {
/* 543:    */       try
/* 544:    */       {
/* 545:733 */         String key = (String)this.videoQueue.elementAt(0);
/* 546:734 */         TapjoyVideoObject newVideo = (TapjoyVideoObject)this.uncachedVideos.get(key);
/* 547:    */         
/* 548:736 */         newVideo.dataLocation = savedFile.getAbsolutePath();
/* 549:    */         
/* 550:    */ 
/* 551:739 */         this.cachedVideos.put(key, newVideo);
/* 552:740 */         this.uncachedVideos.remove(key);
/* 553:741 */         this.videoQueue.removeElementAt(0);
/* 554:    */         
/* 555:743 */         setVideoIDs();
/* 556:    */         
/* 557:745 */         TapjoyLog.i("TapjoyVideo", "video cached in: " + (System.currentTimeMillis() - time) + "ms");
/* 558:    */       }
/* 559:    */       catch (Exception e)
/* 560:    */       {
/* 561:749 */         TapjoyLog.e("TapjoyVideo", "error caching video ???: " + e.toString());
/* 562:    */       }
/* 563:    */     } else {
/* 564:755 */       videoNotifierError(2);
/* 565:    */     }
/* 566:    */   }
/* 567:    */   
/* 568:    */   private void setVideoIDs()
/* 569:    */   {
/* 570:765 */     String videoIDs = "";
/* 571:767 */     if ((this.cachedVideos != null) && (this.cachedVideos.size() > 0))
/* 572:    */     {
/* 573:769 */       Enumeration<String> keys = this.cachedVideos.keys();
/* 574:771 */       while (keys.hasMoreElements())
/* 575:    */       {
/* 576:773 */         String key = (String)keys.nextElement();
/* 577:774 */         videoIDs = videoIDs + key;
/* 578:776 */         if (keys.hasMoreElements()) {
/* 579:777 */           videoIDs = videoIDs + ",";
/* 580:    */         }
/* 581:    */       }
/* 582:780 */       TapjoyLog.i("TapjoyVideo", "cachedVideos size: " + this.cachedVideos.size());
/* 583:    */     }
/* 584:783 */     TapjoyLog.i("TapjoyVideo", "videoIDs: [" + videoIDs + "]");
/* 585:784 */     TapjoyConnectCore.setVideoIDs(videoIDs);
/* 586:    */   }
/* 587:    */   
/* 588:    */   private boolean validateCachedVideos()
/* 589:    */   {
/* 590:790 */     boolean success = false;
/* 591:791 */     boolean proceed = true;
/* 592:    */     
/* 593:    */ 
/* 594:794 */     File[] cachedFilesOnDisk = new File(this.videoCacheDir).listFiles();
/* 595:796 */     if (this.uncachedVideos == null)
/* 596:    */     {
/* 597:798 */       TapjoyLog.e("TapjoyVideo", "Error: uncachedVideos is null");
/* 598:799 */       proceed = false;
/* 599:    */     }
/* 600:802 */     if (this.cachedVideos == null)
/* 601:    */     {
/* 602:804 */       TapjoyLog.e("TapjoyVideo", "Error: cachedVideos is null");
/* 603:805 */       proceed = false;
/* 604:    */     }
/* 605:808 */     if (this.videoQueue == null)
/* 606:    */     {
/* 607:810 */       TapjoyLog.e("TapjoyVideo", "Error: videoQueue is null");
/* 608:811 */       proceed = false;
/* 609:    */     }
/* 610:815 */     if ((proceed) && (cachedFilesOnDisk != null))
/* 611:    */     {
/* 612:818 */       for (int i = 0; i < cachedFilesOnDisk.length; i++)
/* 613:    */       {
/* 614:820 */         String key = cachedFilesOnDisk[i].getName();
/* 615:    */         
/* 616:    */ 
/* 617:823 */         TapjoyLog.i("TapjoyVideo", "-----");
/* 618:824 */         TapjoyLog.i("TapjoyVideo", "Examining cached file[" + i + "]: " + cachedFilesOnDisk[i].getAbsolutePath() + " --- " + cachedFilesOnDisk[i].getName());
/* 619:829 */         if (this.uncachedVideos.containsKey(key))
/* 620:    */         {
/* 621:831 */           TapjoyLog.i("TapjoyVideo", "Local file found");
/* 622:    */           
/* 623:833 */           TapjoyVideoObject videoObject = (TapjoyVideoObject)this.uncachedVideos.get(key);
/* 624:835 */           if (videoObject == null)
/* 625:    */           {
/* 626:837 */             success = false;
/* 627:    */           }
/* 628:    */           else
/* 629:    */           {
/* 630:841 */             String contentLength = new TapjoyURLConnection().getContentLength(videoObject.videoURL);
/* 631:    */             
/* 632:843 */             TapjoyLog.i("TapjoyVideo", "local file size: " + cachedFilesOnDisk[i].length() + " vs. target: " + contentLength);
/* 633:846 */             if ((contentLength != null) && (Integer.parseInt(contentLength) == cachedFilesOnDisk[i].length()))
/* 634:    */             {
/* 635:848 */               videoObject.dataLocation = cachedFilesOnDisk[i].getAbsolutePath();
/* 636:849 */               this.cachedVideos.put(key, videoObject);
/* 637:850 */               this.uncachedVideos.remove(key);
/* 638:851 */               this.videoQueue.remove(key);
/* 639:    */               
/* 640:853 */               TapjoyLog.i("TapjoyVideo", "VIDEO PREVIOUSLY CACHED -- " + key + ", location: " + videoObject.dataLocation);
/* 641:    */             }
/* 642:    */             else
/* 643:    */             {
/* 644:858 */               TapjoyLog.i("TapjoyVideo", "file size mismatch --- deleting video: " + cachedFilesOnDisk[i].getAbsolutePath());
/* 645:859 */               TapjoyUtil.deleteFileOrDirectory(cachedFilesOnDisk[i]);
/* 646:    */             }
/* 647:    */           }
/* 648:    */         }
/* 649:    */         else
/* 650:    */         {
/* 651:866 */           TapjoyLog.i("TapjoyVideo", "VIDEO EXPIRED? removing video from cache: " + key + " --- " + cachedFilesOnDisk[i].getAbsolutePath());
/* 652:867 */           TapjoyUtil.deleteFileOrDirectory(cachedFilesOnDisk[i]);
/* 653:    */         }
/* 654:    */       }
/* 655:871 */       success = true;
/* 656:    */     }
/* 657:874 */     return success;
/* 658:    */   }
/* 659:    */   
/* 660:    */   public void setVideoNotifier(TapjoyVideoNotifier notifier)
/* 661:    */   {
/* 662:883 */     tapjoyVideoNotifier = notifier;
/* 663:    */   }
/* 664:    */   
/* 665:    */   public static void videoNotifierError(int error)
/* 666:    */   {
/* 667:893 */     if (tapjoyVideoNotifier != null) {
/* 668:894 */       tapjoyVideoNotifier.videoError(error);
/* 669:    */     }
/* 670:    */   }
/* 671:    */   
/* 672:    */   public static void videoNotifierStart()
/* 673:    */   {
/* 674:913 */     if (tapjoyVideoNotifier != null) {
/* 675:914 */       tapjoyVideoNotifier.videoStart();
/* 676:    */     }
/* 677:    */   }
/* 678:    */   
/* 679:    */   public static void videoNotifierComplete()
/* 680:    */   {
/* 681:923 */     if (tapjoyVideoNotifier != null) {
/* 682:924 */       tapjoyVideoNotifier.videoComplete();
/* 683:    */     }
/* 684:    */   }
/* 685:    */   
/* 686:    */   public static Bitmap getWatermarkImage()
/* 687:    */   {
/* 688:934 */     return watermarkImage;
/* 689:    */   }
/* 690:    */ }


/* Location:           C:\Documents and Settings\Administrator\桌面\tapjoyconnectlibrary.jar
 * Qualified Name:     com.tapjoy.TapjoyVideo
 * JD-Core Version:    0.7.0.1
 */