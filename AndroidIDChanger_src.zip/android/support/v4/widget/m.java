package android.support.v4.widget;

class m
  implements k
{
  public void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    o.a(paramObject, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  public boolean a(Object paramObject)
  {
    return o.a(paramObject);
  }
  
  public int b(Object paramObject)
  {
    return o.b(paramObject);
  }
  
  public int c(Object paramObject)
  {
    return o.c(paramObject);
  }
  
  public boolean d(Object paramObject)
  {
    return o.d(paramObject);
  }
  
  public void e(Object paramObject)
  {
    o.e(paramObject);
  }
  
  public int f(Object paramObject)
  {
    return o.f(paramObject);
  }
  
  public int g(Object paramObject)
  {
    return o.g(paramObject);
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.m
 * JD-Core Version:    0.7.0.1
 */