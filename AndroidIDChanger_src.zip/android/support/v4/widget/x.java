package android.support.v4.widget;

import android.view.View;

class x
  extends v
{
  public void a(SlidingPaneLayout paramSlidingPaneLayout, View paramView)
  {
    android.support.v4.view.x.a(paramView, ((r)paramView.getLayoutParams()).d);
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.x
 * JD-Core Version:    0.7.0.1
 */