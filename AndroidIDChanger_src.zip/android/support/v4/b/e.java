package android.support.v4.b;

import android.os.Parcelable.Creator;

class e
{
  static Parcelable.Creator a(c paramc)
  {
    return new d(paramc);
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.b.e
 * JD-Core Version:    0.7.0.1
 */