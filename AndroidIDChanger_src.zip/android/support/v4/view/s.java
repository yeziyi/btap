package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.VelocityTracker;

public class s
{
  static final v a = new t();
  
  static
  {
    if (Build.VERSION.SDK_INT >= 11)
    {
      a = new u();
      return;
    }
  }
  
  public static float a(VelocityTracker paramVelocityTracker, int paramInt)
  {
    return a.a(paramVelocityTracker, paramInt);
  }
  
  public static float b(VelocityTracker paramVelocityTracker, int paramInt)
  {
    return a.b(paramVelocityTracker, paramInt);
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.s
 * JD-Core Version:    0.7.0.1
 */