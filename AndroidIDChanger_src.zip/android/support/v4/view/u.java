package android.support.v4.view;

import android.view.VelocityTracker;

class u
  implements v
{
  public float a(VelocityTracker paramVelocityTracker, int paramInt)
  {
    return w.a(paramVelocityTracker, paramInt);
  }
  
  public float b(VelocityTracker paramVelocityTracker, int paramInt)
  {
    return w.b(paramVelocityTracker, paramInt);
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.u
 * JD-Core Version:    0.7.0.1
 */