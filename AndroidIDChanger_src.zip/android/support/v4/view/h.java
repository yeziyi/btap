package android.support.v4.view;

import android.view.KeyEvent;

class h
  extends g
{
  public void a(KeyEvent paramKeyEvent)
  {
    k.a(paramKeyEvent);
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.h
 * JD-Core Version:    0.7.0.1
 */