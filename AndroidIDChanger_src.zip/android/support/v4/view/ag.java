package android.support.v4.view;

import android.graphics.Paint;
import android.view.View;

abstract interface ag
{
  public abstract int a(View paramView);
  
  public abstract void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract void a(View paramView, int paramInt, Paint paramPaint);
  
  public abstract void a(View paramView, Paint paramPaint);
  
  public abstract void a(View paramView, Runnable paramRunnable);
  
  public abstract boolean a(View paramView, int paramInt);
  
  public abstract void b(View paramView);
  
  public abstract int c(View paramView);
  
  public abstract int d(View paramView);
  
  public abstract boolean e(View paramView);
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ag
 * JD-Core Version:    0.7.0.1
 */