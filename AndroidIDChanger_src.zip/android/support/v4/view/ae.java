package android.support.v4.view;

import android.graphics.Paint;
import android.view.View;

class ae
  extends ad
{
  public void a(View paramView, Paint paramPaint)
  {
    am.a(paramView, paramPaint);
  }
  
  public int d(View paramView)
  {
    return am.a(paramView);
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ae
 * JD-Core Version:    0.7.0.1
 */