package android.support.v4.view;

import android.database.DataSetObserver;

class av
  extends DataSetObserver
{
  private av(ViewPager paramViewPager) {}
  
  public void onChanged()
  {
    this.a.a();
  }
  
  public void onInvalidated()
  {
    this.a.a();
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.av
 * JD-Core Version:    0.7.0.1
 */