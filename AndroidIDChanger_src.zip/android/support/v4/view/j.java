package android.support.v4.view;

import android.view.KeyEvent;

abstract interface j
{
  public abstract void a(KeyEvent paramKeyEvent);
  
  public abstract boolean a(int paramInt1, int paramInt2);
  
  public abstract boolean b(int paramInt);
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.j
 * JD-Core Version:    0.7.0.1
 */