package android.support.v4.view;

import android.view.View;

class z
  extends y
{
  public boolean e(View paramView)
  {
    return ah.a(paramView);
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.z
 * JD-Core Version:    0.7.0.1
 */