package android.support.v4.view;

import android.view.View;
import java.util.Comparator;

class ax
  implements Comparator
{
  public int a(View paramView1, View paramView2)
  {
    ar localar1 = (ar)paramView1.getLayoutParams();
    ar localar2 = (ar)paramView2.getLayoutParams();
    if (localar1.a != localar2.a)
    {
      if (localar1.a) {
        return 1;
      }
      return -1;
    }
    return localar1.e - localar2.e;
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ax
 * JD-Core Version:    0.7.0.1
 */