package android.support.v4.app;

import android.os.Bundle;
import android.support.v4.a.a;

public abstract interface x
{
  public abstract a a(int paramInt, Bundle paramBundle);
  
  public abstract void a(a parama);
  
  public abstract void a(a parama, Object paramObject);
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.x
 * JD-Core Version:    0.7.0.1
 */