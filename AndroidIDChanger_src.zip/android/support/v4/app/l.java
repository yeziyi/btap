package android.support.v4.app;

public abstract class l
{
  public abstract Fragment a(String paramString);
  
  public abstract v a();
  
  public abstract boolean b();
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.l
 * JD-Core Version:    0.7.0.1
 */