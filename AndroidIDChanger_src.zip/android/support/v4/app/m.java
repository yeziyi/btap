package android.support.v4.app;

public abstract interface m
{
  public abstract void a();
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.m
 * JD-Core Version:    0.7.0.1
 */