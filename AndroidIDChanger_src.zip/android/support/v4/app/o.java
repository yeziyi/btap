package android.support.v4.app;

class o
  implements Runnable
{
  o(n paramn) {}
  
  public void run()
  {
    this.a.e();
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.o
 * JD-Core Version:    0.7.0.1
 */