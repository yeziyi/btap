package android.support.v4.app;

public abstract class v
{
  public abstract int a();
  
  public abstract v a(int paramInt, Fragment paramFragment, String paramString);
  
  public abstract v a(Fragment paramFragment);
  
  public abstract v b(Fragment paramFragment);
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.v
 * JD-Core Version:    0.7.0.1
 */