package com.liamw.root.androididchanger;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class i
  implements DialogInterface.OnClickListener
{
  i(h paramh) {}
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    h.a(this.a).a.cancel();
    h.a(this.a).finish();
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.liamw.root.androididchanger.i
 * JD-Core Version:    0.7.0.1
 */