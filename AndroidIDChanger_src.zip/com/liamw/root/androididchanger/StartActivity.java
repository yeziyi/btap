package com.liamw.root.androididchanger;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;

public class StartActivity
  extends Activity
{
  ProgressDialog a;
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    this.a = new ProgressDialog(this);
    this.a.setProgressStyle(0);
    this.a.setTitle("Please Wait");
    this.a.setMessage("Please wait while we confirm root access...");
    this.a.setCancelable(false);
    h localh = new h(this);
    this.a.show();
    localh.start();
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.liamw.root.androididchanger.StartActivity
 * JD-Core Version:    0.7.0.1
 */