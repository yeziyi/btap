package com.liamw.root.androididchanger;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings.Secure;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class BackupActivity
  extends Activity
  implements View.OnClickListener
{
  File a;
  File b;
  TextView c;
  TextView d;
  Button e;
  Button f;
  Boolean g = Boolean.valueOf(false);
  
  private Boolean a(String paramString)
  {
    if (checkCallingOrSelfPermission(paramString) == 0) {
      return Boolean.valueOf(true);
    }
    return Boolean.valueOf(false);
  }
  
  public void a()
  {
    a(Settings.Secure.getString(getContentResolver(), "android_id"), this.b);
  }
  
  public void a(String paramString, File paramFile)
  {
    new File(Environment.getExternalStorageDirectory() + "/idchanger/backup").mkdirs();
    try
    {
      OutputStreamWriter localOutputStreamWriter = new OutputStreamWriter(new FileOutputStream(paramFile));
      localOutputStreamWriter.write(paramString);
      localOutputStreamWriter.close();
      return;
    }
    catch (IOException localIOException)
    {
      Log.w("ExternalStorage", "Error writing " + paramFile, localIOException);
    }
  }
  
  public void b()
  {
    if (!this.b.exists())
    {
      this.c.setText(getString(2131034132));
      this.d.setText(getString(2131034133) + ": -");
      this.e.setEnabled(false);
      this.f.setEnabled(true);
      return;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    for (;;)
    {
      try
      {
        BufferedReader localBufferedReader = new BufferedReader(new FileReader(this.b));
        str = localBufferedReader.readLine();
        if (str != null) {
          continue;
        }
        localBufferedReader.close();
      }
      catch (IOException localIOException)
      {
        String str;
        localIOException.printStackTrace();
        continue;
      }
      this.c.setText(getString(2131034134) + this.b.getAbsolutePath());
      this.d.setText(getString(2131034133) + ":" + localStringBuilder.toString());
      this.e.setEnabled(true);
      this.f.setEnabled(false);
      return;
      localStringBuilder.append(str);
    }
  }
  
  public void onClick(View paramView)
  {
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131230722: 
      a();
      b();
      return;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    for (;;)
    {
      try
      {
        BufferedReader localBufferedReader = new BufferedReader(new FileReader(this.b));
        str2 = localBufferedReader.readLine();
        if (str2 != null) {
          continue;
        }
        localBufferedReader.close();
      }
      catch (IOException localIOException)
      {
        String str2;
        String str1;
        localIOException.printStackTrace();
        continue;
        Toast.makeText(this, "We don't have the Write Secure Settings permission. Please restart the app.", 1).show();
        continue;
      }
      str1 = localStringBuilder.toString();
      this.g = a("android.permission.WRITE_SECURE_SETTINGS");
      Log.i("BackupActivity", "Has WSSPERMISSION: " + this.g);
      if (!this.g.booleanValue()) {
        continue;
      }
      Settings.Secure.putString(getContentResolver(), "android_id", str1);
      this.b.delete();
      Toast.makeText(this, "Done!", 0).show();
      b();
      return;
      localStringBuilder.append(str2);
    }
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903040);
    Log.d("BackupActivity", "Starting Activity");
    this.a = Environment.getExternalStorageDirectory();
    this.b = new File(this.a, "idchanger/backup/backup.txt");
    this.c = ((TextView)findViewById(2131230720));
    this.d = ((TextView)findViewById(2131230721));
    this.e = ((Button)findViewById(2131230723));
    this.f = ((Button)findViewById(2131230722));
    this.e.setOnClickListener(this);
    this.f.setOnClickListener(this);
    b();
    Log.d("BackupActivity", "OnCreate Finished");
  }
  
  protected void onResume()
  {
    super.onResume();
    b();
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.liamw.root.androididchanger.BackupActivity
 * JD-Core Version:    0.7.0.1
 */