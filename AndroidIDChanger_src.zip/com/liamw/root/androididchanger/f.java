package com.liamw.root.androididchanger;

import android.os.Build.VERSION;
import com.liamw.root.a.c;

class f
  extends Thread
{
  f(e parame) {}
  
  public void run()
  {
    if (Build.VERSION.SDK_INT == 19) {}
    for (boolean bool = true; Boolean.valueOf(bool).booleanValue(); bool = false)
    {
      c.a("mount -o remount,rw /system");
      c.a("mount -o remount,rw /data");
      c.a("cp /data/app/com.liamw.root.androididchanger-1.apk /system/priv-app/com.liamw.root.androididchanger.apk");
      c.a("cp /data/app/com.liamw.root.androididchanger-2.apk /system/priv-app/com.liamw.root.androididchanger.apk");
      c.a("cp /data/app/com.liamw.root.androididchanger.apk /system/priv-app/com.liamw.root.androididchanger.apk");
      c.a("rm -f /data/app/com.liamw.root.androididchanger-1.apk");
      c.a("rm -f /data/app/com.liamw.root.androididchanger-2.apk");
      c.a("rm -f /data/app/com.liamw.root.androididchanger.apk");
      c.a("chmod 0655 /system/app/com.liamw.root.androididchanger.apk");
      c.a("reboot");
      return;
    }
    c.a("mount -o remount,rw /system");
    c.a("mount -o remount,rw /data");
    c.a("cp /data/app/com.liamw.root.androididchanger-1.apk /system/app/com.liamw.root.androididchanger.apk");
    c.a("cp /data/app/com.liamw.root.androididchanger-2.apk /system/app/com.liamw.root.androididchanger.apk");
    c.a("cp /data/app/com.liamw.root.androididchanger.apk /system/app/com.liamw.root.androididchanger.apk");
    c.a("rm -f /data/app/com.liamw.root.androididchanger-1.apk");
    c.a("rm -f /data/app/com.liamw.root.androididchanger-2.apk");
    c.a("rm -f /data/app/com.liamw.root.androididchanger.apk");
    c.a("chmod 0655 /system/app/com.liamw.root.androididchanger.apk");
    c.a("reboot");
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.liamw.root.androididchanger.f
 * JD-Core Version:    0.7.0.1
 */