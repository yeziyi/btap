package com.liamw.root.androididchanger;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.net.Uri;

class g
  implements DialogInterface.OnClickListener
{
  g(MainActivity paramMainActivity) {}
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    Intent localIntent = new Intent("android.intent.action.DELETE", Uri.parse("package:" + MainActivity.class.getPackage().getName()));
    this.a.startActivity(localIntent);
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.liamw.root.androididchanger.g
 * JD-Core Version:    0.7.0.1
 */