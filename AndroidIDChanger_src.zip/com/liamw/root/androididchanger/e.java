package com.liamw.root.androididchanger;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class e
  implements DialogInterface.OnClickListener
{
  e(MainActivity paramMainActivity) {}
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    new f(this).start();
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.liamw.root.androididchanger.e
 * JD-Core Version:    0.7.0.1
 */