package com.liamw.root.androididchanger;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import java.util.Random;

public class GenerateActivity
  extends Activity
{
  public String a()
  {
    return String.valueOf("abcdefghijklmnopqrstuvwxyz".charAt(new Random().nextInt("abcdefghijklmnopqrstuvwxyz".length())));
  }
  
  public Integer b()
  {
    return Integer.valueOf(0 + new Random().nextInt(10));
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    String str = a() + b().toString() + b().toString() + b().toString() + b().toString() + b().toString() + a() + b().toString() + a() + a() + a() + b().toString() + a() + b().toString() + a() + b().toString();
    Intent localIntent = new Intent();
    localIntent.putExtra("genid", str);
    setResult(-1, localIntent);
    finish();
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.liamw.root.androididchanger.GenerateActivity
 * JD-Core Version:    0.7.0.1
 */