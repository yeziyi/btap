package com.liamw.root.androididchanger;

import com.liamw.root.a.c;

class d
  extends Thread
{
  d(MainActivity paramMainActivity) {}
  
  public void run()
  {
    super.run();
    c.a("pm grant com.liamw.root.androididchanger android.permission.WRITE_SECURE_SETTINGS");
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.liamw.root.androididchanger.d
 * JD-Core Version:    0.7.0.1
 */