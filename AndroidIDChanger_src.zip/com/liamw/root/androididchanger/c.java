package com.liamw.root.androididchanger;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.SharedPreferences.Editor;
import android.widget.Toast;

class c
  implements DialogInterface.OnClickListener
{
  c(MainActivity paramMainActivity, AlertDialog.Builder paramBuilder) {}
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    this.b.create().cancel();
    this.a.g.putBoolean("rdisplay", false);
    this.a.g.commit();
    Toast.makeText(this.a, "Aw :(", 0).show();
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.liamw.root.androididchanger.c
 * JD-Core Version:    0.7.0.1
 */