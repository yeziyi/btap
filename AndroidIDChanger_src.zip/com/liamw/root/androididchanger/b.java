package com.liamw.root.androididchanger;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.widget.Toast;

class b
  implements DialogInterface.OnClickListener
{
  b(MainActivity paramMainActivity, AlertDialog.Builder paramBuilder) {}
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    this.b.create().cancel();
    Toast.makeText(this.a, "I'll let you decide on the next open, or the one after that, or the one after that and so on... ;)", 1).show();
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.liamw.root.androididchanger.b
 * JD-Core Version:    0.7.0.1
 */