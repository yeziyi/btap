package com.liamw.root.androididchanger;

import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Intent;
import com.liamw.root.a.c;

class h
  extends Thread
{
  h(StartActivity paramStartActivity) {}
  
  public void run()
  {
    if (!Boolean.valueOf(c.a()).booleanValue())
    {
      AlertDialog.Builder localBuilder = new AlertDialog.Builder(this.a);
      localBuilder.setTitle("Root Error!");
      localBuilder.setMessage("I was unable to successfully gain root access. Please ensure your device is rooted and you have allowed this app root access.");
      localBuilder.setCancelable(false);
      localBuilder.setNeutralButton("Exit", new i(this));
      this.a.runOnUiThread(new j(this, localBuilder));
      return;
    }
    this.a.a.cancel();
    Intent localIntent = new Intent(this.a, MainActivity.class);
    this.a.startActivity(localIntent);
    this.a.finish();
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.liamw.root.androididchanger.h
 * JD-Core Version:    0.7.0.1
 */