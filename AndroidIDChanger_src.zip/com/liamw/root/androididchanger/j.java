package com.liamw.root.androididchanger;

import android.app.AlertDialog.Builder;

class j
  implements Runnable
{
  j(h paramh, AlertDialog.Builder paramBuilder) {}
  
  public void run()
  {
    this.b.show();
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.liamw.root.androididchanger.j
 * JD-Core Version:    0.7.0.1
 */