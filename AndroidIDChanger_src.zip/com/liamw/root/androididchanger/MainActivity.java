package com.liamw.root.androididchanger;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.Settings.Secure;
import android.text.Editable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class MainActivity
  extends Activity
  implements View.OnClickListener
{
  Button a;
  TextView b;
  EditText c;
  File d;
  File e;
  SharedPreferences f;
  SharedPreferences.Editor g;
  Boolean h = Boolean.valueOf(false);
  
  private Boolean a(String paramString)
  {
    if (checkCallingOrSelfPermission(paramString) == 0) {
      return Boolean.valueOf(true);
    }
    return Boolean.valueOf(false);
  }
  
  public void a()
  {
    this.b.setText("Current ID: " + Settings.Secure.getString(getContentResolver(), "android_id"));
  }
  
  public void a(String paramString, File paramFile)
  {
    new File(Environment.getExternalStorageDirectory() + "/idchanger/backup").mkdirs();
    try
    {
      OutputStreamWriter localOutputStreamWriter = new OutputStreamWriter(new FileOutputStream(paramFile));
      localOutputStreamWriter.write(paramString);
      localOutputStreamWriter.close();
      return;
    }
    catch (IOException localIOException)
    {
      Log.w("ExternalStorage", "Error writing " + paramFile, localIOException);
    }
  }
  
  public void b()
  {
    a(Settings.Secure.getString(getContentResolver(), "android_id"), this.d);
  }
  
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    switch (paramInt1)
    {
    }
    do
    {
      return;
    } while (paramInt2 != -1);
    String str = paramIntent.getExtras().getString("genid");
    this.c.setText(str);
  }
  
  public void onClick(View paramView)
  {
    switch (paramView.getId())
    {
    case 2131230724: 
    case 2131230725: 
    case 2131230726: 
    default: 
      return;
    case 2131230727: 
      b();
      this.h = a("android.permission.WRITE_SECURE_SETTINGS");
      if (this.h.booleanValue())
      {
        Settings.Secure.putString(getContentResolver(), "android_id", this.c.getText().toString());
        Toast.makeText(this, "Done!", 0).show();
      }
      for (;;)
      {
        a();
        return;
        Toast.makeText(this, "We don't have the Write Secure Settings permission. Please restart the app.", 1).show();
      }
    case 2131230722: 
      b();
      a();
      return;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    for (;;)
    {
      try
      {
        BufferedReader localBufferedReader = new BufferedReader(new FileReader(this.d));
        str2 = localBufferedReader.readLine();
        if (str2 != null) {
          continue;
        }
        localBufferedReader.close();
      }
      catch (IOException localIOException)
      {
        String str2;
        String str1;
        localIOException.printStackTrace();
        continue;
        Toast.makeText(this, "We don't have the Write Secure Settings permission. Please restart the app.", 1).show();
        continue;
      }
      str1 = localStringBuilder.toString();
      this.h = a("android.permission.WRITE_SECURE_SETTINGS");
      if (!this.h.booleanValue()) {
        continue;
      }
      Settings.Secure.putString(getContentResolver(), "android_id", str1);
      Toast.makeText(this, "Done!", 0).show();
      a();
      return;
      localStringBuilder.append(str2);
    }
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903041);
    this.f = PreferenceManager.getDefaultSharedPreferences(this);
    this.g = this.f.edit();
    int i = Integer.parseInt(this.f.getString("openedint", "1"));
    Boolean localBoolean = Boolean.valueOf(this.f.getBoolean("rdisplay", true));
    this.g.putString("openedint", String.valueOf(i + 1));
    this.g.commit();
    Log.d("Rating Dialog", "topened is: " + String.valueOf(i));
    Log.d("Rating Dialog", "rdisplay is: " + String.valueOf(localBoolean));
    if ((i >= 5) && (localBoolean.booleanValue()))
    {
      AlertDialog.Builder localBuilder2 = new AlertDialog.Builder(this);
      localBuilder2.setTitle("Liking this app?");
      localBuilder2.setMessage("You've opened this app 5 times now, so you must like it :) Why don't you leave a rating for it on Google Play?");
      localBuilder2.setCancelable(false);
      localBuilder2.setPositiveButton("Add a Rating!", new a(this, localBuilder2));
      localBuilder2.setNeutralButton("Ask me Later...", new b(this, localBuilder2));
      localBuilder2.setNegativeButton("I don't want to rate this app...", new c(this, localBuilder2));
      localBuilder2.show();
    }
    this.h = a("android.permission.WRITE_SECURE_SETTINGS");
    if (!this.h.booleanValue())
    {
      d locald = new d(this);
      locald.start();
      while (locald.isAlive()) {}
    }
    this.h = a("android.permission.WRITE_SECURE_SETTINGS");
    if (!this.h.booleanValue())
    {
      AlertDialog.Builder localBuilder1 = new AlertDialog.Builder(this);
      localBuilder1.setTitle("Write Secure Settings Permission");
      localBuilder1.setMessage("This app requires the Write Secure Settings permission, however I was unable to acquire it. Please convert this app into a system app.");
      localBuilder1.setPositiveButton("Convert to System App & Reboot", new e(this));
      localBuilder1.setNegativeButton("Exit & Uninstall App", new g(this));
      localBuilder1.setCancelable(false);
      localBuilder1.show();
    }
    this.e = Environment.getExternalStorageDirectory();
    this.d = new File(this.e, "idchanger/backup/backup.txt");
    this.a = ((Button)findViewById(2131230727));
    this.b = ((TextView)findViewById(2131230724));
    this.c = ((EditText)findViewById(2131230725));
    a();
    this.a.setOnClickListener(this);
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    new MenuInflater(this).inflate(2131165184, paramMenu);
    return super.onCreateOptionsMenu(paramMenu);
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem)
  {
    switch (paramMenuItem.getItemId())
    {
    }
    for (;;)
    {
      return super.onMenuItemSelected(paramInt, paramMenuItem);
      startActivity(new Intent(this, BackupActivity.class));
      continue;
      startActivityForResult(new Intent(this, GenerateActivity.class), 25);
    }
  }
  
  protected void onResume()
  {
    super.onResume();
    a();
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.liamw.root.androididchanger.MainActivity
 * JD-Core Version:    0.7.0.1
 */