package com.liamw.root.a;

import java.util.Iterator;
import java.util.List;

public class c
{
  public static List a(String paramString)
  {
    return b.a("su", new String[] { paramString }, false);
  }
  
  public static List a(String[] paramArrayOfString)
  {
    return b.a("su", paramArrayOfString, false);
  }
  
  public static boolean a()
  {
    List localList = a(new String[] { "id", "echo -EOC-" });
    if (localList == null) {
      return false;
    }
    Iterator localIterator = localList.iterator();
    String str;
    do
    {
      if (!localIterator.hasNext()) {
        return false;
      }
      str = (String)localIterator.next();
      if (str.contains("uid=")) {
        return str.contains("uid=0");
      }
    } while (!str.contains("-EOC-"));
    return true;
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.liamw.root.a.c
 * JD-Core Version:    0.7.0.1
 */