package com.liamw.root.a;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

public class e
  extends Thread
{
  private String a = null;
  private BufferedReader b = null;
  private List c = null;
  
  public e(String paramString, InputStream paramInputStream, List paramList)
  {
    this.a = paramString;
    this.b = new BufferedReader(new InputStreamReader(paramInputStream));
    this.c = paramList;
  }
  
  public void run()
  {
    for (;;)
    {
      try
      {
        str = this.b.readLine();
        if (str != null) {}
      }
      catch (IOException localIOException1)
      {
        String str;
        Object[] arrayOfObject;
        continue;
      }
      try
      {
        this.b.close();
        return;
      }
      catch (IOException localIOException2) {}
      arrayOfObject = new Object[2];
      arrayOfObject[0] = this.a;
      arrayOfObject[1] = str;
      a.a(String.format("[%s] %s", arrayOfObject));
      if (this.c != null) {
        this.c.add(str);
      }
    }
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.liamw.root.a.e
 * JD-Core Version:    0.7.0.1
 */