package com.liamw.root.a;

public class d
  extends RuntimeException
{
  public d()
  {
    super("Application attempted to run a shell command from the main thread");
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.liamw.root.a.d
 * JD-Core Version:    0.7.0.1
 */