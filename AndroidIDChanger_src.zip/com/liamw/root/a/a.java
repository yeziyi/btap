package com.liamw.root.a;

import android.util.Log;

public class a
{
  public static void a(String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder("[libsuperuser]");
    if ((!paramString.startsWith("[")) && (!paramString.startsWith(" "))) {}
    for (String str = " ";; str = "")
    {
      Log.d("libsuperuser", str + paramString);
      return;
    }
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.liamw.root.a.a
 * JD-Core Version:    0.7.0.1
 */