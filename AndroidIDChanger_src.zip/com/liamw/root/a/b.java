package com.liamw.root.a;

public class b
{
  /* Error */
  public static java.util.List a(java.lang.String paramString, java.lang.String[] paramArrayOfString, boolean paramBoolean)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 16	java/lang/String:toUpperCase	()Ljava/lang/String;
    //   4: astore_3
    //   5: invokestatic 22	android/os/Looper:myLooper	()Landroid/os/Looper;
    //   8: invokestatic 25	android/os/Looper:getMainLooper	()Landroid/os/Looper;
    //   11: if_acmpne +16 -> 27
    //   14: ldc 27
    //   16: invokestatic 32	com/liamw/root/a/a:a	(Ljava/lang/String;)V
    //   19: new 34	com/liamw/root/a/d
    //   22: dup
    //   23: invokespecial 38	com/liamw/root/a/d:<init>	()V
    //   26: athrow
    //   27: ldc 40
    //   29: iconst_1
    //   30: anewarray 4	java/lang/Object
    //   33: dup
    //   34: iconst_0
    //   35: aload_3
    //   36: aastore
    //   37: invokestatic 44	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   40: invokestatic 32	com/liamw/root/a/a:a	(Ljava/lang/String;)V
    //   43: new 46	java/util/ArrayList
    //   46: dup
    //   47: invokespecial 47	java/util/ArrayList:<init>	()V
    //   50: invokestatic 53	java/util/Collections:synchronizedList	(Ljava/util/List;)Ljava/util/List;
    //   53: astore 4
    //   55: invokestatic 59	java/lang/Runtime:getRuntime	()Ljava/lang/Runtime;
    //   58: aload_0
    //   59: invokevirtual 63	java/lang/Runtime:exec	(Ljava/lang/String;)Ljava/lang/Process;
    //   62: astore 8
    //   64: new 65	java/io/DataOutputStream
    //   67: dup
    //   68: aload 8
    //   70: invokevirtual 71	java/lang/Process:getOutputStream	()Ljava/io/OutputStream;
    //   73: invokespecial 74	java/io/DataOutputStream:<init>	(Ljava/io/OutputStream;)V
    //   76: astore 9
    //   78: new 76	com/liamw/root/a/e
    //   81: dup
    //   82: new 78	java/lang/StringBuilder
    //   85: dup
    //   86: aload_3
    //   87: invokestatic 82	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   90: invokespecial 84	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   93: ldc 86
    //   95: invokevirtual 90	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   98: invokevirtual 93	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   101: aload 8
    //   103: invokevirtual 97	java/lang/Process:getInputStream	()Ljava/io/InputStream;
    //   106: aload 4
    //   108: invokespecial 100	com/liamw/root/a/e:<init>	(Ljava/lang/String;Ljava/io/InputStream;Ljava/util/List;)V
    //   111: astore 10
    //   113: new 78	java/lang/StringBuilder
    //   116: dup
    //   117: aload_3
    //   118: invokestatic 82	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   121: invokespecial 84	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   124: ldc 102
    //   126: invokevirtual 90	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   129: invokevirtual 93	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   132: astore 11
    //   134: aload 8
    //   136: invokevirtual 105	java/lang/Process:getErrorStream	()Ljava/io/InputStream;
    //   139: astore 12
    //   141: iload_2
    //   142: ifeq +138 -> 280
    //   145: aload 4
    //   147: astore 13
    //   149: new 76	com/liamw/root/a/e
    //   152: dup
    //   153: aload 11
    //   155: aload 12
    //   157: aload 13
    //   159: invokespecial 100	com/liamw/root/a/e:<init>	(Ljava/lang/String;Ljava/io/InputStream;Ljava/util/List;)V
    //   162: astore 14
    //   164: aload 10
    //   166: invokevirtual 108	com/liamw/root/a/e:start	()V
    //   169: aload 14
    //   171: invokevirtual 108	com/liamw/root/a/e:start	()V
    //   174: aload_1
    //   175: arraylength
    //   176: istore 15
    //   178: iconst_0
    //   179: istore 16
    //   181: iload 16
    //   183: iload 15
    //   185: if_icmplt +101 -> 286
    //   188: aload 9
    //   190: ldc 110
    //   192: invokevirtual 113	java/io/DataOutputStream:writeBytes	(Ljava/lang/String;)V
    //   195: aload 9
    //   197: invokevirtual 116	java/io/DataOutputStream:flush	()V
    //   200: aload 8
    //   202: invokevirtual 120	java/lang/Process:waitFor	()I
    //   205: pop
    //   206: aload 9
    //   208: invokevirtual 123	java/io/DataOutputStream:close	()V
    //   211: aload 10
    //   213: invokevirtual 126	com/liamw/root/a/e:join	()V
    //   216: aload 14
    //   218: invokevirtual 126	com/liamw/root/a/e:join	()V
    //   221: aload 8
    //   223: invokevirtual 129	java/lang/Process:destroy	()V
    //   226: aload_0
    //   227: ldc 131
    //   229: invokevirtual 135	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   232: ifeq +21 -> 253
    //   235: aload 8
    //   237: invokevirtual 138	java/lang/Process:exitValue	()I
    //   240: istore 19
    //   242: iload 19
    //   244: sipush 255
    //   247: if_icmpne +6 -> 253
    //   250: aconst_null
    //   251: astore 4
    //   253: iconst_1
    //   254: anewarray 4	java/lang/Object
    //   257: astore 6
    //   259: aload 6
    //   261: iconst_0
    //   262: aload_0
    //   263: invokevirtual 16	java/lang/String:toUpperCase	()Ljava/lang/String;
    //   266: aastore
    //   267: ldc 140
    //   269: aload 6
    //   271: invokestatic 44	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   274: invokestatic 32	com/liamw/root/a/a:a	(Ljava/lang/String;)V
    //   277: aload 4
    //   279: areturn
    //   280: aconst_null
    //   281: astore 13
    //   283: goto -134 -> 149
    //   286: aload_1
    //   287: iload 16
    //   289: aaload
    //   290: astore 20
    //   292: ldc 142
    //   294: iconst_2
    //   295: anewarray 4	java/lang/Object
    //   298: dup
    //   299: iconst_0
    //   300: aload_3
    //   301: aastore
    //   302: dup
    //   303: iconst_1
    //   304: aload 20
    //   306: aastore
    //   307: invokestatic 44	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   310: invokestatic 32	com/liamw/root/a/a:a	(Ljava/lang/String;)V
    //   313: aload 9
    //   315: new 78	java/lang/StringBuilder
    //   318: dup
    //   319: aload 20
    //   321: invokestatic 82	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   324: invokespecial 84	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   327: ldc 144
    //   329: invokevirtual 90	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   332: invokevirtual 93	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   335: invokevirtual 113	java/io/DataOutputStream:writeBytes	(Ljava/lang/String;)V
    //   338: aload 9
    //   340: invokevirtual 116	java/io/DataOutputStream:flush	()V
    //   343: iinc 16 1
    //   346: goto -165 -> 181
    //   349: astore 7
    //   351: aconst_null
    //   352: astore 4
    //   354: goto -101 -> 253
    //   357: astore 5
    //   359: aconst_null
    //   360: astore 4
    //   362: goto -109 -> 253
    //   365: astore 18
    //   367: goto -156 -> 211
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	370	0	paramString	java.lang.String
    //   0	370	1	paramArrayOfString	java.lang.String[]
    //   0	370	2	paramBoolean	boolean
    //   4	297	3	str1	java.lang.String
    //   53	308	4	localList1	java.util.List
    //   357	1	5	localInterruptedException	java.lang.InterruptedException
    //   257	13	6	arrayOfObject	Object[]
    //   349	1	7	localIOException1	java.io.IOException
    //   62	174	8	localProcess	java.lang.Process
    //   76	263	9	localDataOutputStream	java.io.DataOutputStream
    //   111	101	10	locale1	e
    //   132	22	11	str2	java.lang.String
    //   139	17	12	localInputStream	java.io.InputStream
    //   147	135	13	localList2	java.util.List
    //   162	55	14	locale2	e
    //   176	10	15	i	int
    //   179	165	16	j	int
    //   365	1	18	localIOException2	java.io.IOException
    //   240	8	19	k	int
    //   290	30	20	str3	java.lang.String
    // Exception table:
    //   from	to	target	type
    //   55	141	349	java/io/IOException
    //   149	178	349	java/io/IOException
    //   188	206	349	java/io/IOException
    //   211	242	349	java/io/IOException
    //   286	343	349	java/io/IOException
    //   55	141	357	java/lang/InterruptedException
    //   149	178	357	java/lang/InterruptedException
    //   188	206	357	java/lang/InterruptedException
    //   206	211	357	java/lang/InterruptedException
    //   211	242	357	java/lang/InterruptedException
    //   286	343	357	java/lang/InterruptedException
    //   206	211	365	java/io/IOException
  }
}


/* Location:           C:\Documents and Settings\Administrator\桌面\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.liamw.root.a.b
 * JD-Core Version:    0.7.0.1
 */